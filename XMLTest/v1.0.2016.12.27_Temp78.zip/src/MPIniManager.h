// MPIniManager.h: interface for the CMPIniManager class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MPINIMANAGER_H__D87F2E24_3BE0_45BC_981F_1F910E8DA4A3__INCLUDED_)
#define AFX_MPINIMANAGER_H__D87F2E24_3BE0_45BC_981F_1F910E8DA4A3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//--------------------------------------------------------------------------------------------------
#include "FileManager.h"
#include "SNManager.h"

//--------------------------------------------------------------------------------------------------
class CMPIniManager  
{
public:
	CMPIniManager();
	virtual ~CMPIniManager();


	int   m_PortAlignmentMode;
	char  m_SN[SN_LEN + 1];


	int Init(IN char *pFullPathName);
	
private:
	CFileManager  m_FileManager;
};

#endif // !defined(AFX_MPINIMANAGER_H__D87F2E24_3BE0_45BC_981F_1F910E8DA4A3__INCLUDED_)
