#if !defined(AFX_DLGSHOWCEPAGE_H__A4729CF5_B225_46EA_A5B0_A44FF794E341__INCLUDED_)
#define AFX_DLGSHOWCEPAGE_H__A4729CF5_B225_46EA_A5B0_A44FF794E341__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// dlgShowCEPage.h : header file
//

//-------------------------------------------------------------------------------------------------
#include "MPDefine.h"

/////////////////////////////////////////////////////////////////////////////
// CdlgShowCEPage dialog

class CdlgShowCEPage : public CDialog
{
// Construction
public:
	CdlgShowCEPage(CWnd* pParent = NULL, IN const CH_ID_INFO *pIdInfo = NULL);   // standard constructor
	int  Init();
	//int  Init(IN CH_ID_INFO *pIdInfo);
	int  showAllCe();
// Dialog Data
	//{{AFX_DATA(CdlgShowCEPage)
	enum { IDD = IDD_CE_INFO };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CdlgShowCEPage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CdlgShowCEPage)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	virtual BOOL OnInitDialog();
	CEdit	m_edit_show_ce0, m_edit_show_ce1;

	DECLARE_MESSAGE_MAP()
private:
	void            InitUI();

	CH_ID_INFO  m_IdInfo;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGSHOWCEPAGE_H__A4729CF5_B225_46EA_A5B0_A44FF794E341__INCLUDED_)
