// SNManager.cpp: implementation of the CSNManager class.
//
///////////////////////////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SSDMP.h"
#include "SNManager.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

///////////////////////////////////////////////////////////////////////////////////////////////////
// Construction/Destruction
///////////////////////////////////////////////////////////////////////////////////////////////////

CSNManager::CSNManager()
{
	// init member variable
	::InitializeCriticalSection(&this->m_CriticalSection);

	::memset(this->m_CurrentSN, 0, sizeof(this->m_CurrentSN));
	::memset(this->m_EndSN, 0, sizeof(this->m_EndSN));
    ::memset(this->m_Addend, 0, sizeof(this->m_Addend));
    
    this->m_SNLen = 0;
    this->m_IsInitSucceed = false;
    this->m_IsFirstGenSN  = true;
    
    
    
    this->m_pFixPart            = NULL;
    this->m_pCurrentCounterPart = NULL;
    this->m_pEndCounterPart     = NULL;
    this->m_FixPartLen          = 0;
    this->m_CounterPartLen      = 0;
}

//-------------------------------------------------------------------------------------------------
CSNManager::~CSNManager()
{
    this->ReleaseResource();
    
	::DeleteCriticalSection(&this->m_CriticalSection);
}

//-------------------------------------------------------------------------------------------------
int CSNManager::Init(IN char *pStartSN, IN char *pEndSN, IN char *pMask)
{
    int   StartLen;
    int   EndLen;
    int   MaskLen;
    bool  IsDecStr;
    char  Temp[8];
    
    
    this->m_IsInitSucceed = false;
    
    // check length
    StartLen = ::strlen(pStartSN);
    EndLen   = ::strlen(pEndSN);
    MaskLen  = ::strlen(pMask);
    
    
    if ((StartLen > SN_LEN) || (EndLen > SN_LEN) || (MaskLen > SN_LEN)) {
        return 1;
    }
    
    if ((StartLen != EndLen) || (EndLen != MaskLen) || (MaskLen != StartLen)) {
        return 1;
    }
    
    // calculate '#' count from the higest position of mask
    int PoundCount = 0;
    for (int i = (MaskLen - 1); i >= 0; i--) {
        if (pMask[i] == '#') {
            PoundCount++;
            continue;
        }
        break;
    }
    
    //==========================================================
    //      serial number --> fix part + counter part
    //==========================================================
    this->m_FixPartLen     = MaskLen - PoundCount;
    this->m_CounterPartLen = PoundCount;
    
    // fix part
    this->m_pFixPart = (char*)::malloc(this->m_FixPartLen);
    if (this->m_pFixPart == NULL) {
        this->ReleaseResource();
        return 1;
    }
    ::memset(this->m_pFixPart, 0, this->m_FixPartLen);
    ::strncpy(this->m_pFixPart, pMask, this->m_FixPartLen);
    
    
    // counter part is from start sn and use decimal number
    this->m_pCurrentCounterPart = (BYTE*)::malloc(this->m_CounterPartLen);
    if (this->m_pCurrentCounterPart == NULL) {
        this->ReleaseResource();
        return 1;
    }
    
    ::memset(this->m_pCurrentCounterPart, 0, this->m_CounterPartLen);
    for (int i = 0; i < this->m_CounterPartLen; i++) {
        // convert start sn to current counter part int array. lowest number is from array[0]
        int Decimal;
        ::memset(Temp, 0, sizeof(Temp));
        ::sprintf(Temp, "%c", pStartSN[this->m_FixPartLen + i]);
        /*
        ::sscanf(Temp, "%2d", &this->m_pCurrentCounterPart[this->m_CounterPartLen - 1 -i]);
        */
        ::sscanf(Temp, "%2d", &Decimal);
        this->m_pCurrentCounterPart[this->m_CounterPartLen - 1 -i] = (BYTE)Decimal;
    }
    
    this->m_pEndCounterPart = (BYTE*)::malloc(this->m_CounterPartLen);
    if (this->m_pEndCounterPart == NULL) {
        this->ReleaseResource();
        return 1;
    }
    
    ::memset(this->m_pEndCounterPart, 0, this->m_CounterPartLen);
    for (int i = 0; i < this->m_CounterPartLen; i++) {
        // convert end sn to end counter part int array. lowest number is from array[0]
        int Decimal;
        ::memset(Temp, 0, sizeof(Temp));
        ::sprintf(Temp, "%c", pEndSN[this->m_FixPartLen + i]);
        /*
        ::sscanf(Temp, "%d", &this->m_pEndCounterPart[this->m_CounterPartLen - 1 -i]);
        */
        ::sscanf(Temp, "%d", &Decimal);
        this->m_pEndCounterPart[this->m_CounterPartLen - 1 -i] = (BYTE)Decimal;
        
    }
    
    // check counter part --> should not have non-decimal number
    IsDecStr = this->IsDecString(&pStartSN[this->m_FixPartLen], this->m_CounterPartLen);
    if (IsDecStr == false) {
        this->ReleaseResource();
        return 1;
    }
    
    IsDecStr = this->IsDecString(&pEndSN[this->m_FixPartLen], this->m_CounterPartLen);
    if (IsDecStr == false) {
        this->ReleaseResource();
        return 1;
    }
    
    
    // end sn should not be less than start sn
    if (this->IsStartBiggerThanEnd(this->m_pCurrentCounterPart, this->m_pEndCounterPart, this->m_CounterPartLen) == true) {
        this->ReleaseResource();
        return 1;
    }
    
    this->m_SNLen         = this->m_FixPartLen + this->m_CounterPartLen;
    this->m_IsInitSucceed = true;
    this->m_IsFirstGenSN  = true;

	return 0;
}

//-------------------------------------------------------------------------------------------------
int CSNManager::GenerateSN(OUT char *pSN)
{
	::EnterCriticalSection(&this->m_CriticalSection);
    
    BYTE  TempSN[SN_LEN];
    int   Carry;
    char  Buffer[8];
    int   i;
    

    if (this->m_IsInitSucceed == false) {
        ::LeaveCriticalSection(&this->m_CriticalSection);
        return 1;
    }
    
    // to let user get the sn from the start sn. after that will always add 1
    this->m_Addend[0] = (this->m_IsFirstGenSN == true) ? 0 : 1;
    this->m_IsFirstGenSN = false;
    
    
    //
    // if current counter part equal to the end counter part
    //
    if (::memcmp(this->m_pCurrentCounterPart, this->m_pEndCounterPart, this->m_CounterPartLen) == 0) {
        ::LeaveCriticalSection(&this->m_CriticalSection);
        return 1;
    }
    
    //
    // big number add method
    //
    ::memset(TempSN, 0, sizeof(TempSN));
    ::memcpy(TempSN, this->m_pCurrentCounterPart, this->m_CounterPartLen);
    
    Carry = 0;
    
    for (i = 0; i < this->m_CounterPartLen; i++){
        TempSN[i] = TempSN[i] + this->m_Addend[i] + Carry;
        
        Carry     = TempSN[i] / 10;
        TempSN[i] = TempSN[i] % 10;
    }
    
    // Theoretically this case should not occur, because we have checked equal case in the above code
    if (Carry == 1) {
        ::LeaveCriticalSection(&this->m_CriticalSection);
        return 1;
    }
    
    // Theoretically this case should not occur, because we have checked equal case in the above code
    if (this->IsStartBiggerThanEnd(TempSN, this->m_pEndCounterPart, m_CounterPartLen) == true) {
        ::LeaveCriticalSection(&this->m_CriticalSection);
        return 1;
    }
    
    
    ::memcpy(pSN, this->m_pFixPart, this->m_FixPartLen);
    for (int i = 0; i < this->m_CounterPartLen; i++) {
        ::memset(Buffer, 0, sizeof(Buffer));
        ::sprintf(Buffer, "%d", TempSN[i]);
        pSN[this->m_SNLen - 1 - i] = Buffer[0];
    }
    
    // update current sn
    ::memcpy(this->m_pCurrentCounterPart, TempSN, this->m_CounterPartLen);


	::LeaveCriticalSection(&this->m_CriticalSection);

	return 0;
}

//-------------------------------------------------------------------------------------------------
int CSNManager::GetCurrentSN(OUT char *pSN)
{
    char  Temp[8];


	if (this->m_IsInitSucceed == false) {
        return 1;
    }
    
    ::memcpy(pSN, this->m_pFixPart, this->m_FixPartLen);
    for (int i = 0; i < this->m_CounterPartLen; i++) {
        ::memset(Temp, 0, sizeof(Temp));
        ::sprintf(Temp, "%d", this->m_pCurrentCounterPart[i]);
        pSN[this->m_SNLen - 1 - i] = Temp[0];
    }

	return 0;
}

//-------------------------------------------------------------------------------------------------
bool CSNManager::IsStartBiggerThanEnd(IN BYTE *pStart, IN BYTE *pEnd, IN int CheckLen)
{
    for (int i = (CheckLen - 1); i >= 0; i--) {

        // compare from the highest number
        if (pStart[i] == pEnd[i]) {
            continue;
        }
        else if (pStart[i] < pEnd[i]) {
            return false;
        }
        else {
            return true;
        }
    }
    
    return false;
}

//-------------------------------------------------------------------------------------------------
bool CSNManager::IsHexNumString(IN char *pStr, IN int StrLen)
{
	for (int i = 0; i < StrLen; i++) {
		if (!::isxdigit(pStr[i])) {
            return false;
        }
	}
    
    return true;
}

//---------------------------------------------------------------------------
bool CSNManager::IsDecString(IN char *pStr, IN int StrLen)
{
	for (int i = 0; i < StrLen; i++) {
		if (!::isdigit(pStr[i]))
			return false;
	}

	return true;
}

//-------------------------------------------------------------------------------------------------
void CSNManager::ReleaseResource()
{
    if (this->m_pFixPart != NULL) {
        ::free(this->m_pFixPart);
        this->m_pFixPart = NULL;
    }
    
    if (this->m_pCurrentCounterPart != NULL) {
        ::free(this->m_pCurrentCounterPart);
        this->m_pCurrentCounterPart = NULL;
    }
    
    if (this->m_pEndCounterPart != NULL) {
        ::free(this->m_pEndCounterPart);
        this->m_pEndCounterPart = NULL;
    }
    
    return;
}

//-------------------------------------------------------------------------------------------------


