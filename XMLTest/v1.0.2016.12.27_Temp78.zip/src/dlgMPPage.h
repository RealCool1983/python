#if !defined(AFX_DLGMPPAGE_H__B01FD19A_A4ED_4DDA_80E5_8FB6214083E5__INCLUDED_)
#define AFX_DLGMPPAGE_H__B01FD19A_A4ED_4DDA_80E5_8FB6214083E5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// dlgMPPage.h : header file
//

//-------------------------------------------------------------------------------------------------
#include "MPDefine.h"
#include "dlgNandInfo.h"

// common class
#include "XListCtrl.h"
#include "XColorStatic.h"
#include "Label.h"

//-------------------------------------------------------------------------------------------------
// drive status
#define DRIVE_READY  "ready"
#define DRIVE_BUSY   "busy"


#pragma pack(1)

typedef struct _MP_LIST_CTRL_FORMAT
{
	char    Title[64];
	UINT32  Alignment;
	UINT32  Width;
	UINT16  ColumnIndex;
} MP_LIST_CTRL_FORMAT, *PMP_LIST_CTRL_FORMAT;

#pragma pack()

//-------------------------------------------------------------------------------------------------


///////////////////////////////////////////////////////////////////////////////////////////////////
// CdlgMPPage dialog

class CdlgMPPage : public CDialog
{
// Construction
public:
	CdlgMPPage(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CdlgMPPage)
	enum { IDD = IDD_MP_PAGE_DIALOG };
	CXColorStatic	m_StaticDescription;
	CXListCtrl	m_ListCtrlMPInfo;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CdlgMPPage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CdlgMPPage)
	virtual BOOL OnInitDialog();
	afx_msg void OnBtnStart();
	afx_msg void OnBtnScan();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnDblclkListMpInfo(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

public:
	static double  UINT64ToDouble(UINT64 ui64);


	int   Init(IN PORT_DATA *pPortData, IN char *pCommonBurnerFullPath);

	void  EnableAllUI(IN bool IsEnable);
	void  EnableRunTimer(IN bool IsEnable);
    void  UpdatePortDataUI(IN PORT_DATA *pPortData);
    
    void  ClearPort(IN int ItemIndex);
    void  UpdatePhyDrvNum(IN int ItemIndex, IN int PhyDrvNum);
    void  UpdateProgress(IN int ItemIndex, IN int Progress);
    void  UpdateStatus(IN int ItemIndex, IN char *pStatus, COLORREF TextColor);
    void  UpdateCapacity(IN int ItemIndex, IN char *pStr);
    void  ShowErrorCode(IN int ItemIndex, IN int ErrorCode);
    void  ShowDescription(IN char *pStr);
    BOOL  IsItemChecked(IN int ItemIndex);

    // status bar
    void  SetStatusBarTotalCount(IN int Count);
    void  SetStatusBarPassCount(IN int Count);
    void  SetStatusBarFailCount(IN int Count);
	void  SetStatusBarKeyProCount(IN int Count);

private:
	PORT_DATA     *m_pPortData;
	char          m_CommonBurnerFullPath[MAX_PATH];
	CFileManager  m_FileManager;
    CFont         m_ListCtrlFont;     // IDC_LIST_MP_INFO font
    CStatusBar    m_StatusBar;
	CLabel		  m_StaticRunTime;
	CLabel		  m_StaticRunTime_title;
	
    void  InitUI();
    /*
	void  InitListCtrl(IN CXListCtrl *pList);
    */
    void  InitListCtrl(IN CXListCtrl *pListCtrl, IN MP_LIST_CTRL_FORMAT *pListFormat, IN int ColumnCount);
    void  InitStatusBar(IN CStatusBar *pStatusBar);
	UINT  nRunTimeMin, nRunTimeSec;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGMPPAGE_H__B01FD19A_A4ED_4DDA_80E5_8FB6214083E5__INCLUDED_)
