#if !defined(AFX_COLOREDIT_H__70ABDC07_DF34_48A1_945B_EE3228D643B3__INCLUDED_)
#define AFX_COLOREDIT_H__70ABDC07_DF34_48A1_945B_EE3228D643B3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ColorEdit.h : header file
//


/////////////////////////////////////////////////////////////////////////////
// CColorEdit window

class CColorEdit : public CEdit
{
// Construction
public:
	CColorEdit();

// Attributes
public:

// Operations
public:

	//Overloaded Function
	void SetWindowText(LPCTSTR lpszString);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CColorEdit)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CColorEdit();

	// Generated message map functions
protected:
	//{{AFX_MSG(CColorEdit)
	afx_msg HBRUSH CtlColor(CDC* pDC, UINT nCtlColor);
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	//}}AFX_MSG

	afx_msg LRESULT OnCheckText(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()


public:
	void  SetTextColor(IN COLORREF rgb);
	void  SetBackColor(IN COLORREF rgb);	

protected:
	COLORREF  m_crText;        // text color
	COLORREF  m_crBack;        // text background color
	CBrush    m_brBackground;  // background brush

	
	void  ShowHorizScrollBar(BOOL bShow=TRUE);
	void  ShowVertScrollBar(BOOL bShow=TRUE);
	void  CheckScrolling(LPCTSTR lpszString);

private:
	BOOL  m_bShowHoriz;
	BOOL  m_bShowVert;

	static const UINT UWM_CHECKTEXT;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_COLOREDIT_H__70ABDC07_DF34_48A1_945B_EE3228D643B3__INCLUDED_)
