// ColorEdit.cpp : implementation file
//

#include "stdafx.h"
#include "ColorEdit.h"
#include "FontSize.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


#define UWM_CHECKTEXT_MSG _T("UWM_CHECKTEXT_MSG-{D53C7065_FD4C_138A_BC72_01A0253651C0}")

//Resize Message
const UINT CColorEdit::UWM_CHECKTEXT = ::RegisterWindowMessage(UWM_CHECKTEXT_MSG);

/////////////////////////////////////////////////////////////////////////////
// CColorEdit

CColorEdit::CColorEdit()
{
	// set default color
	this->m_crText = RGB(0, 0, 0);
	this->m_crBack = ::GetSysColor(COLOR_BTNFACE);
	this->m_brBackground.CreateSolidBrush(this->m_crBack);
		
	this->m_bShowHoriz = FALSE;
	this->m_bShowVert  = FALSE;
}

CColorEdit::~CColorEdit()
{
	//delete brush
	if(this->m_brBackground.GetSafeHandle()) {
		this->m_brBackground.DeleteObject();
	}
}


BEGIN_MESSAGE_MAP(CColorEdit, CEdit)
	//{{AFX_MSG_MAP(CColorEdit)
	ON_WM_CTLCOLOR_REFLECT()
	ON_WM_CHAR()
	//}}AFX_MSG_MAP
	ON_REGISTERED_MESSAGE(UWM_CHECKTEXT, OnCheckText)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CColorEdit message handlers

HBRUSH CColorEdit::CtlColor(CDC* pDC, UINT nCtlColor) 
{
	// TODO: Change any attributes of the DC here
	
	// TODO: Return a non-NULL brush if the parent's handler should not be called

	// set text color
	pDC->SetTextColor(this->m_crText);

	// set background color
	pDC->SetBkColor(this->m_crBack);
	
	//return NULL;
	return this->m_brBackground;
}

//---------------------------------------------------------------------------
void CColorEdit::SetTextColor(IN COLORREF rgb)
{
	//set text color
	this->m_crText = rgb;

	//redraw
	Invalidate(TRUE);
}

//---------------------------------------------------------------------------
void CColorEdit::SetBackColor(IN COLORREF rgb)
{
	this->m_crBack = rgb;

	//free brush
	if(this->m_brBackground.GetSafeHandle()) {
		this->m_brBackground.DeleteObject();
	}

	//set brush to new color
	this->m_brBackground.CreateSolidBrush(rgb);

	//redraw
	Invalidate(TRUE);
}

//---------------------------------------------------------------------------
void CColorEdit::SetWindowText(LPCTSTR lpszString)
{
	this->CheckScrolling(lpszString);
	CEdit::SetWindowText(lpszString);
}

//---------------------------------------------------------------------------
void CColorEdit::CheckScrolling(LPCTSTR lpszString)
{
	CRect oRect;	
	CClientDC oDC(this);
	int    iHeight=0;
	BOOL   bHoriz = FALSE;
	CFont* pEdtFont = GetFont();


	GetClientRect(&oRect);
	this->GetClientRect(&oRect);
	
	/*
	TEXTMETRIC           tm;      
     oDC.GetTextMetrics(&tm);          
     int       nHeight=(tm.tmHeight+tm.tmExternalLeading);
     int nn = this->LineLength(1);
	 */


	if(pEdtFont != NULL) {

		//Determine Text Width and Height
		SIZE oSize;
		CFont* pOldFont = oDC.SelectObject(pEdtFont);

		//Determine the line Height
		oSize = oDC.GetTextExtent(CString(_T(" ")));		
		iHeight = oSize.cy;

		//Text Width
		int iWidth=0, i =0;
		CString oStr;

		//Parse the string, the lines in a multiline Edit are separated by "\r\n"
		while(TRUE == ::AfxExtractSubString(oStr, lpszString, i, _T('\n'))) {
			if(FALSE == bHoriz) {
				int iLen = oStr.GetLength()-1;
				if(iLen >=0) {
					//Eliminate last '\r'
					if(_T('\r') == oStr.GetAt(iLen))
						oStr = oStr.Left(iLen);
					oSize = oDC.GetTextExtent(oStr);
					if(iWidth < oSize.cx)
						iWidth = oSize.cx;
					if(iWidth >= oRect.Width())
						bHoriz = TRUE;
				}
			}
			i++;
		}
		oDC.SelectObject(pOldFont);
		//Text Height
		iHeight *= i;
	}

	//this->ShowHorizScrollBar(bHoriz);
	//this->ShowVertScrollBar(iHeight + 15 >= oRect.Height());	
}

//---------------------------------------------------------------------------
LRESULT CColorEdit::OnCheckText(WPARAM wParam, LPARAM lParam)
{
	CString oStr;
	GetWindowText(oStr);
	this->CheckScrolling(oStr);

	return 0;
}

//---------------------------------------------------------------------------
void CColorEdit::ShowHorizScrollBar(BOOL bShow)
{
	if(this->m_bShowHoriz != bShow) {
		this->ShowScrollBar(SB_HORZ, bShow);
		this->m_bShowHoriz = bShow;
	}
}

//---------------------------------------------------------------------------
void CColorEdit::ShowVertScrollBar(BOOL bShow)
{
	if(this->m_bShowVert != bShow) {
		this->ShowScrollBar(SB_VERT, bShow);
		this->m_bShowVert = bShow;
	}
}

//---------------------------------------------------------------------------
void CColorEdit::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	// TODO: Add your message handler code here and/or call default
	
	PostMessage(UWM_CHECKTEXT);
	CEdit::OnChar(nChar, nRepCnt, nFlags);
}
