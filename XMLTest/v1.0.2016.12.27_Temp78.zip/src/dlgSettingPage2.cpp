// dlgSettingPage2.cpp : implementation file
//

#include "stdafx.h"
#include "SSDMP.h"
#include "dlgSettingPage2.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

///////////////////////////////////////////////////////////////////////////////////////////////////
// CdlgSettingPage2 dialog


CdlgSettingPage2::CdlgSettingPage2(CWnd* pParent /*=NULL*/)
	: CDialog(CdlgSettingPage2::IDD, pParent)
{
	//{{AFX_DATA_INIT(CdlgSettingPage2)
	m_RadioSelectIniMode = UNKNOW_INI_MODE;
	//}}AFX_DATA_INIT
}

//-------------------------------------------------------------------------------------------------
void CdlgSettingPage2::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CdlgSettingPage2)
	DDX_Radio(pDX, IDC_RADIO_AUTO, m_RadioSelectIniMode);
	//}}AFX_DATA_MAP
}

//-------------------------------------------------------------------------------------------------
BEGIN_MESSAGE_MAP(CdlgSettingPage2, CDialog)
	//{{AFX_MSG_MAP(CdlgSettingPage2)
	ON_BN_CLICKED(IDC_BTN_SAVE, OnBtnSave)
	ON_BN_CLICKED(IDC_BTN_SAVE_AS, OnBtnSaveAs)
	ON_BN_CLICKED(IDC_BTN_DETECT, OnBtnDetect)
	ON_BN_CLICKED(IDC_BTN_BROWSE_INI, OnBtnBrowseIni)
	ON_BN_CLICKED(IDC_BTN_BROWSE_FW, OnBtnBrowseFw)
	ON_BN_CLICKED(IDC_RADIO_AUTO, OnRadioAuto)
	ON_BN_CLICKED(IDC_RADIO_MANUAL, OnRadioManual)
	ON_CBN_SELCHANGE(IDC_COMBO_INI, OnSelChangeComboIni)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

///////////////////////////////////////////////////////////////////////////////////////////////////
// CdlgSettingPage2 message handlers

BOOL CdlgSettingPage2::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here

	this->InitUI();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

//-------------------------------------------------------------------------------------------------
void CdlgSettingPage2::InitUI()
{
	CEdit      *pEdit;
	CComboBox  *pComboBox;


	// select ini mode
	this->m_RadioSelectIniMode = AUTO_INI_MODE;
	UpdateData(FALSE);

    this->OnRadioAuto();


	// Common group
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_MODEL_NAME);
	pEdit->SetLimitText(MODEL_NAME_LEN);

	pComboBox = (CComboBox*)GetDlgItem(IDC_COMBO_FORCE_ERASE_ALL);
	pComboBox->AddString("True");
	pComboBox->AddString("False");


	// RDT group
	pComboBox = (CComboBox*)GetDlgItem(IDC_COMBO_TLC_RANDOM_BLOCK);
	pComboBox->AddString("True");
	pComboBox->AddString("False");

	pComboBox = (CComboBox*)GetDlgItem(IDC_COMBO_SLC_RANDOM_BLOCK);
	pComboBox->AddString("True");
	pComboBox->AddString("False");

	this->EnableRDTGroupCtrl(FALSE);
	this->EnableMPGroupCtrl(FALSE);

	return;
}

//-------------------------------------------------------------------------------------------------
int CdlgSettingPage2::Init(IN PORT_DATA *pPortData, IN char *pMTableFullPath, IN char *pCommonBurnerFullPath)
{
	CString  StrMsg;
	BOOL     IsFileExist;

    
    this->m_pPortData = pPortData;

    IsFileExist = this->m_FileManager.IsFileExist(pMTableFullPath);
	if (IsFileExist == FALSE) {
		StrMsg.Format("MTable.set doesn't exist. path = %s", pMTableFullPath);
		MessageBox(StrMsg, NULL, MB_OK | MB_ICONERROR);
		return 1;
	}
    ::memset(this->m_MTableFullPath, 0, sizeof(this->m_MTableFullPath));
    ::strncpy(this->m_MTableFullPath, pMTableFullPath, MAX_PATH);


    IsFileExist = this->m_FileManager.IsFileExist(pCommonBurnerFullPath);
	if (IsFileExist == FALSE) {
		StrMsg.Format("common burner doesn't exist. path = %s", pCommonBurnerFullPath);
		MessageBox(StrMsg, NULL, MB_OK | MB_ICONERROR);
		return 1;
	}
    ::memset(this->m_CommonBurnerFullPath, 0, sizeof(this->m_CommonBurnerFullPath));
    ::strncpy(this->m_CommonBurnerFullPath, pCommonBurnerFullPath, MAX_PATH);


    // interface parameter
	::memset(this->m_IniFullPath, 0, sizeof(this->m_IniFullPath));
    ::memset(this->m_FwFullPath, 0, sizeof(this->m_FwFullPath));
    this->m_Task = UNKNOW_TASK;


    // read / write ini parameter
    ::memset(&this->m_RDTSetting, 0, sizeof(RDT_INI_SETTING));
    ::memset(&this->m_MPSetting, 0, sizeof(MP_INI_SETTING));

	return 0;
}

//-------------------------------------------------------------------------------------------------
void CdlgSettingPage2::RDTSettingToUI()
{
	CString    Str;
	CEdit      *pEdit;
	CComboBox  *pComboBox;


	//======================================================
	//             common setting group
	//======================================================
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_MODEL_NAME);
	pEdit->SetWindowText(this->m_RDTSetting.Model_Name);

	pComboBox = (CComboBox*)GetDlgItem(IDC_COMBO_FORCE_ERASE_ALL);
	(this->m_RDTSetting.Is_Force_Erase_All == 0) ? pComboBox->SetCurSel(1) : pComboBox->SetCurSel(0);


	//======================================================
	//                    RDT group
	//======================================================

	// TLC full die
	Str.Format("%d", this->m_RDTSetting.TLC_Full_Die_Cycles);
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_TLC_FULL_DIE_CYCLE);
	pEdit->SetWindowText(Str);

    Str.Format("%d", this->m_RDTSetting.TLC_Full_Die_ECC_Log_Interval);
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_TLC_FULL_DIE_ECC_LOG_INTERVAL);
	pEdit->SetWindowText(Str);

	Str.Format("%d", this->m_RDTSetting.TLC_Full_Die_ECC_Bit_Threshold);
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_TLC_FULL_DIE_ECC_BIT);
	pEdit->SetWindowText(Str);

	Str.Format("%d", this->m_RDTSetting.Bypass_SLC_Weru_For_TLC_Full_Die_Test);
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_BYPASS_SLC_BLOCK_COUNT);
	pEdit->SetWindowText(Str);


	// SLC full die
	Str.Format("%d", this->m_RDTSetting.SLC_Full_Die_Cycles);
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_SLC_FULL_DIE_CYCLE);
	pEdit->SetWindowText(Str);

    Str.Format("%d", this->m_RDTSetting.SLC_Full_Die_ECC_Log_Interval);
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_SLC_FULL_DIE_ECC_LOG_INTERVAL);
	pEdit->SetWindowText(Str);

	Str.Format("%d", this->m_RDTSetting.SLC_Full_Die_ECC_Bit_Threshold);
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_SLC_FULL_DIE_ECC_BIT);
	pEdit->SetWindowText(Str);
	

	// TLC sampling
	Str.Format("%d", this->m_RDTSetting.TLC_Sampling_Cycle);
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_TLC_SAMPLING_CYCLE);
	pEdit->SetWindowText(Str);
	
	Str.Format("%d.%d", (this->m_RDTSetting.TLC_Dwell_Time / 10), (this->m_RDTSetting.TLC_Dwell_Time % 10));
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_TLC_DWELL_TIME);
	pEdit->SetWindowText(Str);
	
	Str.Format("%d", this->m_RDTSetting.TLC_ECC_Log_Interval);
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_TLC_LOG_INTERVAL);
	pEdit->SetWindowText(Str);

	Str.Format("%d", this->m_RDTSetting.TLC_Start_Select_Block);
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_TLC_START_SELECT_BLOCK);
	pEdit->SetWindowText(Str);

	Str.Format("%d", this->m_RDTSetting.TLC_End_Select_Block);
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_TLC_END_SELECT_BLOCK);
	pEdit->SetWindowText(Str);
	
	Str.Format("%d", this->m_RDTSetting.TLC_Sampling_Block_Quantity);
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_TLC_QUANTITY);
	pEdit->SetWindowText(Str);

	pComboBox = (CComboBox*)GetDlgItem(IDC_COMBO_TLC_RANDOM_BLOCK);
	(this->m_RDTSetting.TLC_Random_Block == 0) ? pComboBox->SetCurSel(1) : pComboBox->SetCurSel(0);

	Str.Format("%d", this->m_RDTSetting.TLC_Sampling_ECC_Bit_Threshold);
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_TLC_SAMPLING_ECC_BIT);
	pEdit->SetWindowText(Str);


	// SLC sampling
	Str.Format("%d", this->m_RDTSetting.SLC_Sampling_Cycle);
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_SLC_SAMPLING_CYCLE);
	pEdit->SetWindowText(Str);
	
	Str.Format("%d.%d", (this->m_RDTSetting.SLC_Dwell_Time / 10), (this->m_RDTSetting.SLC_Dwell_Time % 10));
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_SLC_DWELL_TIME);
	pEdit->SetWindowText(Str);
	
	Str.Format("%d", this->m_RDTSetting.SLC_ECC_Log_Interval);
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_SLC_LOG_INTERVAL);
	pEdit->SetWindowText(Str);

	Str.Format("%d", this->m_RDTSetting.SLC_Start_Select_Block);
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_SLC_START_SELECT_BLOCK);
	pEdit->SetWindowText(Str);

	Str.Format("%d", this->m_RDTSetting.SLC_End_Select_Block);
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_SLC_END_SELECT_BLOCK);
	pEdit->SetWindowText(Str);
	
	Str.Format("%d", this->m_RDTSetting.SLC_Sampling_Block_Quantity);
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_SLC_QUANTITY);
	pEdit->SetWindowText(Str);

	pComboBox = (CComboBox*)GetDlgItem(IDC_COMBO_SLC_RANDOM_BLOCK);
	(this->m_RDTSetting.SLC_Random_Block == 0) ? pComboBox->SetCurSel(1) : pComboBox->SetCurSel(0);
		
	Str.Format("%d", this->m_RDTSetting.SLC_Sampling_ECC_Bit_Threshold);
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_SLC_SAMPLING_ECC_BIT);
	pEdit->SetWindowText(Str);

    return;
}

//-------------------------------------------------------------------------------------------------
void CdlgSettingPage2::MPSettingToUI()
{
    CString    Str;
	CComboBox  *pComboBox;
	CEdit      *pEdit;


	//======================================================
	//             common setting group
	//======================================================
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_MODEL_NAME);
	pEdit->SetWindowText(this->m_MPSetting.Model_Name);

	pComboBox = (CComboBox*)GetDlgItem(IDC_COMBO_FORCE_ERASE_ALL);
	(this->m_MPSetting.Is_Force_Erase_All == 0) ? pComboBox->SetCurSel(1) : pComboBox->SetCurSel(0);


    //======================================================
	//                 MP setting group
	//======================================================
    Str.Format("%d", this->m_MPSetting.Max_Grown_Defect_Per_Plane);
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_MAX_GROWN_DEFECT_PER_PLANE);
	pEdit->SetWindowText(Str);

    Str.Format("%d", this->m_MPSetting.Total_Grown_Defect);
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_TOTAL_GROWN_DEFECT);
	pEdit->SetWindowText(Str);

    return;
}

//-------------------------------------------------------------------------------------------------
int CdlgSettingPage2::UIToRDTSetting()
{
	CComboBox  *pComboBox;
	CEdit      *pEdit;
	char       Buffer[64];


	//======================================================
	//                 Common group
	//======================================================
    pEdit = (CEdit*)GetDlgItem(IDC_EDIT_MODEL_NAME);

	::memset(this->m_RDTSetting.Model_Name, 0, sizeof(this->m_RDTSetting.Model_Name));
	pEdit->GetWindowText(this->m_RDTSetting.Model_Name, sizeof(this->m_RDTSetting.Model_Name));

	pComboBox = (CComboBox*)GetDlgItem(IDC_COMBO_FORCE_ERASE_ALL);
	this->m_RDTSetting.Is_Force_Erase_All = (pComboBox->GetCurSel() == 0) ?  1 : 0;


	//======================================================
	//                    RDT group
	//======================================================
	int  Integer;
    int  Decimal;


	// TLC full die
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_TLC_FULL_DIE_CYCLE);
	pEdit->GetWindowText(Buffer, sizeof(Buffer));
	this->m_RDTSetting.TLC_Full_Die_Cycles = ::atoi(Buffer);

    pEdit = (CEdit*)GetDlgItem(IDC_EDIT_TLC_FULL_DIE_ECC_LOG_INTERVAL);
	pEdit->GetWindowText(Buffer, sizeof(Buffer));
	this->m_RDTSetting.TLC_Full_Die_ECC_Log_Interval = ::atoi(Buffer);
	
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_TLC_FULL_DIE_ECC_BIT);
	pEdit->GetWindowText(Buffer, sizeof(Buffer));
	this->m_RDTSetting.TLC_Full_Die_ECC_Bit_Threshold = ::atoi(Buffer);

	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_BYPASS_SLC_BLOCK_COUNT);
	pEdit->GetWindowText(Buffer, sizeof(Buffer));
	this->m_RDTSetting.Bypass_SLC_Weru_For_TLC_Full_Die_Test = ::atoi(Buffer);


	// SLC full die
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_SLC_FULL_DIE_CYCLE);
	pEdit->GetWindowText(Buffer, sizeof(Buffer));
	this->m_RDTSetting.SLC_Full_Die_Cycles = ::atoi(Buffer);

    pEdit = (CEdit*)GetDlgItem(IDC_EDIT_SLC_FULL_DIE_ECC_LOG_INTERVAL);
	pEdit->GetWindowText(Buffer, sizeof(Buffer));
	this->m_RDTSetting.SLC_Full_Die_ECC_Log_Interval = ::atoi(Buffer);

	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_SLC_FULL_DIE_ECC_BIT);
	pEdit->GetWindowText(Buffer, sizeof(Buffer));
	this->m_RDTSetting.SLC_Full_Die_ECC_Bit_Threshold = ::atoi(Buffer);
		

	// TLC sampling
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_TLC_SAMPLING_CYCLE);
	pEdit->GetWindowText(Buffer, sizeof(Buffer));
	this->m_RDTSetting.TLC_Sampling_Cycle = ::atoi(Buffer);

	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_TLC_DWELL_TIME);
	pEdit->GetWindowText(Buffer, sizeof(Buffer));
	this->ParseString(Buffer, &Integer, &Decimal);
	this->m_RDTSetting.TLC_Dwell_Time = (Integer * 10) + Decimal;

	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_TLC_LOG_INTERVAL);
	pEdit->GetWindowText(Buffer, sizeof(Buffer));
	this->m_RDTSetting.TLC_ECC_Log_Interval = ::atoi(Buffer);

	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_TLC_START_SELECT_BLOCK);
	pEdit->GetWindowText(Buffer, sizeof(Buffer));
	this->m_RDTSetting.TLC_Start_Select_Block = ::atoi(Buffer);

	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_TLC_END_SELECT_BLOCK);
	pEdit->GetWindowText(Buffer, sizeof(Buffer));
	this->m_RDTSetting.TLC_End_Select_Block = ::atoi(Buffer);
	
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_TLC_QUANTITY);
	pEdit->GetWindowText(Buffer, sizeof(Buffer));
	this->m_RDTSetting.TLC_Sampling_Block_Quantity = ::atoi(Buffer);
	
	pComboBox = (CComboBox*)GetDlgItem(IDC_COMBO_TLC_RANDOM_BLOCK);
	this->m_RDTSetting.TLC_Random_Block = (pComboBox->GetCurSel() == 0) ? 1 : 0;

	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_TLC_SAMPLING_ECC_BIT);
	pEdit->GetWindowText(Buffer, sizeof(Buffer));
	this->m_RDTSetting.TLC_Sampling_ECC_Bit_Threshold = ::atoi(Buffer);


	// SLC sampling
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_SLC_SAMPLING_CYCLE);
	pEdit->GetWindowText(Buffer, sizeof(Buffer));
	this->m_RDTSetting.SLC_Sampling_Cycle = ::atoi(Buffer);

	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_SLC_DWELL_TIME);
	pEdit->GetWindowText(Buffer, sizeof(Buffer));
	this->ParseString(Buffer, &Integer, &Decimal);
	this->m_RDTSetting.SLC_Dwell_Time = (Integer * 10) + Decimal;

	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_SLC_LOG_INTERVAL);
	pEdit->GetWindowText(Buffer, sizeof(Buffer));
	this->m_RDTSetting.SLC_ECC_Log_Interval = ::atoi(Buffer);

	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_SLC_START_SELECT_BLOCK);
	pEdit->GetWindowText(Buffer, sizeof(Buffer));
	this->m_RDTSetting.SLC_Start_Select_Block = ::atoi(Buffer);

	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_SLC_END_SELECT_BLOCK);
	pEdit->GetWindowText(Buffer, sizeof(Buffer));
	this->m_RDTSetting.SLC_End_Select_Block = ::atoi(Buffer);
	
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_SLC_QUANTITY);
	pEdit->GetWindowText(Buffer, sizeof(Buffer));
	this->m_RDTSetting.SLC_Sampling_Block_Quantity = ::atoi(Buffer);
	
	pComboBox = (CComboBox*)GetDlgItem(IDC_COMBO_SLC_RANDOM_BLOCK);
	this->m_RDTSetting.SLC_Random_Block = (pComboBox->GetCurSel() == 0) ?  1 : 0;

	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_SLC_SAMPLING_ECC_BIT);
	pEdit->GetWindowText(Buffer, sizeof(Buffer));
	this->m_RDTSetting.SLC_Sampling_ECC_Bit_Threshold = ::atoi(Buffer);
	

    return 0;
}

//-------------------------------------------------------------------------------------------------
int CdlgSettingPage2::UIToMPSetting()
{
	CComboBox  *pComboBox;
	CEdit      *pEdit;
    char       Buffer[64];


	//======================================================
	//                 Common group
	//======================================================
    pEdit = (CEdit*)GetDlgItem(IDC_EDIT_MODEL_NAME);

	::memset(this->m_MPSetting.Model_Name, 0, sizeof(this->m_MPSetting.Model_Name));
	pEdit->GetWindowText(this->m_MPSetting.Model_Name, sizeof(this->m_MPSetting.Model_Name));

	pComboBox = (CComboBox*)GetDlgItem(IDC_COMBO_FORCE_ERASE_ALL);
	this->m_MPSetting.Is_Force_Erase_All = (pComboBox->GetCurSel() == 0) ? 1 : 0;


    //======================================================
	//                     MP group
	//======================================================
    pEdit = (CEdit*)GetDlgItem(IDC_EDIT_MAX_GROWN_DEFECT_PER_PLANE);
	pEdit->GetWindowText(Buffer, sizeof(Buffer));
	this->m_MPSetting.Max_Grown_Defect_Per_Plane = ::atoi(Buffer);

    pEdit = (CEdit*)GetDlgItem(IDC_EDIT_TOTAL_GROWN_DEFECT);
	pEdit->GetWindowText(Buffer, sizeof(Buffer));
	this->m_MPSetting.Total_Grown_Defect = ::atoi(Buffer);


    return 0;
}

//-------------------------------------------------------------------------------------------------
void CdlgSettingPage2::OnBtnSave() 
{
	// TODO: Add your control notification handler code here

    BOOL IsFileExist;
    

    IsFileExist = this->m_FileManager.IsFileExist(this->m_IniFullPath);
    if (IsFileExist == FALSE) {
        MessageBox("file not exist. please select setting first", NULL, MB_OK | MB_ICONERROR);
        return;
    }

    if (this->m_Task == UNKNOW_TASK) {
        MessageBox("unknow task. please check MTable.set or the source ini", NULL, MB_OK | MB_ICONERROR);
        return;
    }

    switch (this->m_Task) {
        case FTA_FLOW:
            this->UIToRDTSetting();
            this->SaveRDTSetting();
            break;

        case FTB_FLOW:
            this->UIToMPSetting();
            this->SaveMPSetting();
            break;
    }

	MessageBox("save successfully", NULL, MB_OK);

	return;

}

//-------------------------------------------------------------------------------------------------
void CdlgSettingPage2::OnBtnSaveAs() 
{
	// TODO: Add your control notification handler code here
	
}

//-------------------------------------------------------------------------------------------------
void CdlgSettingPage2::OnBtnDetect() 
{
	// TODO: Add your control notification handler code here
    CNandInfoManager  NandInfoManager;
    BYTE  FlashID[FLASH_ID_LENGTH];
	bool  IsDriveInserted;
    int   Index;
	int   Rslt;
	

    //============================================================
	//      get the flash id of the first port data drive
    //============================================================
    IsDriveInserted = false;

    for (Index = 0; Index < SUPPORT_PORT_COUNT; Index++) {
        if (this->m_pPortData[Index].PhyDrvNum != -1) {
            IsDriveInserted = true;
            break;
        }
    }

    if (IsDriveInserted == false) {
        MessageBox("please insert drive first", NULL, MB_OK | MB_ICONWARNING);
        return;
    }

    Rslt = NandInfoManager.Init(this->m_pPortData[Index].PhyDrvNum, NULL, this->m_CommonBurnerFullPath);
    if (Rslt != 0) {
        MessageBox("nand info manager init fail", NULL, MB_OK | MB_ICONERROR);
		return;
    }

    ::memset(FlashID, 0, sizeof(FlashID));
    NandInfoManager.GetFlashID(0, 0, FlashID);


    //============================================================
    //          parse mapping table by flash id
    //============================================================
    CComboBox     *pComboBox;
    SETTING_ITEM  SettingItem;


	Rslt = this->m_MTableManager.Init(FlashID, this->m_MTableFullPath);
	if (Rslt != 0) {
		MessageBox("MTable manager init fail", NULL, MB_OK | MB_ICONERROR);
		return;
	}

    // update ini combo box
    pComboBox = (CComboBox*)GetDlgItem(IDC_COMBO_INI);
    pComboBox->ResetContent();

    for (int i = 0; i < this->m_MTableManager.GetItemCount(); i++) {
        Rslt = this->m_MTableManager.GetItem(&SettingItem, i);
        if (Rslt != 0) {
            continue;
        }
        
        char  Drive[_MAX_DRIVE]         = {0};
        char  Path[_MAX_PATH]           = {0};
        char  FileName[_MAX_FNAME]      = {0};
        char  Ext_Name[8]               = {0};
        
        ::_splitpath(SettingItem.IniFullPath, Drive, Path, FileName, Ext_Name);

        pComboBox->AddString(FileName);
    }

    pComboBox->SetCurSel(0);
	this->OnSelChangeComboIni();

	return;
}

//-------------------------------------------------------------------------------------------------
void CdlgSettingPage2::OnBtnBrowseIni() 
{
	// TODO: Add your control notification handler code here
    CEdit    *pEdit;
	CString  Filter;
	char     CurrentDir[MAX_PATH];
	

	::memset(CurrentDir, 0, sizeof(CurrentDir));
	::GetCurrentDirectory(MAX_PATH, CurrentDir);

    pEdit  = (CEdit*)GetDlgItem(IDC_EDIT_INI_FULL_PATH);
    Filter = "INI File(*.ini)|*.pem|All files(*.*)|*.*|";

	CFileDialog *BrowseIsoDlg = new CFileDialog(TRUE,
			                                    _T("ini"),
			                                    _T("*.ini"),
			                                    OFN_HIDEREADONLY,
			                                    Filter,
			                                    this);    

    BrowseIsoDlg->m_ofn.lpstrTitle= _T("Please select the ini file");
	
    if (BrowseIsoDlg->DoModal() != IDOK) {
		delete BrowseIsoDlg;
		return;
	}
	
    pEdit->SetWindowText(BrowseIsoDlg->GetPathName());
	delete BrowseIsoDlg;


	// CFileDialog will change current directory when IDOK, we need to keep
	// original directory to make auto mode works fine.
	::SetCurrentDirectory(CurrentDir);


    // assign to interface parameter
    ::memset(this->m_IniFullPath, 0, sizeof(this->m_IniFullPath));
    pEdit->GetWindowText(this->m_IniFullPath, sizeof(this->m_IniFullPath));
    
    this->GetTaskByParseINI(this->m_IniFullPath, &this->m_Task);

	switch (this->m_Task) {
	    case FTA_FLOW:
			this->ReadRDTSetting();  
            this->RDTSettingToUI();
			this->EnableRDTGroupCtrl(TRUE);
            this->EnableMPGroupCtrl(FALSE);
            ::SendMessage(AfxGetMainWnd()->m_hWnd, WM_UPDATE_DESCRIPTION, MANUAL_INI_MODE, 0);
			break;

		case FTB_FLOW:
			this->ReadMPSetting();
            this->MPSettingToUI();
            this->EnableRDTGroupCtrl(FALSE);
            this->EnableMPGroupCtrl(TRUE);
            ::SendMessage(AfxGetMainWnd()->m_hWnd, WM_UPDATE_DESCRIPTION, MANUAL_INI_MODE, 0);
			break;

		default:
			MessageBox("unknow task. please check ini file", NULL, MB_OK | MB_ICONERROR);
			return;
	}

    return;
}

//-------------------------------------------------------------------------------------------------
void CdlgSettingPage2::OnBtnBrowseFw() 
{
	// TODO: Add your control notification handler code here
    CEdit    *pEdit;
	CString  Filter;
	char     CurrentDir[MAX_PATH];
	

	::memset(CurrentDir, 0, sizeof(CurrentDir));
	::GetCurrentDirectory(MAX_PATH, CurrentDir);

    pEdit  = (CEdit*)GetDlgItem(IDC_EDIT_FW_FULL_PATH);
    Filter = "BIN File(*.bin)|*.pem|All files(*.*)|*.*|";

	CFileDialog *BrowseIsoDlg = new CFileDialog(TRUE,
			                                    _T("bin"),
			                                    _T("*.bin"),
			                                    OFN_HIDEREADONLY,
			                                    Filter,
			                                    this);    

    BrowseIsoDlg->m_ofn.lpstrTitle= _T("Please select the bin file");
	
    if (BrowseIsoDlg->DoModal() != IDOK) {
		delete BrowseIsoDlg;
		return;
	}

    pEdit->SetWindowText(BrowseIsoDlg->GetPathName());
	delete BrowseIsoDlg;


	// CFileDialog will change current directory when IDOK, we need to keep
	// original directory to make auto mode works fine.
	::SetCurrentDirectory(CurrentDir);


    // assign to interface parameter
    ::memset(this->m_FwFullPath, 0, sizeof(this->m_FwFullPath));
    pEdit->GetWindowText(this->m_FwFullPath, sizeof(this->m_FwFullPath));

    return;
}

//-------------------------------------------------------------------------------------------------
int CdlgSettingPage2::GetIniFullPath(OUT char *pBuffer, IN int BufferLen)
{
    ::memset(pBuffer, 0, BufferLen * sizeof(char));
    ::strncpy(pBuffer, this->m_IniFullPath, BufferLen);

	return 0;
}

//-------------------------------------------------------------------------------------------------
int CdlgSettingPage2::GetFwFullPath(OUT char *pBuffer, IN int BufferLen)
{
    ::memset(pBuffer, 0, BufferLen * sizeof(char));
    ::strncpy(pBuffer, this->m_FwFullPath, BufferLen);

	return 0;
}

//-------------------------------------------------------------------------------------------------
int CdlgSettingPage2::GetTask(OUT int *pTask)
{
    *pTask = this->m_Task;

    return 0;
}

//-------------------------------------------------------------------------------------------------
int CdlgSettingPage2::GetDescription(OUT char *pBuffer, IN int BufferLen)
{
    CComboBox     *pComboBox;
    SETTING_ITEM  SettingItem;
    int           CurSel;
    int           Rslt;


    if (this->m_RadioSelectIniMode == AUTO_INI_MODE) {
        pComboBox = (CComboBox*)GetDlgItem(IDC_COMBO_INI);
        CurSel = pComboBox->GetCurSel();
        if (CurSel == CB_ERR) {
            return 1;
        }

        Rslt = this->m_MTableManager.GetItem(&SettingItem, CurSel);
        if (Rslt != 0) {
            return 1;
        }

        if (BufferLen < COMMENT_LEN) {
            return 1;
        }

        ::memset(pBuffer, 0, BufferLen);
        ::strncpy(pBuffer, SettingItem.Comment, BufferLen);
    }
    else if (this->m_RadioSelectIniMode == MANUAL_INI_MODE) {
        char  Drive[_MAX_DRIVE]         = {0};
        char  Path[_MAX_PATH]           = {0};
        char  FileName[_MAX_FNAME]      = {0};
        char  Ext_Name[8]               = {0};
        
        ::_splitpath(this->m_IniFullPath, Drive, Path, FileName, Ext_Name);

        int Len = ::strlen(FileName) + ::strlen(Ext_Name);
        if (BufferLen < Len) {
            return 1;
        }

        ::memset(pBuffer, 0, BufferLen);
        ::sprintf(pBuffer, "%s%s", FileName, Ext_Name);
    }
    
    return 0;
}

//-------------------------------------------------------------------------------------------------
void CdlgSettingPage2::OnRadioAuto() 
{
	// TODO: Add your control notification handler code here
    CString       StrMsg;
    CComboBox     *pComboBox;
    SETTING_ITEM  SettingItem;
    BOOL          IsFileExist;
    int           CurSel;
    int           Rslt;

    
    UpdateData(TRUE);

    GetDlgItem(IDC_STATIC_AUTO_INI)->EnableWindow(TRUE);
	GetDlgItem(IDC_COMBO_INI)->EnableWindow(TRUE);
    GetDlgItem(IDC_BTN_DETECT)->EnableWindow(TRUE);

    
    GetDlgItem(IDC_STATIC_MANUAL_INI)->EnableWindow(FALSE);
    GetDlgItem(IDC_EDIT_INI_FULL_PATH)->EnableWindow(FALSE);
    GetDlgItem(IDC_BTN_BROWSE_INI)->EnableWindow(FALSE);

    GetDlgItem(IDC_STATIC_MANUAL_FW)->EnableWindow(FALSE);
    GetDlgItem(IDC_EDIT_FW_FULL_PATH)->EnableWindow(FALSE);
    GetDlgItem(IDC_BTN_BROWSE_FW)->EnableWindow(FALSE);


    // re-get interface parameter
    ::memset(this->m_IniFullPath, 0, sizeof(this->m_IniFullPath));
    ::memset(this->m_FwFullPath, 0, sizeof(this->m_FwFullPath));
    this->m_Task = UNKNOW_TASK;

    pComboBox = (CComboBox*)GetDlgItem(IDC_COMBO_INI);
    CurSel = pComboBox->GetCurSel();
    if (CurSel == CB_ERR) {
        return;
    }

    Rslt = this->m_MTableManager.GetItem(&SettingItem, CurSel);
    if (Rslt != 0) {
        MessageBox("get item fail", NULL, MB_OK | MB_ICONERROR);
        return;
    }


    //======================================================
    //              check setting item
    //======================================================
    IsFileExist = this->m_FileManager.IsFileExist(SettingItem.IniFullPath);
	if (IsFileExist == FALSE) {
		StrMsg.Format("ini doesn't exist. path = %s", SettingItem.IniFullPath);
		MessageBox(StrMsg, NULL, MB_OK | MB_ICONERROR);
		return;
	}

    IsFileExist = this->m_FileManager.IsFileExist(SettingItem.FwFullPath);
	if (IsFileExist == FALSE) {
		StrMsg.Format("firmware doesn't exist. path = %s", SettingItem.FwFullPath);
		MessageBox(StrMsg, NULL, MB_OK | MB_ICONERROR);
		return;
	}

    if (SettingItem.Task == UNKNOW_TASK) {
        MessageBox("unknow task. please check MTable.set", NULL, MB_OK | MB_ICONERROR);
        return;
    }

	switch (this->m_Task) {
	    case FTA_FLOW:
            this->EnableRDTGroupCtrl(TRUE);
            this->EnableMPGroupCtrl(FALSE);
            break;

		case FTB_FLOW:
            this->EnableRDTGroupCtrl(FALSE);
            this->EnableMPGroupCtrl(TRUE);
            break;
	}


    //======================================================
    //            assign to interface parameter
    //======================================================
    ::strncpy(this->m_IniFullPath, SettingItem.IniFullPath, sizeof(this->m_IniFullPath));
    ::strncpy(this->m_FwFullPath, SettingItem.FwFullPath, sizeof(this->m_FwFullPath));
    this->m_Task = SettingItem.Task;

    ::SendMessage(AfxGetMainWnd()->m_hWnd, WM_UPDATE_DESCRIPTION, AUTO_INI_MODE, 0);

    return;
}

//-------------------------------------------------------------------------------------------------
void CdlgSettingPage2::OnRadioManual() 
{
	// TODO: Add your control notification handler code here
	CEdit  *pEdit;


    UpdateData(TRUE);

    GetDlgItem(IDC_STATIC_AUTO_INI)->EnableWindow(FALSE);
	GetDlgItem(IDC_COMBO_INI)->EnableWindow(FALSE);
    GetDlgItem(IDC_BTN_DETECT)->EnableWindow(FALSE);
    
    GetDlgItem(IDC_STATIC_MANUAL_INI)->EnableWindow(TRUE);
    GetDlgItem(IDC_EDIT_INI_FULL_PATH)->EnableWindow(TRUE);
    GetDlgItem(IDC_BTN_BROWSE_INI)->EnableWindow(TRUE);

    GetDlgItem(IDC_STATIC_MANUAL_FW)->EnableWindow(TRUE);
    GetDlgItem(IDC_EDIT_FW_FULL_PATH)->EnableWindow(TRUE);
    GetDlgItem(IDC_BTN_BROWSE_FW)->EnableWindow(TRUE);


    // re-get interface parameter
    ::memset(this->m_IniFullPath, 0, sizeof(this->m_IniFullPath));
    pEdit = (CEdit*)GetDlgItem(IDC_EDIT_INI_FULL_PATH);
    pEdit->GetWindowText(this->m_IniFullPath, sizeof(this->m_IniFullPath));

    this->GetTaskByParseINI(this->m_IniFullPath, &this->m_Task);

    ::memset(this->m_FwFullPath, 0, sizeof(this->m_FwFullPath));
    pEdit = (CEdit*)GetDlgItem(IDC_EDIT_FW_FULL_PATH);
    pEdit->GetWindowText(this->m_FwFullPath, sizeof(this->m_FwFullPath));


	switch (this->m_Task) {
	    case FTA_FLOW:
            this->EnableRDTGroupCtrl(TRUE);
            this->EnableMPGroupCtrl(FALSE);
            break;

		case FTB_FLOW:
            this->EnableRDTGroupCtrl(FALSE);
            this->EnableMPGroupCtrl(TRUE);
            break;

		default:
			this->EnableRDTGroupCtrl(FALSE);
            this->EnableMPGroupCtrl(FALSE);
	}

    ::SendMessage(AfxGetMainWnd()->m_hWnd, WM_UPDATE_DESCRIPTION, MANUAL_INI_MODE, 0);

    return;
}

//-------------------------------------------------------------------------------------------------
void CdlgSettingPage2::OnSelChangeComboIni()
{
	// TODO: Add your control notification handler code here

    CComboBox     *pComboBox;
    CString       StrMsg;
    SETTING_ITEM  SettingItem;
    BOOL          IsFileExist;
    int           CurSel;
    int           Rslt;


    ::memset(this->m_IniFullPath, 0, sizeof(this->m_IniFullPath));
    ::memset(this->m_FwFullPath, 0, sizeof(this->m_FwFullPath));
    this->m_Task = UNKNOW_TASK;


    pComboBox = (CComboBox*)GetDlgItem(IDC_COMBO_INI);

    CurSel = pComboBox->GetCurSel();
    if (CurSel == CB_ERR) {
        return;
    }

    Rslt = this->m_MTableManager.GetItem(&SettingItem, CurSel);
    if (Rslt != 0) {
        MessageBox("get item fail", NULL, MB_OK | MB_ICONERROR);
        return;
    }


    //======================================================
    //              check setting item
    //======================================================
    IsFileExist = this->m_FileManager.IsFileExist(SettingItem.IniFullPath);
	if (IsFileExist == FALSE) {
		StrMsg.Format("ini doesn't exist. path = %s", SettingItem.IniFullPath);
		MessageBox(StrMsg, NULL, MB_OK | MB_ICONERROR);
		return;
	}

    IsFileExist = this->m_FileManager.IsFileExist(SettingItem.FwFullPath);
	if (IsFileExist == FALSE) {
		StrMsg.Format("firmware doesn't exist. path = %s", SettingItem.FwFullPath);
		MessageBox(StrMsg, NULL, MB_OK | MB_ICONERROR);
		return;
	}

    if (SettingItem.Task == UNKNOW_TASK) {
		this->EnableRDTGroupCtrl(FALSE);
        this->EnableMPGroupCtrl(FALSE);
        MessageBox("unknow task. please check MTable.set", NULL, MB_OK | MB_ICONERROR);
        return;
    }


    //======================================================
    //            assign to interface parameter
    //======================================================
    ::memset(this->m_IniFullPath, 0, sizeof(this->m_IniFullPath));
    ::strncpy(this->m_IniFullPath, SettingItem.IniFullPath, sizeof(this->m_IniFullPath));

    ::memset(this->m_FwFullPath, 0, sizeof(this->m_FwFullPath));
    ::strncpy(this->m_FwFullPath, SettingItem.FwFullPath, sizeof(this->m_FwFullPath));

    this->m_Task = SettingItem.Task;


    //======================================================
    //                 read setting
    //======================================================
    switch (SettingItem.Task) {
        case FTA_FLOW:
            this->ReadRDTSetting();  
            this->RDTSettingToUI();
			this->EnableRDTGroupCtrl(TRUE);
            this->EnableMPGroupCtrl(FALSE);
            ::SendMessage(AfxGetMainWnd()->m_hWnd, WM_UPDATE_DESCRIPTION, AUTO_INI_MODE, 0);
            break;

        case FTB_FLOW:
            this->ReadMPSetting();
            this->MPSettingToUI();
			this->EnableRDTGroupCtrl(FALSE);
            this->EnableMPGroupCtrl(TRUE);
            ::SendMessage(AfxGetMainWnd()->m_hWnd, WM_UPDATE_DESCRIPTION, AUTO_INI_MODE, 0);
            break;
    }

    return;
}

//-------------------------------------------------------------------------------------------------
int CdlgSettingPage2::ReadRDTSetting()
{
    char  SectionName[64];
	char  KeyValue[MAX_PATH];
	int   CopyLen;
    int   Rslt;


	::memset(&this->m_RDTSetting, 0, sizeof(RDT_INI_SETTING));

    //========================================================
	//                   [SSD_Info]
	//========================================================
	::memset(SectionName, 0, sizeof(SectionName));
	::strcpy(SectionName, "SSD_Info");


	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "BOM_No", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "");  // default value
	}
	::strncpy(this->m_RDTSetting.BOM_No, KeyValue, sizeof(this->m_RDTSetting.BOM_No));

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Controller_Name", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "");  // default value
	}
	::strncpy(this->m_RDTSetting.Controller_Name, KeyValue, sizeof(this->m_RDTSetting.Controller_Name));

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Model_Name", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "");  // default value
	}

	CopyLen = ::strlen(KeyValue);
    if (CopyLen > MODEL_NUMBER_LEN) {
        CopyLen = MODEL_NUMBER_LEN;
    }

	::strncpy(this->m_RDTSetting.Model_Name, KeyValue, CopyLen);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Controller_Vendor", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "");  // default value
	}
	::strncpy(this->m_RDTSetting.Controller_Vendor, KeyValue, sizeof(this->m_RDTSetting.Controller_Vendor));

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Chamber_Port_ID", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "");  // default value
	}
	::strncpy(this->m_RDTSetting.Chamber_Port_ID, KeyValue, sizeof(this->m_RDTSetting.Chamber_Port_ID));


	//========================================================
    //                  [Tool_Info]
    //========================================================
	::memset(SectionName, 0, sizeof(SectionName));
	::strcpy(SectionName, "Tool_Info");
    
        
	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Firmware_Version", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "");  // default value
	}
	::strncpy(this->m_RDTSetting.Firmware_Version, KeyValue, sizeof(this->m_RDTSetting.Firmware_Version));
	
	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Tool_Name", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "");  // default value
	}
	::strncpy(this->m_RDTSetting.Tool_Name, KeyValue, sizeof(this->m_RDTSetting.Tool_Name));

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Tool_Vendor", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "");  // default value
	}
	::strncpy(this->m_RDTSetting.Tool_Vendor, KeyValue, sizeof(this->m_RDTSetting.Tool_Vendor));


	//========================================================
    //             [Firmware_Bin_File_Path]
    //========================================================
	::memset(SectionName, 0, sizeof(SectionName));
	::strcpy(SectionName, "Firmware_Bin_File_Path");


	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Burner", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "");  // default value
	}
	::strncpy(this->m_RDTSetting.Burner_Path, KeyValue, sizeof(this->m_RDTSetting.Burner_Path));


	//========================================================
    //                 [Test_Condition]
    //========================================================
    int  Integer;
    int  Decimal;
    
    
	::memset(SectionName, 0, sizeof(SectionName));
	::strcpy(SectionName, "Test_Condition");
    
	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Previous_Stage", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "");  // default value
	}
	::strncpy(this->m_RDTSetting.Previous_Stage, KeyValue, sizeof(this->m_RDTSetting.Previous_Stage));

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Current_Stage", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "");  // default value
	}
	::strncpy(this->m_RDTSetting.Current_Stage, KeyValue, sizeof(this->m_RDTSetting.Current_Stage));

	
    // test condition
	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Mark_Bad", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "1");  // default value
	}
	this->m_RDTSetting.Mark_Bad = ::atoi(KeyValue);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "MP_Test", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_RDTSetting.MP_Test = ::atoi(KeyValue);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Preload_Data", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_RDTSetting.Preload_Data = ::atoi(KeyValue);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Bad_Sample_Block_Per_CE", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_RDTSetting.Bad_Sample_Block_Per_CE = ::atoi(KeyValue);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "LED_Mode", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_RDTSetting.LED_Mode = ::atoi(KeyValue);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Pattern_Mode", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_RDTSetting.Pattern_Mode = ::atoi(KeyValue);


    // TLC full die
	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "TLC_Full_Die_Cycles", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_RDTSetting.TLC_Full_Die_Cycles = ::atoi(KeyValue);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "TLC_Full_Die_ECC_Log_Interval", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_RDTSetting.TLC_Full_Die_ECC_Log_Interval = ::atoi(KeyValue);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "TLC_Full_Die_ECC_Bit_Threshold", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "200");  // default value
	}
	this->m_RDTSetting.TLC_Full_Die_ECC_Bit_Threshold = ::atoi(KeyValue);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Bypass_SLC_Weru_For_TLC_Full_Die_Test", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_RDTSetting.Bypass_SLC_Weru_For_TLC_Full_Die_Test = ::atoi(KeyValue);


	// SLC full die
	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "SLC_Full_Die_Cycles", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_RDTSetting.SLC_Full_Die_Cycles = ::atoi(KeyValue);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "SLC_Full_Die_ECC_Log_Interval", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_RDTSetting.SLC_Full_Die_ECC_Log_Interval = ::atoi(KeyValue);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "SLC_Full_Die_ECC_Bit_Threshold", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "100");  // default value
	}
	this->m_RDTSetting.SLC_Full_Die_ECC_Bit_Threshold = ::atoi(KeyValue);


    // TLC sampling
	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "TLC_Dwell_Time", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->ParseString(KeyValue, &Integer, &Decimal);
	this->m_RDTSetting.TLC_Dwell_Time = (Integer * 10) + Decimal;

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "TLC_Sampling_Cycle", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_RDTSetting.TLC_Sampling_Cycle = ::atoi(KeyValue);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "TLC_ECC_Log_Interval", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "1");  // default value
	}
	this->m_RDTSetting.TLC_ECC_Log_Interval = ::atoi(KeyValue);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "TLC_Start_Select_Block", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_RDTSetting.TLC_Start_Select_Block = ::atoi(KeyValue);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "TLC_End_Select_Block", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_RDTSetting.TLC_End_Select_Block = ::atoi(KeyValue);
    
	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "TLC_Random_Block", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_RDTSetting.TLC_Random_Block = ::atoi(KeyValue);    

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "TLC_Sampling_Block_Quantity", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_RDTSetting.TLC_Sampling_Block_Quantity = ::atoi(KeyValue);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "TLC_Sampling_ECC_Bit_Threshold", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "200");  // default value
	}
	this->m_RDTSetting.TLC_Sampling_ECC_Bit_Threshold = ::atoi(KeyValue);


    // SLC sampling
	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "SLC_Dwell_Time", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->ParseString(KeyValue, &Integer, &Decimal);
	this->m_RDTSetting.SLC_Dwell_Time = (Integer * 10) + Decimal;

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "SLC_Sampling_Cycle", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_RDTSetting.SLC_Sampling_Cycle = ::atoi(KeyValue);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "SLC_ECC_Log_Interval", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_RDTSetting.SLC_ECC_Log_Interval = ::atoi(KeyValue);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "SLC_Random_Block", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_RDTSetting.SLC_Random_Block = ::atoi(KeyValue);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "SLC_Sampling_Block_Quantity", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_RDTSetting.SLC_Sampling_Block_Quantity = ::atoi(KeyValue);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "SLC_Start_Select_Block", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_RDTSetting.SLC_Start_Select_Block = ::atoi(KeyValue);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "SLC_End_Select_Block", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_RDTSetting.SLC_End_Select_Block = ::atoi(KeyValue);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "SLC_Sampling_ECC_Bit_Threshold", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "100");  // default value
	}
	this->m_RDTSetting.SLC_Sampling_ECC_Bit_Threshold = ::atoi(KeyValue);


	//========================================================
    //              [Production_Setting]
    //========================================================
	::memset(SectionName, 0, sizeof(SectionName));
	::strcpy(SectionName, "Production_Setting");
    

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Serial_Number", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_RDTSetting.Serial_Number = ::atoi(KeyValue);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "SN_Length", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_RDTSetting.SN_Length = ::atoi(KeyValue);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "SKU", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "");  // default value
	}
	::strncpy(this->m_RDTSetting.SKU, KeyValue, sizeof(this->m_RDTSetting.SKU));


	//========================================================
    //                   [MP_Option]
    //========================================================
	::memset(SectionName, 0, sizeof(SectionName));
	::strcpy(SectionName, "MP_Option");


	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Force_Erase_All", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_RDTSetting.Is_Force_Erase_All = (::atoi(KeyValue) == 0) ? false : true;

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Keep_Setting", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_RDTSetting.Is_Keep_Setting = (::atoi(KeyValue) == 0) ? false : true;

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Backup_Table", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "1");  // default value
	}
	this->m_RDTSetting.Is_Backup_Table = (::atoi(KeyValue) == 0) ? false : true;

    ::memset(this->m_RDTSetting.Backup_Table_Folder_Full_Path_Name, 0, sizeof(this->m_RDTSetting.Backup_Table_Folder_Full_Path_Name));
    ::sprintf(this->m_RDTSetting.Backup_Table_Folder_Full_Path_Name, "./table");

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Ignore_Scan_Later_Defect", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_RDTSetting.Is_Ignore_Scan_Later_Defect = (::atoi(KeyValue) == 0) ? false : true;

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Good_Block_Per_Plane", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "1395");  // default value
	}
	this->m_RDTSetting.Good_Block_Per_Plane = ::atoi(KeyValue);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Total_Good_WERU", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "101");  // default value
	}
	this->m_RDTSetting.Total_Good_WERU = ::atoi(KeyValue);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Replace_Table_Bit_Map", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_RDTSetting.Replace_Table_Bit_Map = ::atoi(KeyValue);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Mark_Bad_Sampling_Block", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_RDTSetting.Mark_Bad_Sampling_Block = (::atoi(KeyValue) == 0) ? false : true;

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "CE_Count", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_RDTSetting.CE_Count = ::atoi(KeyValue);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Flash_ID", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "");  // default value
	}
	this->ParseFlashIdString(KeyValue, this->m_RDTSetting.Flash_ID);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Manual_Mark_Bad_Table", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "");  // default value
	}
	::strncpy(this->m_RDTSetting.Manual_Mark_Bad_Table_Full_Path_Name, KeyValue, sizeof(this->m_RDTSetting.Manual_Mark_Bad_Table_Full_Path_Name));

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Download_FW_Retry", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_RDTSetting.Download_FW_Retry = ::atoi(KeyValue);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Non_Preprogram_Safe_Erase_All_Retry", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_RDTSetting.Non_Preprogram_Safe_Erase_All_Retry = ::atoi(KeyValue);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Endurance", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_RDTSetting.Endurance = ::atoi(KeyValue);

        

    /*
    Read_INI_File(pSection, "Remote_IP", Buffer, sizeof(Buffer), "", this->m_INI_Full_Name);
    ::strncpy(this->m_RDT_INI_Setting.Remote_IP, Buffer, sizeof(this->m_RDT_INI_Setting.Remote_IP) - 1);
    
    Read_INI_File(pSection, "Local_Path", Buffer, sizeof(Buffer), "", this->m_INI_Full_Name);
    ::strncpy(this->m_RDT_INI_Setting.Local_Path, Buffer, sizeof(this->m_RDT_INI_Setting.Local_Path) - 1);
    
    Read_INI_File(pSection, "Enable_Check", Buffer, sizeof(Buffer), "1", this->m_INI_Full_Name);
    this->m_RDT_INI_Setting.Enable_Check = (::atoi(Buffer) == 0) ? false : true;
	*/

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Log_Event_Log", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "1");  // default value
	}
	this->m_RDTSetting.Is_Log_Event_Log = (::atoi(KeyValue) == 0) ? false : true;

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Recv_Drv_Num_By_UI", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "1");  // default value
	}
	this->m_RDTSetting.Is_Recv_Drv_Num_By_UI = (::atoi(KeyValue) == 0) ? false : true;

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Nand_Phy_Calibration", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "1");  // default value
	}
	this->m_RDTSetting.Nand_Phy_Calibration = ::atoi(KeyValue);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Bypass_Preprogram", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_RDTSetting.Bypass_Preprogram = ::atoi(KeyValue);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Read_Sorting_Table", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_RDTSetting.Is_Read_Sorting_Table = (::atoi(KeyValue) == 0) ? false : true;

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "User_FW_Revision", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "");  // default value
	}

	CopyLen = ::strlen(KeyValue);
    if (CopyLen > 8) {
        CopyLen = 8;
    }
	::strncpy(this->m_RDTSetting.User_FW_Revision, KeyValue, CopyLen);
    
	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Too_Many_Defect_Error_Safe_Erase", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_RDTSetting.Is_Too_Many_Defect_Error_Safe_Erase = (::atoi(KeyValue) == 0) ? false : true;

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Read_Log_Ext_Mode", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "1");  // default value
	}
	this->m_RDTSetting.Read_Log_Ext_Mode = ::atoi(KeyValue);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "DA_Read", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_RDTSetting.DA_Read = ::atoi(KeyValue);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "ADATA_Scan_DF_Mode", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_RDTSetting.ADATA_Scan_DF_Mode = ::atoi(KeyValue);


	return 0;
}

//-------------------------------------------------------------------------------------------------
int CdlgSettingPage2::SaveRDTSetting()
{
	char  SectionName[64];
	char  KeyValue[MAX_PATH];
    int   Rslt;
	

    //========================================================
	//                   [SSD_Info]
	//========================================================
	::memset(SectionName, 0, sizeof(SectionName));
	::strcpy(SectionName, "SSD_Info");


	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "BOM_No", this->m_RDTSetting.BOM_No);
	if (Rslt != 0) {
	}
	
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "Controller_Name", this->m_RDTSetting.Controller_Name);
	if (Rslt != 0) {
	}
	
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "Model_Name", this->m_RDTSetting.Model_Name);
	if (Rslt != 0) {
	}
	
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "Controller_Vendor", this->m_RDTSetting.Controller_Vendor);
	if (Rslt != 0) {
	
	}
	
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "Chamber_Port_ID", this->m_RDTSetting.Chamber_Port_ID);
	if (Rslt != 0) {
	}


	//========================================================
    //                  [Tool_Info]
    //========================================================
	::memset(SectionName, 0, sizeof(SectionName));
	::strcpy(SectionName, "Tool_Info");
    
    
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "Firmware_Version", this->m_RDTSetting.Firmware_Version);
	if (Rslt != 0) {
	}
	
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "Tool_Name", this->m_RDTSetting.Tool_Name);
	if (Rslt != 0) {
	}

	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "Tool_Vendor", this->m_RDTSetting.Tool_Vendor);
	if (Rslt != 0) {
	}


	//========================================================
    //              [Firmware_Bin_File_Path]
    //========================================================
	::memset(SectionName, 0, sizeof(SectionName));
	::strcpy(SectionName, "Firmware_Bin_File_Path");

	
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "Burner", this->m_RDTSetting.Burner_Path);
	if (Rslt != 0) {
	}


	//========================================================
    //                  [Test_Condition]
    //========================================================
	::memset(SectionName, 0, sizeof(SectionName));
	::strcpy(SectionName, "Test_Condition");
    
	
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "Previous_Stage", this->m_RDTSetting.Previous_Stage);
	if (Rslt != 0) {
	}
	
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "Current_Stage", this->m_RDTSetting.Current_Stage);
	if (Rslt != 0) {
	}


	// common
	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.Mark_Bad);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "Mark_Bad", KeyValue);
	if (Rslt != 0) {
	}

	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.MP_Test);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "MP_Test", KeyValue);
	if (Rslt != 0) {
	
	}	 

	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.Preload_Data);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "Preload_Data", KeyValue);
	if (Rslt != 0) {
	}

	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.Bad_Sample_Block_Per_CE);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "Bad_Sample_Block_Per_CE", KeyValue);
	if (Rslt != 0) {
	}

	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.LED_Mode);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "LED_Mode", KeyValue);
	if (Rslt != 0) {
	}

	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.Pattern_Mode);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "Pattern_Mode", KeyValue);
	if (Rslt != 0) {
	}


    // TLC full die
	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.TLC_Full_Die_Cycles);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "TLC_Full_Die_Cycles", KeyValue);
	if (Rslt != 0) {
	}

	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.TLC_Full_Die_ECC_Log_Interval);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "TLC_Full_Die_ECC_Log_Interval", KeyValue);
	if (Rslt != 0) {
	}

	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.TLC_Full_Die_ECC_Bit_Threshold);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "TLC_Full_Die_ECC_Bit_Threshold", KeyValue);
	if (Rslt != 0) {
	}

	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.Bypass_SLC_Weru_For_TLC_Full_Die_Test);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "Bypass_SLC_Weru_For_TLC_Full_Die_Test", KeyValue);
	if (Rslt != 0) {
	}


	// SLC full die
	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.SLC_Full_Die_Cycles);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "SLC_Full_Die_Cycles", KeyValue);
	if (Rslt != 0) {
	}

	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.SLC_Full_Die_ECC_Log_Interval);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "SLC_Full_Die_ECC_Log_Interval", KeyValue);
	if (Rslt != 0) {
	}

	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.SLC_Full_Die_ECC_Bit_Threshold);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "SLC_Full_Die_ECC_Bit_Threshold", KeyValue);
	if (Rslt != 0) {
	}


    // TLC sampling
	::memset(KeyValue, 0, sizeof(KeyValue));
	if ((this->m_RDTSetting.TLC_Dwell_Time % 10) == 0) {
		::sprintf(KeyValue, "%d", (this->m_RDTSetting.TLC_Dwell_Time / 10));
	}
	else {
		::sprintf(KeyValue, "%d.%d", (this->m_RDTSetting.TLC_Dwell_Time / 10), (this->m_RDTSetting.TLC_Dwell_Time % 10));
	}
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "TLC_Dwell_Time", KeyValue);
	if (Rslt != 0) {
	}
	
	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.TLC_Sampling_Cycle);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "TLC_Sampling_Cycle", KeyValue);
	if (Rslt != 0) {
	}


	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.TLC_ECC_Log_Interval);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "TLC_ECC_Log_Interval", KeyValue);
	if (Rslt != 0) {
	}

	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.TLC_Start_Select_Block);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "TLC_Start_Select_Block", KeyValue);
	if (Rslt != 0) {
	}

	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.TLC_End_Select_Block);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "TLC_End_Select_Block", KeyValue);
	if (Rslt != 0) {
	}
    

	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.TLC_Random_Block);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "TLC_Random_Block", KeyValue);
	if (Rslt != 0) {
	}

	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.TLC_Sampling_Block_Quantity);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "TLC_Sampling_Block_Quantity", KeyValue);
	if (Rslt != 0) {
	}

	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.TLC_Sampling_ECC_Bit_Threshold);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "TLC_Sampling_ECC_Bit_Threshold", KeyValue);
	if (Rslt != 0) {
	}


    // SLC sampling
	::memset(KeyValue, 0, sizeof(KeyValue));
	if ((this->m_RDTSetting.SLC_Dwell_Time % 10) == 0) {
		::sprintf(KeyValue, "%d", (this->m_RDTSetting.SLC_Dwell_Time / 10));
	}
	else {
		::sprintf(KeyValue, "%d.%d", (this->m_RDTSetting.SLC_Dwell_Time / 10), (this->m_RDTSetting.SLC_Dwell_Time % 10));
	}
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "SLC_Dwell_Time", KeyValue);
	if (Rslt != 0) {
	}

	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.SLC_Sampling_Cycle);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "SLC_Sampling_Cycle", KeyValue);
	if (Rslt != 0) {
	}

	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.SLC_ECC_Log_Interval);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "SLC_ECC_Log_Interval", KeyValue);
	if (Rslt != 0) {
	}

	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.SLC_Random_Block);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "SLC_Random_Block", KeyValue);
	if (Rslt != 0) {
	}

	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.SLC_Sampling_Block_Quantity);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "SLC_Sampling_Block_Quantity", KeyValue);
	if (Rslt != 0) {
	}

	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.SLC_Start_Select_Block);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "SLC_Start_Select_Block", KeyValue);
	if (Rslt != 0) {
	}

	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.SLC_End_Select_Block);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "SLC_End_Select_Block", KeyValue);
	if (Rslt != 0) {
	}
	
	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.SLC_Sampling_ECC_Bit_Threshold);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "SLC_Sampling_ECC_Bit_Threshold", KeyValue);
	if (Rslt != 0) {
	}


	//========================================================
    //              [Production_Setting]
    //========================================================
	::memset(SectionName, 0, sizeof(SectionName));
	::strcpy(SectionName, "Production_Setting");
    

	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.Serial_Number);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "Serial_Number", KeyValue);
	if (Rslt != 0) {
	}

	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.SN_Length);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "SN_Length", KeyValue);
	if (Rslt != 0) {
	}

	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "SKU", this->m_RDTSetting.SKU);
	if (Rslt != 0) {
	}


	//========================================================
    //                  [MP_Option]
    //========================================================
	::memset(SectionName, 0, sizeof(SectionName));
	::strcpy(SectionName, "MP_Option");


	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.Is_Force_Erase_All);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "Force_Erase_All", KeyValue);
	if (Rslt != 0) {
	}

	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.Is_Keep_Setting);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "Keep_Setting", KeyValue);
	if (Rslt != 0) {
	}

	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.Is_Backup_Table);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "Backup_Table", KeyValue);
	if (Rslt != 0) {
	}

	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.Is_Ignore_Scan_Later_Defect);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "Ignore_Scan_Later_Defect", KeyValue);
	if (Rslt != 0) {
	}
	
	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.Good_Block_Per_Plane);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "Good_Block_Per_Plane", KeyValue);
	if (Rslt != 0) {
	}

	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.Total_Good_WERU);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "Total_Good_WERU", KeyValue);
	if (Rslt != 0) {
	}

	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.Replace_Table_Bit_Map);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "Replace_Table_Bit_Map", KeyValue);
	if (Rslt != 0) {
	}

	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.Mark_Bad_Sampling_Block);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "Mark_Bad_Sampling_Block", KeyValue);
	if (Rslt != 0) {
	}

	/*
	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.CE_Count);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "CE_Count", KeyValue);
	if (Rslt != 0) {
	}

	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%X %X %X %X %X %X", this->m_RDTSetting.Flash_ID[0],
		                                     this->m_RDTSetting.Flash_ID[1],
											 this->m_RDTSetting.Flash_ID[2],
											 this->m_RDTSetting.Flash_ID[3],
											 this->m_RDTSetting.Flash_ID[4],
											 this->m_RDTSetting.Flash_ID[5]);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "Flash_ID", KeyValue);
	if (Rslt != 0) {
	}
	*/

	/*	
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "Manual_Mark_Bad_Table", this->m_RDTSetting.Manual_Mark_Bad_Table_Full_Path_Name);
	if (Rslt != 0) {
	}
	*/

	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.Download_FW_Retry);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "Download_FW_Retry", KeyValue);
	if (Rslt != 0) {
	}

	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.Non_Preprogram_Safe_Erase_All_Retry);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "Non_Preprogram_Safe_Erase_All_Retry", KeyValue);
	if (Rslt != 0) {
	}

	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.Endurance);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "Endurance", KeyValue);
	if (Rslt != 0) {
	}

    /*
    Read_INI_File(pSection, "Remote_IP", Buffer, sizeof(Buffer), "", this->m_INI_Full_Name);
    ::strncpy(this->m_RDT_INI_Setting.Remote_IP, Buffer, sizeof(this->m_RDT_INI_Setting.Remote_IP) - 1);
    
    Read_INI_File(pSection, "Local_Path", Buffer, sizeof(Buffer), "", this->m_INI_Full_Name);
    ::strncpy(this->m_RDT_INI_Setting.Local_Path, Buffer, sizeof(this->m_RDT_INI_Setting.Local_Path) - 1);
    
    Read_INI_File(pSection, "Enable_Check", Buffer, sizeof(Buffer), "1", this->m_INI_Full_Name);
    this->m_RDT_INI_Setting.Enable_Check = (::atoi(Buffer) == 0) ? false : true;
	*/

	/*
	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.Is_Log_Event_Log);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "Log_Event_Log", KeyValue);
	if (Rslt != 0) {
	}
	*/

	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.Is_Recv_Drv_Num_By_UI);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "Recv_Drv_Num_By_UI", KeyValue);
	if (Rslt != 0) {
	}

	/*
	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.Nand_Phy_Calibration);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "Nand_Phy_Calibration", KeyValue);
	if (Rslt != 0) {
	}
	*/

	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.Bypass_Preprogram);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "Bypass_Preprogram", KeyValue);
	if (Rslt != 0) {
	}

	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.Is_Read_Sorting_Table);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "Read_Sorting_Table", KeyValue);
	if (Rslt != 0) {
	}
	
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "User_FW_Revision", this->m_RDTSetting.User_FW_Revision);
	if (Rslt != 0) {
	}

	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.Is_Too_Many_Defect_Error_Safe_Erase);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "Too_Many_Defect_Error_Safe_Erase", KeyValue);
	if (Rslt != 0) {
	}

	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.Read_Log_Ext_Mode);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "Read_Log_Ext_Mode", KeyValue);
	if (Rslt != 0) {
	}

	/*
	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.DA_Read);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "DA_Read", KeyValue);
	if (Rslt != 0) {
	}

	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_RDTSetting.ADATA_Scan_DF_Mode);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "ADATA_Scan_DF_Mode", KeyValue);
	if (Rslt != 0) {
	}
	*/

    return 0;
}

//-------------------------------------------------------------------------------------------------
int CdlgSettingPage2::ReadMPSetting()
{

	char  SectionName[64];
	char  KeyValue[256];
	int   CopyLen;
    int   Rslt;


    ::memset(&this->m_MPSetting, 0, sizeof(this->m_MPSetting));

	//========================================================
	//                 [SSD_Info] section
	//========================================================
	::memset(SectionName, 0, sizeof(SectionName));
	::strcpy(SectionName, "SSD_Info");


	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "BOM_No", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "");  // default value
	}
	::strncpy(this->m_MPSetting.BOM_No, KeyValue, sizeof(this->m_MPSetting.BOM_No));

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Controller_Name", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "");  // default value
	}
	::strncpy(this->m_MPSetting.Controller_Name, KeyValue, sizeof(this->m_MPSetting.Controller_Name));

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Model_Name", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "");  // default value
	}

	CopyLen = ::strlen(KeyValue);
    if (CopyLen > MODEL_NUMBER_LEN) {
        CopyLen = MODEL_NUMBER_LEN;
    }

	::strncpy(this->m_MPSetting.Model_Name, KeyValue, CopyLen);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Controller_Vendor", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "");  // default value
	}
	::strncpy(this->m_MPSetting.Controller_Vendor, KeyValue, sizeof(this->m_MPSetting.Controller_Vendor));

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Chamber_Port_ID", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "");  // default value
	}
	::strncpy(this->m_MPSetting.Chamber_Port_ID, KeyValue, sizeof(this->m_MPSetting.Chamber_Port_ID));


	//========================================================
    //              read section [Tool_Info]
    //========================================================
	::memset(SectionName, 0, sizeof(SectionName));
	::strcpy(SectionName, "Tool_Info");
    
        
	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Firmware_Version", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "");  // default value
	}
	::strncpy(this->m_MPSetting.Firmware_Version, KeyValue, sizeof(this->m_MPSetting.Firmware_Version));
	
	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Tool_Name", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "");  // default value
	}
	::strncpy(this->m_MPSetting.Tool_Name, KeyValue, sizeof(this->m_MPSetting.Tool_Name));

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Tool_Vendor", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "");  // default value
	}
	::strncpy(this->m_MPSetting.Tool_Vendor, KeyValue, sizeof(this->m_MPSetting.Tool_Vendor));
    
    
    //========================================================
    //          read section [Test_Condition]
    //========================================================
	::memset(SectionName, 0, sizeof(SectionName));
	::strcpy(SectionName, "Test_Condition");
    
    
	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Previous_Stage", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "");  // default value
	}
	::strncpy(this->m_MPSetting.Previous_Stage, KeyValue, sizeof(this->m_MPSetting.Previous_Stage));

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Current_Stage", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "");  // default value
	}
	::strncpy(this->m_MPSetting.Current_Stage, KeyValue, sizeof(this->m_MPSetting.Current_Stage));
    
    ::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Preload_Data", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_MPSetting.Preload_Data = ::atoi(KeyValue);


    //========================================================
    //        read section [Production_Setting]
    //========================================================
	::memset(SectionName, 0, sizeof(SectionName));
	::strcpy(SectionName, "Production_Setting");
    

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Serial_Number", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_MPSetting.Serial_Number = ::atoi(KeyValue);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "SN_Length", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_MPSetting.SN_Length = ::atoi(KeyValue);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "SKU", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "");  // default value
	}
	::strncpy(this->m_MPSetting.SKU, KeyValue, sizeof(this->m_RDTSetting.SKU));

    
    //========================================================
    //        read section [Firmware_Bin_File_Path]
    //========================================================
	::memset(SectionName, 0, sizeof(SectionName));
	::strcpy(SectionName, "Firmware_Bin_File_Path");


	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Burner", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "");  // default value
	}
	::strncpy(this->m_MPSetting.Burner_Path, KeyValue, sizeof(this->m_MPSetting.Burner_Path));
    

    //========================================================
    //            read section [MP_Option]
    //========================================================
    ::memset(SectionName, 0, sizeof(SectionName));
	::strcpy(SectionName, "MP_Option");


	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Force_Erase_All", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_MPSetting.Is_Force_Erase_All = (::atoi(KeyValue) == 0) ? false : true;

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Is_Force_ReMP", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_MPSetting.Is_Force_ReMP = (::atoi(KeyValue) == 0) ? false : true;

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Ignore_RDT_Result", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_MPSetting.Is_Ignore_RDT_Result = (::atoi(KeyValue) == 0) ? false : true;

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Read_RDT_Result_Only", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_MPSetting.Is_Read_RDT_Result_Only = (::atoi(KeyValue) == 0) ? false : true;

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Keep_Setting", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_MPSetting.Is_Keep_Setting = (::atoi(KeyValue) == 0) ? false : true;

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Backup_Table", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "1");  // default value
	}
	this->m_MPSetting.Is_Backup_Table = (::atoi(KeyValue) == 0) ? false : true;
    
    ::memset(this->m_MPSetting.Backup_Table_Folder_Full_Path_Name, 0, sizeof(this->m_MPSetting.Backup_Table_Folder_Full_Path_Name));
    ::sprintf(this->m_MPSetting.Backup_Table_Folder_Full_Path_Name, "./table");

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Ignore_Scan_Later_Defect", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_MPSetting.Is_Ignore_Scan_Later_Defect = (::atoi(KeyValue) == 0) ? false : true;

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Good_Block_Per_Plane", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "1395");  // default value
	}
	this->m_MPSetting.Good_Block_Per_Plane = ::atoi(KeyValue);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Total_Good_WERU", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "101");  // default value
	}
	this->m_MPSetting.Total_Good_WERU = ::atoi(KeyValue);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Replace_Table_Bit_Map", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_MPSetting.Replace_Table_Bit_Map = ::atoi(KeyValue);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Max_Grown_Defect_Per_Plane", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "5");  // default value
	}
	this->m_MPSetting.Max_Grown_Defect_Per_Plane = ::atoi(KeyValue);

    ::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Total_Grown_Defect", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_MPSetting.Total_Grown_Defect = ::atoi(KeyValue);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "CE_Count", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_MPSetting.CE_Count = ::atoi(KeyValue);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Flash_ID", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "");  // default value
	}
	this->ParseFlashIdString(KeyValue, this->m_MPSetting.Flash_ID);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Manual_Mark_Bad_Table", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "");  // default value
	}
	::strncpy(this->m_MPSetting.Manual_Mark_Bad_Table_Full_Path_Name, KeyValue, sizeof(this->m_MPSetting.Manual_Mark_Bad_Table_Full_Path_Name));

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Download_FW_Retry", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_MPSetting.Download_FW_Retry = ::atoi(KeyValue);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Non_Preprogram_Safe_Erase_All_Retry", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_MPSetting.Non_Preprogram_Safe_Erase_All_Retry = ::atoi(KeyValue);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Endurance", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_MPSetting.Endurance = ::atoi(KeyValue);

	/*
    Read_INI_File(pSection, "Remote_IP", Buffer, sizeof(Buffer), "", this->m_INI_Full_Name);
    ::strncpy(this->m_MP_INI_Setting.Remote_IP, Buffer, sizeof(this->m_MP_INI_Setting.Remote_IP) - 1);
    
    Read_INI_File(pSection, "Local_Path", Buffer, sizeof(Buffer), "", this->m_INI_Full_Name);
    ::strncpy(this->m_MP_INI_Setting.Local_Path, Buffer, sizeof(this->m_MP_INI_Setting.Local_Path) - 1);
    
    Read_INI_File(pSection, "Enable_Check", Buffer, sizeof(Buffer), "1", this->m_INI_Full_Name);
    this->m_MP_INI_Setting.Enable_Check = (::atoi(Buffer) == 0) ? false : true;
	*/
    
	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Log_Event_Log", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "1");  // default value
	}
	this->m_MPSetting.Is_Log_Event_Log = (::atoi(KeyValue) == 0) ? false : true;

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Recv_Drv_Num_By_UI", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "1");  // default value
	}
	this->m_MPSetting.Is_Recv_Drv_Num_By_UI = (::atoi(KeyValue) == 0) ? false : true;

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Nand_Phy_Calibration", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "1");  // default value
	}
	this->m_MPSetting.Nand_Phy_Calibration = ::atoi(KeyValue);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Bypass_Preprogram", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_MPSetting.Bypass_Preprogram = ::atoi(KeyValue);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Read_Sorting_Table", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_MPSetting.Is_Read_Sorting_Table = (::atoi(KeyValue) == 0) ? false : true;

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "User_FW_Revision", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "");  // default value
	}

	CopyLen = ::strlen(KeyValue);
    if (CopyLen > 8) {
        CopyLen = 8;
    }
	::strncpy(this->m_MPSetting.User_FW_Revision, KeyValue, CopyLen);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Too_Many_Defect_Error_Safe_Erase", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_MPSetting.Is_Too_Many_Defect_Error_Safe_Erase = (::atoi(KeyValue) == 0) ? false : true;

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "Read_Log_Ext_Mode", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "1");  // default value
	}
	this->m_MPSetting.Read_Log_Ext_Mode = ::atoi(KeyValue);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "DA_Read", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_MPSetting.DA_Read = ::atoi(KeyValue);

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(this->m_IniFullPath, SectionName, "ADATA_Scan_DF_Mode", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_MPSetting.ADATA_Scan_DF_Mode = ::atoi(KeyValue);


    return 0;
}

//-------------------------------------------------------------------------------------------------
int CdlgSettingPage2::SaveMPSetting()
{
	char  SectionName[64];
	char  KeyValue[MAX_PATH];
    int   Rslt;
	

    //========================================================
	//                 [SSD_Info] section
	//========================================================
	::memset(SectionName, 0, sizeof(SectionName));
	::strcpy(SectionName, "SSD_Info");


	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "BOM_No", this->m_MPSetting.BOM_No);
	if (Rslt != 0) {
	}
	
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "Controller_Name", this->m_MPSetting.Controller_Name);
	if (Rslt != 0) {
	}
	
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "Model_Name", this->m_MPSetting.Model_Name);
	if (Rslt != 0) {
	}
	
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "Controller_Vendor", this->m_MPSetting.Controller_Vendor);
	if (Rslt != 0) {
	
	}
	
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "Chamber_Port_ID", this->m_MPSetting.Chamber_Port_ID);
	if (Rslt != 0) {
	}


	//===============================================
    //        read section [MP_Option]
    //===============================================
	::memset(SectionName, 0, sizeof(SectionName));
	::strcpy(SectionName, "MP_Option");


	::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_MPSetting.Is_Force_Erase_All);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "Force_Erase_All", KeyValue);
	if (Rslt != 0) {
	}

    ::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_MPSetting.Max_Grown_Defect_Per_Plane);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "Max_Grown_Defect_Per_Plane", KeyValue);
	if (Rslt != 0) {
	}

    ::memset(KeyValue, 0, sizeof(KeyValue));
	::sprintf(KeyValue, "%d", this->m_MPSetting.Total_Grown_Defect);
	Rslt = this->m_FileManager.WriteIniFile(this->m_IniFullPath, SectionName, "Total_Grown_Defect", KeyValue);
	if (Rslt != 0) {
	}

    return 0;
}

//-------------------------------------------------------------------------------------------------
int CdlgSettingPage2::GetTaskByParseINI(IN char *pIniFullPath, OUT int *pTask)
{
    char  SectionName[64];
	char  KeyValue[256];
    int   Rslt;

    
	::memset(SectionName, 0, sizeof(SectionName));
	::strcpy(SectionName, "Test_Condition");

	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(pIniFullPath, SectionName, "Current_Stage", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}

    if (::stricmp(KeyValue, "FTA") == 0) {
        *pTask = FTA_FLOW;
    }
    else if (::stricmp(KeyValue, "FTB") == 0) {
        *pTask = FTB_FLOW;
    }
    else {
        *pTask = UNKNOW_TASK;
    }

    return 0;
}

//-------------------------------------------------------------------------------------------------
int CdlgSettingPage2::ParseString(IN char *pString, OUT int *pInteger, OUT int *pDecimal)
{
    int   String_Length;
    char  *pPoint;
    char  Temp[16];
    
    
    String_Length = ::strlen(pString);
    pPoint = ::strchr(pString, '.');

    if (pPoint == NULL) {
        *pInteger = ::atoi(pString);
        *pDecimal = 0;        
    }
    else {
        ::memset(Temp, 0, sizeof(Temp));
        ::strncpy(Temp, pString, String_Length - ::strlen(pPoint));
        *pInteger = ::atoi(Temp);
        
        ::memset(Temp, 0, sizeof(Temp));
        ::strncpy(Temp, pPoint + 1, 1);  // only one decimal place
        *pDecimal = ::atoi(Temp);
    }
    
    return 0;
}

//-------------------------------------------------------------------------------------------------
int CdlgSettingPage2::ParseFlashIdString(IN char *pString, OUT BYTE *pFlashID)
{
    BYTE  TempID[FLASH_ID_LENGTH + 1];


    if (::strlen(pString) == 0) {
        return 1;
    }
    
    ::sscanf(pString, "%2hx %2hx %2hx %2hx %2hx %2hx", &TempID[0],
                                                       &TempID[1],
                                                       &TempID[2],
                                                       &TempID[3],
                                                       &TempID[4],
                                                       &TempID[5]);

    ::memcpy(pFlashID, TempID, FLASH_ID_LENGTH);

    return 0;
}

//-------------------------------------------------------------------------------------------------
void CdlgSettingPage2::EnableRDTGroupCtrl(IN BOOL IsEnable)
{
	GetDlgItem(IDC_GROUP_RDT)->EnableWindow(IsEnable);
	GetDlgItem(IDC_GROUP_FULL_DIE)->EnableWindow(IsEnable);


	// TLC full die
	GetDlgItem(IDC_STATIC_TLC_FULL_DIE_CYCLE)->EnableWindow(IsEnable);
	GetDlgItem(IDC_EDIT_TLC_FULL_DIE_CYCLE)->EnableWindow(IsEnable);
    GetDlgItem(IDC_STATIC_TLC_FULL_DIE_ECC_LOG_INTERVAL)->EnableWindow(IsEnable);
	GetDlgItem(IDC_EDIT_TLC_FULL_DIE_ECC_LOG_INTERVAL)->EnableWindow(IsEnable);
	GetDlgItem(IDC_STATIC_TLC_FULL_DIE_ECC_BIT)->EnableWindow(IsEnable);
	GetDlgItem(IDC_EDIT_TLC_FULL_DIE_ECC_BIT)->EnableWindow(IsEnable);
	GetDlgItem(IDC_STATIC_BYPASS_SLC_BLOCK_COUNT)->EnableWindow(IsEnable);
	GetDlgItem(IDC_EDIT_BYPASS_SLC_BLOCK_COUNT)->EnableWindow(IsEnable);


	// SLC full die
	GetDlgItem(IDC_STATIC_SLC_FULL_DIE_CYCLE)->EnableWindow(IsEnable);
	GetDlgItem(IDC_EDIT_SLC_FULL_DIE_CYCLE)->EnableWindow(IsEnable);
    GetDlgItem(IDC_STATIC_SLC_FULL_DIE_ECC_LOG_INTERVAL)->EnableWindow(IsEnable);
	GetDlgItem(IDC_EDIT_SLC_FULL_DIE_ECC_LOG_INTERVAL)->EnableWindow(IsEnable);
	GetDlgItem(IDC_STATIC_SLC_FULL_DIE_ECC_BIT)->EnableWindow(IsEnable);
	GetDlgItem(IDC_EDIT_SLC_FULL_DIE_ECC_BIT)->EnableWindow(IsEnable);	


	GetDlgItem(IDC_GROUP_SAMPLING)->EnableWindow(IsEnable);


	// TLC sampling
	GetDlgItem(IDC_STATIC_TLC_SAMPLING_CYCLE)->EnableWindow(IsEnable);
	GetDlgItem(IDC_STATIC_TLC_DWELL_TIME)->EnableWindow(IsEnable);
	GetDlgItem(IDC_STATIC_TLC_LOG_INTERVAL)->EnableWindow(IsEnable);
	GetDlgItem(IDC_STATIC_TLC_START_SELECT_BLOCK)->EnableWindow(IsEnable);
	GetDlgItem(IDC_STATIC_TLC_END_SELECT_BLOCK)->EnableWindow(IsEnable);
	GetDlgItem(IDC_STATIC_TLC_QUANTITY)->EnableWindow(IsEnable);
	GetDlgItem(IDC_STATIC_TLC_RANDOM_BLOCK)->EnableWindow(IsEnable);
	GetDlgItem(IDC_STATIC_TLC_SAMPLING_ECC_BIT)->EnableWindow(IsEnable);

	GetDlgItem(IDC_EDIT_TLC_SAMPLING_CYCLE)->EnableWindow(IsEnable);
	GetDlgItem(IDC_EDIT_TLC_DWELL_TIME)->EnableWindow(IsEnable);
	GetDlgItem(IDC_EDIT_TLC_LOG_INTERVAL)->EnableWindow(IsEnable);
	GetDlgItem(IDC_EDIT_TLC_START_SELECT_BLOCK)->EnableWindow(IsEnable);
	GetDlgItem(IDC_EDIT_TLC_END_SELECT_BLOCK)->EnableWindow(IsEnable);
	GetDlgItem(IDC_EDIT_TLC_QUANTITY)->EnableWindow(IsEnable);
	GetDlgItem(IDC_COMBO_TLC_RANDOM_BLOCK)->EnableWindow(IsEnable);
	GetDlgItem(IDC_EDIT_TLC_SAMPLING_ECC_BIT)->EnableWindow(IsEnable);


	// SLC sampling
	GetDlgItem(IDC_STATIC_SLC_SAMPLING_CYCLE)->EnableWindow(IsEnable);
	GetDlgItem(IDC_STATIC_SLC_DWELL_TIME)->EnableWindow(IsEnable);
	GetDlgItem(IDC_STATIC_SLC_LOG_INTERVAL)->EnableWindow(IsEnable);
	GetDlgItem(IDC_STATIC_SLC_START_SELECT_BLOCK)->EnableWindow(IsEnable);
	GetDlgItem(IDC_STATIC_SLC_END_SELECT_BLOCK)->EnableWindow(IsEnable);
	GetDlgItem(IDC_STATIC_SLC_QUANTITY)->EnableWindow(IsEnable);
	GetDlgItem(IDC_STATIC_SLC_RANDOM_BLOCK)->EnableWindow(IsEnable);
	GetDlgItem(IDC_STATIC_SLC_SAMPLING_ECC_BIT)->EnableWindow(IsEnable);

	GetDlgItem(IDC_EDIT_SLC_SAMPLING_CYCLE)->EnableWindow(IsEnable);
	GetDlgItem(IDC_EDIT_SLC_DWELL_TIME)->EnableWindow(IsEnable);
	GetDlgItem(IDC_EDIT_SLC_LOG_INTERVAL)->EnableWindow(IsEnable);
	GetDlgItem(IDC_EDIT_SLC_START_SELECT_BLOCK)->EnableWindow(IsEnable);
	GetDlgItem(IDC_EDIT_SLC_END_SELECT_BLOCK)->EnableWindow(IsEnable);
	GetDlgItem(IDC_EDIT_SLC_QUANTITY)->EnableWindow(IsEnable);
	GetDlgItem(IDC_COMBO_SLC_RANDOM_BLOCK)->EnableWindow(IsEnable);
	GetDlgItem(IDC_EDIT_SLC_SAMPLING_ECC_BIT)->EnableWindow(IsEnable);
			
	return;
}

//-------------------------------------------------------------------------------------------------
void CdlgSettingPage2::EnableMPGroupCtrl(IN BOOL IsEnable)
{
    GetDlgItem(IDC_STATIC_MAX_GROWN_DEFECT_PER_PLANE)->EnableWindow(IsEnable);
    GetDlgItem(IDC_EDIT_MAX_GROWN_DEFECT_PER_PLANE)->EnableWindow(IsEnable);
    GetDlgItem(IDC_STATIC_TOTAL_GROWN_DEFECT)->EnableWindow(IsEnable);
    GetDlgItem(IDC_EDIT_TOTAL_GROWN_DEFECT)->EnableWindow(IsEnable);

    return;
}

//-------------------------------------------------------------------------------------------------

