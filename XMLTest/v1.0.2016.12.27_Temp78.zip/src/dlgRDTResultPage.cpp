// dlgRDTResultPage.cpp : implementation file
//

#include "stdafx.h"
#include "SSDMP.h"
#include "dlgRDTResultPage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


//-------------------------------------------------------------------------------------------------
enum ENUM_RDT_LIST_CTRL_COLUMN_INDEX
{
	FAIL_TYPE_INDEX,
	BAD_SEQ_INDEX,
	LOOP_INDEX,
	MODE_INDEX,
	BLOCK_INDEX,
	MAX_ECC_INDEX,
	CH_INDEX,
	CE_INDEX,
	LUN_INDEX,
	PLANE_INDEX,
	TEMP_INDEX,
};

enum ENUM_DEFECT_LIST_CTRL_COLUMN_INDEX
{
	DF_CH_INDEX,
	DF_CE_INDEX,
	DF_COUNT_INDEX,
};


LIST_CTRL_FORMAT g_RDTListCtrlFormat[] =
{
	// column caption  alignment       column width  column index
	{"Fail Type",      LVCFMT_CENTER,  135,          FAIL_TYPE_INDEX},
	{"Bad Seq",        LVCFMT_CENTER,  75,           BAD_SEQ_INDEX},
	{"Loop",           LVCFMT_CENTER,  70,           LOOP_INDEX},
	{"Mode",           LVCFMT_CENTER,  115,          MODE_INDEX},
	{"Block",          LVCFMT_CENTER,  80,           BLOCK_INDEX},
	{"MAX ECC",        LVCFMT_CENTER,  85,           MAX_ECC_INDEX},
	{"CH",             LVCFMT_CENTER,  45,           CH_INDEX},
	{"CE",             LVCFMT_CENTER,  45,           CE_INDEX},
	{"LUN",            LVCFMT_CENTER,  50,           LUN_INDEX},
	{"Plane",          LVCFMT_CENTER,  60,           PLANE_INDEX},
	{"Temp.",          LVCFMT_CENTER,  55,           TEMP_INDEX},
};


LIST_CTRL_FORMAT g_DefectListCtrlFormat[] =
{
	// column caption  alignment       column width  column index
	{"CH",             LVCFMT_CENTER,  40,           DF_CH_INDEX},
	{"CE",             LVCFMT_CENTER,  40,           DF_CE_INDEX},
	{"Count",          LVCFMT_CENTER,  80,           DF_COUNT_INDEX}
};


STATUS_DESCRIPTION g_StatusDescription[] =
{
	{"unknow mode",        COLOR_RED},
	{"rom safe mode",      COLOR_BLUE},
	{"burner mode",        COLOR_BLUE},
	{"RDT fw mode",        COLOR_BLUE},
	{"production fw mode", COLOR_BLUE}
};

//-------------------------------------------------------------------------------------------------


///////////////////////////////////////////////////////////////////////////////////////////////////
// CdlgRDTResultPage dialog


CdlgRDTResultPage::CdlgRDTResultPage(CWnd* pParent /*=NULL*/)
	: CDialog(CdlgRDTResultPage::IDD, pParent)
{
	//{{AFX_DATA_INIT(CdlgRDTResultPage)
	m_RadioDefect = GD_INDEX;
	//}}AFX_DATA_INIT
}

//-------------------------------------------------------------------------------------------------
void CdlgRDTResultPage::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CdlgRDTResultPage)
	DDX_Control(pDX, IDC_EDIT_STATUS, m_EditStatus);
	DDX_Control(pDX, IDC_LIST_DEFECT, m_ListCtrlDefect);
	DDX_Control(pDX, IDC_LIST_RSLT, m_ListCtrlRslt);
	DDX_Radio(pDX, IDC_RADIO_TOTAL_DEFECT, m_RadioDefect);
	//}}AFX_DATA_MAP
}


//-------------------------------------------------------------------------------------------------
BEGIN_MESSAGE_MAP(CdlgRDTResultPage, CDialog)
	//{{AFX_MSG_MAP(CdlgRDTResultPage)
	ON_BN_CLICKED(IDC_BTN_READ_RSLT, OnBtnReadRslt)
	ON_BN_CLICKED(IDC_RADIO_TOTAL_DEFECT, OnRadioTotalDefect)
	ON_BN_CLICKED(IDC_RADIO_FD, OnRadioFD)
	ON_BN_CLICKED(IDC_RADIO_GD, OnRadioGD)
	ON_CBN_SELCHANGE(IDC_COMBO_PORT, OnSelChangeComboPort)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

///////////////////////////////////////////////////////////////////////////////////////////////////
// CdlgRDTResultPage message handlers


//-------------------------------------------------------------------------------------------------
BOOL CdlgRDTResultPage::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	
	this->InitUI();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

//-------------------------------------------------------------------------------------------------
int CdlgRDTResultPage::Init(IN PORT_DATA *pPortData)
{
	CComboBox  *pComboBox;
	CString    Str;
	

	this->m_pPortData = pPortData;
	pComboBox = (CComboBox*)GetDlgItem(IDC_COMBO_PORT);
	pComboBox->ResetContent();

	for (int i = 0; i < SUPPORT_PORT_COUNT; i++) {
		if (this->m_pPortData[i].PhyDrvNum == -1) {
			continue;
		}

		Str.Format("Port %d", this->m_pPortData[i].MapIndex);
		pComboBox->AddString(Str);
	}

	pComboBox->SetCurSel(0);
	
	this->m_IsInitSucceed = false;
	//OnSelChangeComboPort();

	return 0;
}

//-------------------------------------------------------------------------------------------------
void CdlgRDTResultPage::InitUI()
{
	int ColumnCount;


	ColumnCount = sizeof(g_RDTListCtrlFormat) / sizeof(LIST_CTRL_FORMAT);
	this->InitListCtrl(&this->m_ListCtrlRslt, g_RDTListCtrlFormat, ColumnCount);


	ColumnCount = sizeof(g_DefectListCtrlFormat) / sizeof(LIST_CTRL_FORMAT);
	this->InitListCtrl(&this->m_ListCtrlDefect, g_DefectListCtrlFormat, ColumnCount);


	this->m_EditStatus.SetWindowText(_T(""));
	this->m_EditStatus.SetTextColor(COLOR_BLUE);

	return;
}

//-------------------------------------------------------------------------------------------------
void CdlgRDTResultPage::OnBtnReadRslt() 
{
	ShowProductionInfo();
}

//-------------------------------------------------------------------------------------------------
void CdlgRDTResultPage::InitListCtrl(IN CListCtrl *pListCtrl, IN LIST_CTRL_FORMAT *pListFormat, IN int ColumnCount)
{
	LV_COLUMN  lvcolumn;
	CRect      Rect;
	DWORD      ExStyle;
	int        i;


	// set style
	ExStyle = LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES;
	pListCtrl->SetExtendedStyle(ExStyle);


	// add columns according to window rect
	pListCtrl->GetWindowRect(&Rect);
	
	for (i = 0; i < ColumnCount; i++) {
		::memset(&lvcolumn, 0, sizeof(lvcolumn));

		lvcolumn.mask     = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
		lvcolumn.fmt      = pListFormat[i].Alignment;
		lvcolumn.pszText  = pListFormat[i].Title;
		lvcolumn.iSubItem = pListFormat[i].ColumnIndex;
		/*
		lvcolumn.cx       = ((Rect.Width() - 2) * g_DefectListCtrlFormat[i].Width) / 100;
		*/
		lvcolumn.cx = pListFormat[i].Width;
		pListCtrl->InsertColumn(pListFormat[i].ColumnIndex, &lvcolumn);
	}

	return;
}

//-------------------------------------------------------------------------------------------------
void CdlgRDTResultPage::ShowRDTRslt()
{
	CEdit    *pEdit;
	CString  StrTemp;
	char     Buffer[260];


	//==========================================================
	//              show RDT result to UI
	//==========================================================
	this->AllRDTRsltToListCtrl(&this->m_ListCtrlRslt, this->m_RDTManager.GetBlockInfo());


	//==========================================================
	//              show RDT setting to UI
	//==========================================================
	/*
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_RDT_SETTING_INFO);
	std::string *pSettingInfo = this->m_RDTManager.GetRDTSetting();
	pEdit->SetWindowText((*pSettingInfo).c_str());
	*/
	CString UserContent;

	std::string *pSettingInfo = this->m_RDTManager.GetRDTSetting();
	this->UserRDTSettingInfoFormat(pSettingInfo, &UserContent);

	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_RDT_SETTING_INFO);
	pEdit->SetWindowText(UserContent);



	//==========================================================
	//                show RDT done to UI
	//==========================================================
	bool  IsDone;

	IsDone = this->m_RDTManager.IsRDTDone();

	this->m_EditStatus.GetWindowText(StrTemp);
	if (IsDone == true) {
		StrTemp = "RDT fw mode (done)";
		this->m_EditStatus.SetWindowText(StrTemp);
		this->m_EditStatus.SetTextColor(COLOR_BLUE);
	}
	else {
		StrTemp = "RDT fw mode (not done)";
		this->m_EditStatus.SetWindowText(StrTemp);
		this->m_EditStatus.SetTextColor(COLOR_RED);
	}


	//==========================================================
	//               show RDT firmware version
	//==========================================================
	char *pSection;

	pSection = "Tool_Info";
    
	::memset(Buffer, 0, sizeof(Buffer));
    Read_INI_File_Ex(pSection, "Firmware_Version", Buffer, sizeof(Buffer), "", (*pSettingInfo).c_str());
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_FW_VERSION);
	pEdit->SetWindowText(Buffer);


	//==========================================================
	//              show total spend time to UI
	//==========================================================
	RDT_SPEND_TIME_INFO *pTimeInfo = this->m_RDTManager.GetSpendTimeInfo();
	
	::memset(Buffer, 0, sizeof(Buffer));
	CRDTResultManager::Convert_RDT_Time_To_String(pTimeInfo->Total_Spend_Time, 0, Buffer);
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_TOTAL_SPEND_TIME);
	pEdit->SetWindowText(Buffer);
	
	::memset(Buffer, 0, sizeof(Buffer));
	CRDTResultManager::Convert_RDT_Time_To_String(pTimeInfo->TLC_Full_Die_Spend_Time, 0, Buffer);
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_TLC_FULL_DIE_TIME);
	pEdit->SetWindowText(Buffer);
	
	::memset(Buffer, 0, sizeof(Buffer));
	CRDTResultManager::Convert_RDT_Time_To_String(pTimeInfo->SLC_Full_Die_Spend_Time, 0, Buffer);
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_SLC_FULL_DIE_TIME);
	pEdit->SetWindowText(Buffer);
	
	::memset(Buffer, 0, sizeof(Buffer));
	CRDTResultManager::Convert_RDT_Time_To_String(pTimeInfo->TLC_Sampling_Spend_Time, 0, Buffer);
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_TLC_SAMPLING_TIME);
	pEdit->SetWindowText(Buffer);

	::memset(Buffer, 0, sizeof(Buffer));
	CRDTResultManager::Convert_RDT_Time_To_String(pTimeInfo->SLC_Sampling_Spend_Time, 0, Buffer);
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_SLC_SAMPLING_TIME);
	pEdit->SetWindowText(Buffer);
	

	//==========================================================
	//             show temperature to UI
	//==========================================================
	int  MaxTemp;

	MaxTemp = this->m_RDTManager.GetMaxTemperature();
	StrTemp.Format("%d", MaxTemp);
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_MAX_TEMPERATURE);
	pEdit->SetWindowText(StrTemp);


	//==========================================================
	//             show test fail count to UI
	//==========================================================
	int  TotalFail;
	int  uECCFailCount;
	int  ProgramFailCount;
	int  EraseFailCount;
	int  OverThresholdFailCount;
	int  FDCount;
	int  OtherFailCount;


	TEST_FAIL_INFO *pFailInfo = this->m_RDTManager.GetTestFailInfo();

	// total fail	
	TotalFail = pFailInfo->TLCFullDie.TotalFailCount + pFailInfo->SLCFullDie.TotalFailCount + pFailInfo->TLCSampling.TotalFailCount + pFailInfo->SLCSampling.TotalFailCount;
	StrTemp.Format("%d", TotalFail);
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_TOTAL_FAIL);
	pEdit->SetWindowText(StrTemp);

	// uECC fail count
	uECCFailCount = pFailInfo->TLCFullDie.uECCFailCount + pFailInfo->SLCFullDie.uECCFailCount + pFailInfo->TLCSampling.uECCFailCount + pFailInfo->SLCSampling.uECCFailCount;
	StrTemp.Format("%d", uECCFailCount);
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_UECC_FAIL);
	pEdit->SetWindowText(StrTemp);

	// program fail count
	ProgramFailCount = pFailInfo->TLCFullDie.ProgramFailCount + pFailInfo->SLCFullDie.ProgramFailCount + pFailInfo->TLCSampling.ProgramFailCount + pFailInfo->SLCSampling.ProgramFailCount;
	StrTemp.Format("%d", ProgramFailCount);
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_PROGRAM_FAIL);
	pEdit->SetWindowText(StrTemp);

	// erase fail count
	EraseFailCount = pFailInfo->TLCFullDie.EraseFailCount + pFailInfo->SLCFullDie.EraseFailCount + pFailInfo->TLCSampling.EraseFailCount + pFailInfo->SLCSampling.EraseFailCount;
	StrTemp.Format("%d", EraseFailCount);
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_ERASE_FAIL);
	pEdit->SetWindowText(StrTemp);

	// over threshold fail count
	OverThresholdFailCount = pFailInfo->TLCFullDie.OverThresholdFailCount + pFailInfo->SLCFullDie.OverThresholdFailCount + pFailInfo->TLCSampling.OverThresholdFailCount + pFailInfo->SLCSampling.OverThresholdFailCount;
	StrTemp.Format("%d", OverThresholdFailCount);
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_OVER_THRESHOLD_FAIL);
	pEdit->SetWindowText(StrTemp);

	// factory defect
	FDCount = pFailInfo->TLCFullDie.FactoryDefectCount + pFailInfo->SLCFullDie.FactoryDefectCount + pFailInfo->TLCSampling.FactoryDefectCount + pFailInfo->SLCSampling.FactoryDefectCount;
	StrTemp.Format("%d", FDCount);
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_FD);
	pEdit->SetWindowText(StrTemp);

	// other fail
	OtherFailCount = pFailInfo->TLCFullDie.OtherFailCount + pFailInfo->SLCFullDie.OtherFailCount + pFailInfo->TLCSampling.OtherFailCount + pFailInfo->SLCSampling.OtherFailCount;
	StrTemp.Format("%d", OtherFailCount);
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_OTHER_FAIL);
	pEdit->SetWindowText(StrTemp);

	return;
}

//-------------------------------------------------------------------------------------------------
void CdlgRDTResultPage::ShowMPVer()
{
}

//-------------------------------------------------------------------------------------------------
void CdlgRDTResultPage::ShowDefectInfo(IN CListCtrl *pListCtrl, IN DEFECT_INFO *pDefect, IN DEFECT_INFO *pGD)
{
	CString      TempStr;
    int          ItemIndex;


	pListCtrl->DeleteAllItems();
	
	ItemIndex = 0;

    for (int ch = 0; ch < 2; ch++) {
        for (int ce = 0; ce < 4; ce++) {
            for (int lun = 0; lun < 2; lun++) {
				for (int plane = 0; plane < 2; plane++) {

					// sort by ascending order
					std::sort(pDefect->Ch[ch].Ce[ce].Lun[lun].Plane[plane].Defect_Block.begin(), pDefect->Ch[ch].Ce[ce].Lun[lun].Plane[plane].Defect_Block.end());

					// show to UI
					for (int i = 0; i < pDefect->Ch[ch].Ce[ce].Lun[lun].Plane[plane].Defect_Block.size(); i++) {

						bool IsGrownDefect = this->IsGD(ch, ce, lun, plane, pDefect->Ch[ch].Ce[ce].Lun[lun].Plane[plane].Defect_Block[i], pGD);
						(IsGrownDefect == true) ? TempStr.Format("LBB") : TempStr.Format("OBB");
						pListCtrl->InsertItem(ItemIndex, TempStr);

						TempStr.Format("--");
                        pListCtrl->SetItemText(ItemIndex, BAD_SEQ_INDEX, TempStr);

						TempStr.Format("--");
                        pListCtrl->SetItemText(ItemIndex, LOOP_INDEX, TempStr);

						TempStr.Format("TLC");
                        pListCtrl->SetItemText(ItemIndex, MODE_INDEX, TempStr);

						TempStr.Format("%d", pDefect->Ch[ch].Ce[ce].Lun[lun].Plane[plane].Defect_Block[i]);
                        pListCtrl->SetItemText(ItemIndex, BLOCK_INDEX, TempStr);

						TempStr.Format("--");
                        pListCtrl->SetItemText(ItemIndex, MAX_ECC_INDEX, TempStr);

						TempStr.Format("%d", ch);
                        pListCtrl->SetItemText(ItemIndex, CH_INDEX, TempStr);

						TempStr.Format("%d", ce);
                        pListCtrl->SetItemText(ItemIndex, CE_INDEX, TempStr);

						TempStr.Format("%d", lun);
                        pListCtrl->SetItemText(ItemIndex, LUN_INDEX, TempStr);

						TempStr.Format("%d", plane);
                        pListCtrl->SetItemText(ItemIndex, PLANE_INDEX, TempStr);

						TempStr.Format("--");
                        pListCtrl->SetItemText(ItemIndex, TEMP_INDEX, TempStr);

						ItemIndex++;
					}
				}
            }
        }
    }

    return;
}

//-------------------------------------------------------------------------------------------------
void CdlgRDTResultPage::AllRDTRsltToListCtrl(IN CListCtrl *pListCtrl, IN RDT_BLOCK_INFO *pBlockInfo)
{
	pListCtrl->DeleteAllItems();

	this->FullDieRsltToListCtrl(pListCtrl, &pBlockInfo->TLCFullDie, "TF");
	this->FullDieRsltToListCtrl(pListCtrl, &pBlockInfo->SLCFullDie, "SF");
	this->SamplingRsltToListCtrl(pListCtrl, &pBlockInfo->TLCSampling, "TS");
	this->SamplingRsltToListCtrl(pListCtrl, &pBlockInfo->SLCSampling, "SS");
	
	return;
}

//-------------------------------------------------------------------------------------------------
void CdlgRDTResultPage::FullDieRsltToListCtrl(IN CListCtrl *pListCtrl, IN std::vector<RDT_BLOCK_RESULT> *pBlock, IN char *pSignature)
{
	BYTE     Empty[16] = {0};  // for judge is there no block test result
    char     Signature[8];
	int      ItemIndex;
	CString  StrTemp;
	int      BadSeq;


    struct _FAIL_TYPE_DESCRIPTOR {
        char Descriptor[64];
    } Fail_Type_Descriptor[] = {
        {"Pass"},
        {"uECC Fail"},
        {"Program Fail"},
        {"Erase Fail"},
        {"Over Threshold Fail"},
        {"Factory Defect"},
        {"Other Fail"}
    };

	ItemIndex = pListCtrl->GetItemCount();
	BadSeq = 0;

	for (int i = 0; i < pBlock->size(); i++) {
		::memset(Signature, 0, sizeof(Signature));
        /*
		Signature[0] = (*pRslt)[i].head.h.signature & 0xFF;
		Signature[1] = ((*pRslt)[i].head.h.signature >> 8) & 0xFF;
        */
        Signature[0] = pSignature[0];
        Signature[1] = pSignature[1];
				
        
        BYTE Fail_Type = (*pBlock)[i].rec.Failed_Type;
        
        // we won't log factory defect info
        if (Fail_Type == RDT_RESULT_ORG_DEFECT) {
            continue;
        }
        
        // avoid fw return unexpected value
        if (Fail_Type > RDT_RESULT_OTHER_FAIL) {
            Fail_Type = RDT_RESULT_OTHER_FAIL;
        }

        StrTemp.Format("%s", Fail_Type_Descriptor[Fail_Type].Descriptor);
        pListCtrl->InsertItem(ItemIndex, StrTemp);
        
        
        if ((Fail_Type != RDT_RESULT_PASS) && (Fail_Type != RDT_RESULT_ORG_DEFECT)) {
            BadSeq++;
        }
        StrTemp.Format("%d", BadSeq);
        pListCtrl->SetItemText(ItemIndex, BAD_SEQ_INDEX, StrTemp);


        StrTemp.Format("%d", (*pBlock)[i].rec.Cycle);
        pListCtrl->SetItemText(ItemIndex, LOOP_INDEX, StrTemp);

        
        CString Temp1;
        CString Temp2;

        Temp1 = (Signature[0] == 'T') ? "TLC" : "SLC";
        Temp2 = (Signature[1] == 'F') ? "Full Die" : "Sampling";
        StrTemp.Format("%s (%s)", Temp1, Temp2);
        pListCtrl->SetItemText(ItemIndex, MODE_INDEX, StrTemp);


        StrTemp.Format("%d", (*pBlock)[i].rec.Block);
        pListCtrl->SetItemText(ItemIndex, BLOCK_INDEX, StrTemp);


		// modify below. if uECC Fail, we won't show error bit
		/*
		StrTemp.Format("%d", (*pBlock)[i].rec.Raw_bit_Error);
        pListCtrl->SetItemText(ItemIndex, MAX_ECC_INDEX, StrTemp);
		*/
		if (Fail_Type == 1) {
			pListCtrl->SetItemText(ItemIndex, MAX_ECC_INDEX, "");
		}
		else {
			StrTemp.Format("%d", (*pBlock)[i].rec.Raw_bit_Error);
			pListCtrl->SetItemText(ItemIndex, MAX_ECC_INDEX, StrTemp);
		}


        StrTemp.Format("%d", (*pBlock)[i].rec.CH);
        pListCtrl->SetItemText(ItemIndex, CH_INDEX, StrTemp);
        

        StrTemp.Format("%d", (*pBlock)[i].rec.CE);
        pListCtrl->SetItemText(ItemIndex, CE_INDEX, StrTemp);


        StrTemp.Format("%d", (*pBlock)[i].rec.Die);
        pListCtrl->SetItemText(ItemIndex, LUN_INDEX, StrTemp);


        StrTemp.Format("%d", (*pBlock)[i].rec.Plane);
        pListCtrl->SetItemText(ItemIndex, PLANE_INDEX, StrTemp);


        StrTemp.Format("%d", (*pBlock)[i].rec.Temp);
        pListCtrl->SetItemText(ItemIndex, TEMP_INDEX, StrTemp);

        ItemIndex++;
	}

	return;
}

//-------------------------------------------------------------------------------------------------
void CdlgRDTResultPage::SamplingRsltToListCtrl(IN CListCtrl *pListCtrl, IN std::vector<RDT_BLOCK_RESULT> *pBlock, IN char *pSignature)
{
	BYTE     Empty[16] = {0};  // for judge is there no block test result
	char     Signature[8];
	int      ItemIndex;
	CString  StrTemp;
	int      BadSeq;


	struct _FAIL_TYPE_DESCRIPTOR {
		char Descriptor[64];
	} Fail_Type_Descriptor[] = {
		{"Pass"},
		{"uECC Fail"},
		{"Program Fail"},
		{"Erase Fail"},
		{"Over Threshold Fail"},
		{"Skip"},  // factory defect
		{"Other Fail"}
	};

	ItemIndex = pListCtrl->GetItemCount();
	BadSeq = 0;

	for (int i = 0; i < pBlock->size(); i++) {
		::memset(Signature, 0, sizeof(Signature));
        /*
        Signature[0] = (*pRslt)[i].head.h.signature & 0xFF;
        Signature[1] = ((*pRslt)[i].head.h.signature >> 8) & 0xFF;
        */
        Signature[0] = pSignature[0];
        Signature[1] = pSignature[1];
		
        
        
        BYTE Fail_Type = (*pBlock)[i].rec.Failed_Type;
        
        // avoid fw return unexpected value
        if (Fail_Type > RDT_RESULT_OTHER_FAIL) {
            Fail_Type = RDT_RESULT_OTHER_FAIL;
        }
        
        StrTemp.Format("%s", Fail_Type_Descriptor[Fail_Type].Descriptor);
        pListCtrl->InsertItem(ItemIndex, StrTemp);
        

        if ((Fail_Type != RDT_RESULT_PASS) && (Fail_Type != RDT_RESULT_ORG_DEFECT)) {
            BadSeq++;
            StrTemp.Format("%d", BadSeq);
            pListCtrl->SetItemText(ItemIndex, BAD_SEQ_INDEX, StrTemp);
        }
        else {
            StrTemp.Format("--");
            pListCtrl->SetItemText(ItemIndex, BAD_SEQ_INDEX, StrTemp);
        }


        StrTemp.Format("%d", (*pBlock)[i].rec.Cycle);
        pListCtrl->SetItemText(ItemIndex, LOOP_INDEX, StrTemp);

        
        CString Temp1;
        CString Temp2;

        Temp1 = (Signature[0] == 'T') ? "TLC" : "SLC";
        Temp2 = (Signature[0] == 'F') ? "Full Die" : "Sampling";
        StrTemp.Format("%s (%s)", Temp1, Temp2);
        pListCtrl->SetItemText(ItemIndex, MODE_INDEX, StrTemp);


        StrTemp.Format("%d", (*pBlock)[i].rec.Block);
        pListCtrl->SetItemText(ItemIndex, BLOCK_INDEX, StrTemp);


		// modify below. if uECC Fail, we won't show error bit
		/*
        StrTemp.Format("%d", (*pBlock)[i].rec.Raw_bit_Error);
        pListCtrl->SetItemText(ItemIndex, MAX_ECC_INDEX, StrTemp);
		*/
		if (Fail_Type == 1) {
			pListCtrl->SetItemText(ItemIndex, MAX_ECC_INDEX, "");
		}
		else {
			StrTemp.Format("%d", (*pBlock)[i].rec.Raw_bit_Error);
			pListCtrl->SetItemText(ItemIndex, MAX_ECC_INDEX, StrTemp);
		}


        StrTemp.Format("%d", (*pBlock)[i].rec.CH);
        pListCtrl->SetItemText(ItemIndex, CH_INDEX, StrTemp);
        

        StrTemp.Format("%d", (*pBlock)[i].rec.CE);
        pListCtrl->SetItemText(ItemIndex, CE_INDEX, StrTemp);


        StrTemp.Format("%d", (*pBlock)[i].rec.Die);
        pListCtrl->SetItemText(ItemIndex, LUN_INDEX, StrTemp);


        StrTemp.Format("%d", (*pBlock)[i].rec.Plane);
        pListCtrl->SetItemText(ItemIndex, PLANE_INDEX, StrTemp);


        StrTemp.Format("%d", (*pBlock)[i].rec.Temp);
        pListCtrl->SetItemText(ItemIndex, TEMP_INDEX, StrTemp);
        
        ItemIndex++;
	}

	return;
}

//-------------------------------------------------------------------------------------------------
int CdlgRDTResultPage::UserRDTSettingInfoFormat(IN std::string *pSettingContent, OUT CString *pUserContent)
{
    char     Buffer[260];
	CString  TempStr;
	int      Rslt;
    

	//================================================================
	//               Test_Condition setting
	//================================================================
    
    // user want the order show to UI
	::memset(Buffer, 0, sizeof(Buffer));
    Read_INI_File_Ex("Test_Condition", "Previous_Stage", Buffer, sizeof(Buffer), "", (*pSettingContent).c_str());
	TempStr.Format("Previous_Stage=%s\r\n", Buffer);
	(*pUserContent) += TempStr;
	
	::memset(Buffer, 0, sizeof(Buffer));
    Read_INI_File_Ex("Test_Condition", "Current_Stage", Buffer, sizeof(Buffer), "", (*pSettingContent).c_str());
	TempStr.Format("Current_Stage=%s\r\n", Buffer);
	(*pUserContent) += TempStr;

	::memset(Buffer, 0, sizeof(Buffer));
    Read_INI_File_Ex("Test_Condition", "TLC_Full_Die_Cycles", Buffer, sizeof(Buffer), "", (*pSettingContent).c_str());
	TempStr.Format("TLC_Full_Die_Cycles=%s\r\n", Buffer);
	(*pUserContent) += TempStr;

	::memset(Buffer, 0, sizeof(Buffer));
	Read_INI_File_Ex("Test_Condition", "TLC_Full_Die_ECC_Bit_Threshold", Buffer, sizeof(Buffer), "", (*pSettingContent).c_str());
	TempStr.Format("TLC_Full_Die_ECC_Bit_Threshold=%s\r\n", Buffer);
	(*pUserContent) += TempStr;

	::memset(Buffer, 0, sizeof(Buffer));
	Read_INI_File_Ex("Test_Condition", "Bypass_SLC_Weru_For_TLC_Full_Die_Test", Buffer, sizeof(Buffer), "", (*pSettingContent).c_str());
	TempStr.Format("Bypass_SLC_Weru_For_TLC_Full_Die_Test=%s\r\n", Buffer);
	(*pUserContent) += TempStr;
    
    ::memset(Buffer, 0, sizeof(Buffer));
    Read_INI_File_Ex("Test_Condition", "SLC_Full_Die_Cycles", Buffer, sizeof(Buffer), "", (*pSettingContent).c_str());
	TempStr.Format("SLC_Full_Die_Cycles=%s\r\n", Buffer);
	(*pUserContent) += TempStr;

	::memset(Buffer, 0, sizeof(Buffer));
	Read_INI_File_Ex("Test_Condition", "SLC_Full_Die_ECC_Bit_Threshold", Buffer, sizeof(Buffer), "", (*pSettingContent).c_str());
	TempStr.Format("SLC_Full_Die_ECC_Bit_Threshold=%s\r\n", Buffer);
	(*pUserContent) += TempStr;
    
	/*
    ::memset(Buffer, 0, sizeof(Buffer));
    Read_INI_File_Ex("Test_Condition", "TLC_ECC_Bit", Buffer, sizeof(Buffer), "", (*pSettingContent).c_str());
    TempStr.Format("TLC_ECC_Bit=%s\r\n", Buffer);
	(*pUserContent) += TempStr;
	*/
	::memset(Buffer, 0, sizeof(Buffer));
	Rslt = Read_INI_File_Ex("Test_Condition", "TLC_ECC_Bit", Buffer, sizeof(Buffer), "", (*pSettingContent).c_str());
    if (Rslt != 0) {
		Rslt = Read_INI_File_Ex("Test_Condition", "TLC_Sampling_ECC_Bit_Threshold", Buffer, sizeof(Buffer), "", (*pSettingContent).c_str());
	}
	TempStr.Format("TLC_Sampling_ECC_Bit_Threshold=%s\r\n", Buffer);
	(*pUserContent) += TempStr;
    
	/*
    ::memset(Buffer, 0, sizeof(Buffer));
    Read_INI_File_Ex("Test_Condition", "SLC_ECC_Bit", Buffer, sizeof(Buffer), "", (*pSettingContent).c_str());
    TempStr.Format("SLC_ECC_Bit=%s\r\n", Buffer);
	(*pUserContent) += TempStr;
	*/
	::memset(Buffer, 0, sizeof(Buffer));
	Rslt = Read_INI_File_Ex("Test_Condition", "SLC_ECC_Bit", Buffer, sizeof(Buffer), "", (*pSettingContent).c_str());
    if (Rslt != 0) {
		Rslt = Read_INI_File_Ex("Test_Condition", "SLC_Sampling_ECC_Bit_Threshold", Buffer, sizeof(Buffer), "", (*pSettingContent).c_str());
    }
	TempStr.Format("SLC_Sampling_ECC_Bit_Threshold=%s\r\n", Buffer);
	(*pUserContent) += TempStr;
    
    ::memset(Buffer, 0, sizeof(Buffer));
    Read_INI_File_Ex("MP_Option", "Force_Erase_All", Buffer, sizeof(Buffer), "", (*pSettingContent).c_str());
    TempStr.Format("Force_Erase_All=%s\r\n", Buffer);
	(*pUserContent) += TempStr;
    
    ::memset(Buffer, 0, sizeof(Buffer));
    Read_INI_File_Ex("MP_Option", "CE_Count", Buffer, sizeof(Buffer), "", (*pSettingContent).c_str());
    TempStr.Format("CE_Count=%s\r\n", Buffer);
	(*pUserContent) += TempStr;

	::memset(Buffer, 0, sizeof(Buffer));
    Read_INI_File_Ex("MP_Option", "Flash_ID", Buffer, sizeof(Buffer), "", (*pSettingContent).c_str());
    TempStr.Format("Flash_ID=%s\r\n", Buffer);
	(*pUserContent) += TempStr;
    
    ::memset(Buffer, 0, sizeof(Buffer));
    Read_INI_File_Ex("MP_Option", "Good_Block_Per_Plane", Buffer, sizeof(Buffer), "", (*pSettingContent).c_str());
    TempStr.Format("Good_Block_Per_Plane=%s\r\n", Buffer);
	(*pUserContent) += TempStr;

	::memset(Buffer, 0, sizeof(Buffer));
    Read_INI_File_Ex("MP_Option", "Total_Good_WERU", Buffer, sizeof(Buffer), "", (*pSettingContent).c_str());
    TempStr.Format("Total_Good_WERU=%s\r\n", Buffer);
	(*pUserContent) += TempStr;
    
    
    
    
	::memset(Buffer, 0, sizeof(Buffer));
    Read_INI_File_Ex("Test_Condition", "TLC_Full_Die_ECC_Log_Interval", Buffer, sizeof(Buffer), "", (*pSettingContent).c_str());
	TempStr.Format("TLC_Full_Die_ECC_Log_Interval=%s\r\n", Buffer);
	(*pUserContent) += TempStr;

	::memset(Buffer, 0, sizeof(Buffer));
    Read_INI_File_Ex("Test_Condition", "SLC_Full_Die_ECC_Log_Interval", Buffer, sizeof(Buffer), "", (*pSettingContent).c_str());
	TempStr.Format("SLC_Full_Die_ECC_Log_Interval=%s\r\n", Buffer);
	(*pUserContent) += TempStr;

	::memset(Buffer, 0, sizeof(Buffer));
    Read_INI_File_Ex("Test_Condition", "TLC_Dwell_Time", Buffer, sizeof(Buffer), "", (*pSettingContent).c_str());
	TempStr.Format("TLC_Dwell_Time=%s\r\n", Buffer);
	(*pUserContent) += TempStr;

	::memset(Buffer, 0, sizeof(Buffer));
    Read_INI_File_Ex("Test_Condition", "TLC_Sampling_Cycle", Buffer, sizeof(Buffer), "", (*pSettingContent).c_str());
    TempStr.Format("TLC_Sampling_Cycle=%s\r\n", Buffer);
	(*pUserContent) += TempStr;

	::memset(Buffer, 0, sizeof(Buffer));
    Read_INI_File_Ex("Test_Condition", "TLC_ECC_Log_Interval", Buffer, sizeof(Buffer), "", (*pSettingContent).c_str());
    TempStr.Format("TLC_ECC_Log_Interval=%s\r\n", Buffer);
	(*pUserContent) += TempStr;

	::memset(Buffer, 0, sizeof(Buffer));
    Read_INI_File_Ex("Test_Condition", "TLC_Start_Select_Block", Buffer, sizeof(Buffer), "", (*pSettingContent).c_str());
    TempStr.Format("TLC_Start_Select_Block=%s\r\n", Buffer);
	(*pUserContent) += TempStr;

	::memset(Buffer, 0, sizeof(Buffer));
    Read_INI_File_Ex("Test_Condition", "TLC_End_Select_Block", Buffer, sizeof(Buffer), "", (*pSettingContent).c_str());
    TempStr.Format("TLC_End_Select_Block=%s\r\n", Buffer);
	(*pUserContent) += TempStr;

	::memset(Buffer, 0, sizeof(Buffer));
    Read_INI_File_Ex("Test_Condition", "TLC_Random_Block", Buffer, sizeof(Buffer), "", (*pSettingContent).c_str());
    TempStr.Format("TLC_Random_Block=%s\r\n", Buffer);
	(*pUserContent) += TempStr;

	::memset(Buffer, 0, sizeof(Buffer));
    Read_INI_File_Ex("Test_Condition", "TLC_Sampling_Block_Quantity", Buffer, sizeof(Buffer), "", (*pSettingContent).c_str());
    TempStr.Format("TLC_Sampling_Block_Quantity=%s\r\n", Buffer);
	(*pUserContent) += TempStr;
    
	::memset(Buffer, 0, sizeof(Buffer));
    Read_INI_File_Ex("Test_Condition", "SLC_Dwell_Time", Buffer, sizeof(Buffer), "", (*pSettingContent).c_str());
    TempStr.Format("SLC_Dwell_Time=%s\r\n", Buffer);
	(*pUserContent) += TempStr;
    
	::memset(Buffer, 0, sizeof(Buffer));
    Read_INI_File_Ex("Test_Condition", "SLC_Sampling_Cycle", Buffer, sizeof(Buffer), "", (*pSettingContent).c_str());
    TempStr.Format("SLC_Sampling_Cycle=%s\r\n", Buffer);
	(*pUserContent) += TempStr;
    
	::memset(Buffer, 0, sizeof(Buffer));
    Read_INI_File_Ex("Test_Condition", "SLC_ECC_Log_Interval", Buffer, sizeof(Buffer), "", (*pSettingContent).c_str());
    TempStr.Format("SLC_ECC_Log_Interval=%s\r\n", Buffer);
	(*pUserContent) += TempStr;
    
	::memset(Buffer, 0, sizeof(Buffer));
    Read_INI_File_Ex("Test_Condition", "SLC_Random_Block", Buffer, sizeof(Buffer), "", (*pSettingContent).c_str());
    TempStr.Format("SLC_Random_Block=%s\r\n", Buffer);
	(*pUserContent) += TempStr;

	::memset(Buffer, 0, sizeof(Buffer));
    Read_INI_File_Ex("Test_Condition", "SLC_Sampling_Block_Quantity", Buffer, sizeof(Buffer), "", (*pSettingContent).c_str());
    TempStr.Format("SLC_Sampling_Block_Quantity=%s\r\n", Buffer);
	(*pUserContent) += TempStr;
	
	::memset(Buffer, 0, sizeof(Buffer));
    Read_INI_File_Ex("Test_Condition", "SLC_Start_Select_Block", Buffer, sizeof(Buffer), "", (*pSettingContent).c_str());
    TempStr.Format("SLC_Start_Select_Block=%s\r\n", Buffer);
	(*pUserContent) += TempStr;
    
	::memset(Buffer, 0, sizeof(Buffer));
    Read_INI_File_Ex("Test_Condition", "SLC_End_Select_Block", Buffer, sizeof(Buffer), "", (*pSettingContent).c_str());
    TempStr.Format("SLC_End_Select_Block=%s\r\n", Buffer);
	(*pUserContent) += TempStr;
    
	::memset(Buffer, 0, sizeof(Buffer));
    Read_INI_File_Ex("Firmware_Bin_File_Path", "Burner", Buffer, sizeof(Buffer), "", (*pSettingContent).c_str());
    TempStr.Format("Burner=%s\r\n", Buffer);
	(*pUserContent) += TempStr;

	return 0;
}

//-------------------------------------------------------------------------------------------------
void CdlgRDTResultPage::ShowDefectCount(IN CListCtrl *pListCtrl, IN DEFECT_INFO *pDefect)
{
    CString  TempStr;
    int      ItemIndex;


    pListCtrl->DeleteAllItems();

    ItemIndex = 0;

    for (int ch = 0; ch < 2; ch++) {
        for (int ce = 0; ce < 4; ce++) {

			int DefectPerCE = 0;

            for (int lun = 0; lun < 2; lun++) {
                for (int plane = 0; plane < 2; plane++) {
                    DefectPerCE += pDefect->Ch[ch].Ce[ce].Lun[lun].Plane[plane].Defect_Block.size();
                }
            }

			TempStr.Format("%d", ch);
			pListCtrl->InsertItem(ItemIndex, TempStr);
			
			TempStr.Format("%d", ce);
			pListCtrl->SetItemText(ItemIndex, DF_CE_INDEX, TempStr);
			
			TempStr.Format("%d", DefectPerCE);
			pListCtrl->SetItemText(ItemIndex, DF_COUNT_INDEX, TempStr);
			
			ItemIndex++;
        }
    }

    return;
}

//-------------------------------------------------------------------------------------------------
int CdlgRDTResultPage::Read_INI_File_Ex(IN  char *pSection,
										IN  char *pKey,
										OUT char *pKey_Value,
										IN  int  Key_Value_Buffer_Size,
										IN  char *pDefault_Value,
										IN  const char *pContent_Buffer)
{
    UINT32  Section_Start;   // section name start offset of file
    UINT32  Section_End;     // section name end offset of file
    UINT32  Key_Start;       // key name start offset of file
    UINT32  Key_End;         // key name end offset of file
    UINT32  KeyValue_Start;  // key value name start offset of file
    UINT32  KeyValue_End;    // key value name end offset of file
    int     Rslt;
    
    
    //==============================================
    //           read key value
    //==============================================
    Rslt = Parse_INI_File(pSection, pKey, pContent_Buffer, &Section_Start, &Section_End, &Key_Start, &Key_End, &KeyValue_Start, &KeyValue_End);
    if (Rslt != 0) {
        ::memset(pKey_Value, 0, Key_Value_Buffer_Size);
        strncpy(pKey_Value, pDefault_Value, Key_Value_Buffer_Size);
        return 6;
    }

    int CopySize = KeyValue_End - KeyValue_Start;

    if (CopySize > Key_Value_Buffer_Size - 1 ) {
        CopySize =  Key_Value_Buffer_Size - 1;
    }

    ::memset(pKey_Value, 0, Key_Value_Buffer_Size);
    ::memcpy(pKey_Value, pContent_Buffer + KeyValue_Start, CopySize);
    pKey_Value[CopySize] = '\0';
    
    return 0;
}

//-------------------------------------------------------------------------------------------------
int CdlgRDTResultPage::Parse_INI_File(IN  char       *pSection,
									  IN  char       *pKey,
									  IN  const char *pFile_Buffer,
									  OUT UINT32     *pSection_Start_Offset,
									  OUT UINT32     *pSection_End_Offset,
									  OUT UINT32     *pKey_Start_Offset,
									  OUT UINT32     *pKey_End_Offset,
									  OUT UINT32     *pKey_Value_Start_Offset,
									  OUT UINT32     *pKey_Value_End_Offset)
{
    UINT32  KeyName_Start;      // temp for saving key name start offset
    UINT32  KeyName_End;        // temp for saving key name end offset
    UINT32  SectionName_Start;  // temp for saving section name start offset
    UINT32  i = 0;


    while (Is_End_Char(pFile_Buffer[i]) == false) {

        //==================================================
        //           try to find section name
        //==================================================

        // find the '['
        if (Is_Left_Bracket(pFile_Buffer[i]) == false) {
            i++;
            continue;
        }
        SectionName_Start = i + 1;


        // find the ']'
        do {
            i++;
            if (Is_End_Char(pFile_Buffer[i]) == true) {
                return 1;
            }
        } while ((Is_Right_Bracket(pFile_Buffer[i]) == false));


        // compare section name
        if ((i - SectionName_Start) != ::strlen(pSection)) {
            continue;
        }

        if (::strncmp((pFile_Buffer + SectionName_Start), pSection, ::strlen(pSection)) != 0) {
            continue;
        }

        *pSection_Start_Offset = SectionName_Start;
        *pSection_End_Offset = i - 1;

        i++;


        // find '\n' char after ']' of section
        while (Is_New_Line_Char(pFile_Buffer[i]) != true) {
            if (Is_End_Char(pFile_Buffer[i]) == true) {
                return 2;
            }
            i++;
        }
        i++;


        //==================================================
        //           try to find key name
        //==================================================
        while (1) {

            KeyName_Start = i;

            while (Is_New_Line_Char(pFile_Buffer[i]) != true) {
                if (Is_End_Char(pFile_Buffer[i]) == true) {
                    return 3;
                }
                i++;
            }
            KeyName_End = i;

            UINT32 nCharCountThisLine = KeyName_End - KeyName_Start - 1;  // -1 for ignore '\n'

            char *pTempBuffer = (char*)::malloc((nCharCountThisLine + 1) * sizeof(char));
            if (pTempBuffer == NULL) {
                return 4;
            }

            ::memset(pTempBuffer, 0, (nCharCountThisLine + 1) * sizeof(char));
            ::strncpy(pTempBuffer, &pFile_Buffer[KeyName_Start], nCharCountThisLine);

            i++;

            // check comment char ';'
            if (::strchr(pTempBuffer, ';') != NULL) {
                ::free(pTempBuffer);
                pTempBuffer = NULL;
                continue;  // continue to find key name in this section
            }

            // check another section start char '[' is found
            if (::strchr(pTempBuffer, '[') != NULL) {
                ::free(pTempBuffer);
                pTempBuffer = NULL;
                break;  // don't need to find key name in this section
            }

            // check key name
            char *pTemp = ::strchr(pTempBuffer, '=');
            if (pTemp == NULL) {
                ::free(pTempBuffer);
                pTempBuffer = NULL;
                continue;  // key name format is incorrect, continue to find key name in this section
            }

            UINT32 KeyName_Length = nCharCountThisLine - ::strlen(pTemp);
            if (::strlen(pKey) != KeyName_Length) {
                ::free(pTempBuffer);
                pTempBuffer = NULL;
                continue;
            }

            if (::strncmp((pFile_Buffer + KeyName_Start), pKey, ::strlen(pKey)) != 0) {
                ::free(pTempBuffer);
                pTempBuffer = NULL;
                continue;
            }

            *pKey_Start_Offset = KeyName_Start;
            *pKey_End_Offset = KeyName_Start + KeyName_Length - 1;  // -1 for ignore '='

            *pKey_Value_Start_Offset = (KeyName_Start + KeyName_Length) + 1;
            *pKey_Value_End_Offset = KeyName_End - 1;  // -1 for ignore '\n'

            ::free(pTempBuffer);
            pTempBuffer = NULL;

            return 0;
        }
    }

    return 5;
}

//-------------------------------------------------------------------------------------------------
bool CdlgRDTResultPage::Is_End_Char(IN char c)
{
    return (c == '\0') ? true : false;
}

//-------------------------------------------------------------------------------------------------
bool CdlgRDTResultPage::Is_Left_Bracket(IN char c)
{
    return (c == LEFT_BRACKET) ? true : false;
}

//-------------------------------------------------------------------------------------------------
bool CdlgRDTResultPage::Is_Right_Bracket(IN char c)
{
    return (c == RIGHT_BRACKET) ? true : false;
}

//-------------------------------------------------------------------------------------------------
bool CdlgRDTResultPage::Is_New_Line_Char(IN char c)
{
    return (c == '\n') ? true : false;
}

//-------------------------------------------------------------------------------------------------
void CdlgRDTResultPage::OnOK()
{
	// TODO: Add extra validation here
	
	//
	// when mouse focus is in the contorl of this page, and then press enter key will call OnOK()
	// OnOK() default action will close dialog.
	// to avoid this case we override virtual function OnOK and return directly.
	//
	return;
}

//-------------------------------------------------------------------------------------------------
void CdlgRDTResultPage::ShowProductionInfo()
{
	// TODO: Add your control notification handler code here
	CComboBox  *pComboBox;
	CEdit      *pEdit;
	CString    StrTemp;
	int        SelectIndex;
	int        SelectItemLen;
	int        SelectPort;
	int        Rslt;


	pComboBox = (CComboBox*)GetDlgItem(IDC_COMBO_PORT);
	SelectIndex = pComboBox->GetCurSel();
	if (SelectIndex == CB_ERR) {
		return;
	}

	//==============================================================
	//                    get select port
	//==============================================================
	CString  PortStr;


	SelectItemLen = pComboBox->GetLBTextLen(SelectIndex);
    pComboBox->GetLBText(SelectIndex, StrTemp.GetBuffer(SelectItemLen));
    StrTemp.ReleaseBuffer();
	PortStr = StrTemp.Mid(5);  // "Port " --> length is 5
	SelectPort = ::atoi(PortStr);


	//==============================================================
	//                    get device handle
	//==============================================================
	HANDLE  hDevice;
	char    DriveRoot[32];
	
	
	if (this->m_pPortData[SelectPort].PhyDrvNum == -1) {
		return;
	}

	this->ClearUI();

	::memset(DriveRoot, 0, sizeof(DriveRoot));
    ::sprintf(DriveRoot, "\\\\.\\PHYSICALDRIVE%d", this->m_pPortData[SelectPort].PhyDrvNum);
	
	hDevice = ::CreateFile(DriveRoot, (GENERIC_WRITE | GENERIC_READ), (FILE_SHARE_READ | FILE_SHARE_WRITE), NULL, OPEN_EXISTING, 0, NULL);
	if (hDevice == INVALID_HANDLE_VALUE) {
		MessageBox("get device handle fail", NULL, MB_OK | MB_ICONERROR);
		return;
	}


	//==============================================================
	//                     show MP version
	//==============================================================
	LOG_EXT_CONFIG_B0  Read_Log_Ext_B0;
    
  
    ::memset(&Read_Log_Ext_B0, 0, sizeof(LOG_EXT_CONFIG_B0));
    Rslt = SSD_Utility_Get_Log_Ext_Config_B0(-1, hDevice, 0, &Read_Log_Ext_B0);
    if (Rslt != 0) {
		::CloseHandle(hDevice);
		hDevice = INVALID_HANDLE_VALUE;

		MessageBox("read MP version fail", NULL, MB_OK | MB_ICONERROR);
        return;
    }

    // check header
    if (::memcmp(Read_Log_Ext_B0.Image_Header_Config.Signature, IMAGE_HEADER_SIGNATURE, sizeof(Read_Log_Ext_B0.Image_Header_Config.Signature)) != 0) {
		::CloseHandle(hDevice);
		hDevice = INVALID_HANDLE_VALUE;

		char Signature[16] = {0};
		::memcpy(Signature, Read_Log_Ext_B0.Image_Header_Config.Signature, sizeof(Signature));
		StrTemp.Format("read MP version fail. signature = %s", Signature);
		MessageBox(StrTemp, NULL, MB_OK | MB_ICONERROR);
        return;
    }

	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_MP_VER);
	pEdit->SetWindowText(Read_Log_Ext_B0.MP_Use_Data_Config.MP_Version);


	//==============================================================
	//                    get RDT result
	//==============================================================
	int  Mode;

	Rslt = SSD_Utility_Get_FW_Mode(-1, hDevice, 0, &Mode);
	if (Rslt != 0) {
		::CloseHandle(hDevice);
		hDevice = INVALID_HANDLE_VALUE;

		MessageBox("get firmware mode command fail", NULL, MB_OK | MB_ICONERROR);
		return;
	}
	this->m_FwMode = (ENUM_FIRMWARE_MODE)Mode;
	

	// show fw mode to UI
	this->m_EditStatus.SetWindowText(g_StatusDescription[Mode].Text);
	this->m_EditStatus.SetTextColor(g_StatusDescription[Mode].Color);
	

	if ((this->m_FwMode == ROM_SAFE_MODE) || (this->m_FwMode == UNKNOW_MODE)) {
		return;
	}
	

	// read defect info
	Rslt = this->m_DefectManager.Init(-1, hDevice, READ_LOG_EXT_NONE_SEGMENT);
	if (Rslt != 0) {
		::CloseHandle(hDevice);
		hDevice = INVALID_HANDLE_VALUE;
		return;
	}
	
	
	this->m_RadioDefect = GD_INDEX;
	UpdateData(FALSE);
	/*
	this->OnRadioTotalDefect();
	*/

	//DEFECT_INFO *pDefect = this->m_DefectManager.GetAllDefect();
    //this->ShowDefectCount(&this->m_ListCtrlDefect, pDefect);
	DEFECT_INFO *pDefect = this->m_DefectManager.GetAllDefect();
	this->ShowDefectCount(&this->m_ListCtrlDefect, this->m_DefectManager.GetGD());

	// read RDT info
	if (Mode == RDT_FW_MODE) {  // RDT firmware mode
		Rslt = this->m_RDTManager.Init(-1, hDevice, READ_LOG_EXT_NONE_SEGMENT, PRELOAD_NORMAL_MODE);
		if (Rslt != 0) {
			::CloseHandle(hDevice);
			hDevice = INVALID_HANDLE_VALUE;
			return;
		}
		
		this->ShowRDTRslt();
	}
	else {  // burner / production firmware mode
		//this->ShowDefectInfo(&this->m_ListCtrlRslt, this->m_DefectManager.GetAllDefect(), this->m_DefectManager.GetGD());
		this->ShowDefectInfo(&this->m_ListCtrlRslt, this->m_DefectManager.GetGD(), this->m_DefectManager.GetGD());
	}


	::CloseHandle(hDevice);
	hDevice = INVALID_HANDLE_VALUE;
	

	this->m_IsInitSucceed = true;

	return;
}

//-------------------------------------------------------------------------------------------------
void CdlgRDTResultPage::OnSelChangeComboPort()
{
	this->ShowProductionInfo();
	return;
}

//-------------------------------------------------------------------------------------------------
void CdlgRDTResultPage::OnRadioTotalDefect()
{
	// TODO: Add your control notification handler code here

    if ((this->m_DefectManager.IsInitSucceed() == false) || (this->m_FwMode == ROM_SAFE_MODE)) {
        return;
    }

	// show defect count to IDC_LIST_DEFECT
    this->ShowDefectCount(&this->m_ListCtrlDefect, this->m_DefectManager.GetAllDefect());


	// show defect info to IDC_LIST_RSLT
	if ((this->m_FwMode == BURNER_MODE) || (this->m_FwMode == PRODUCT_FW_MODE)) {
		this->ShowDefectInfo(&this->m_ListCtrlRslt, this->m_DefectManager.GetAllDefect(), this->m_DefectManager.GetGD());
	}

	return;
}

//-------------------------------------------------------------------------------------------------
void CdlgRDTResultPage::OnRadioFD()
{
	// TODO: Add your control notification handler code here

    if ((this->m_DefectManager.IsInitSucceed() == false) || (this->m_FwMode == ROM_SAFE_MODE)) {
        return;
    }

	// show defect count to IDC_LIST_DEFECT
    this->ShowDefectCount(&this->m_ListCtrlDefect, this->m_DefectManager.GetFD());


	// show defect info to IDC_LIST_RSLT
	if ((this->m_FwMode == BURNER_MODE) || (this->m_FwMode == PRODUCT_FW_MODE)) {
		this->ShowDefectInfo(&this->m_ListCtrlRslt, this->m_DefectManager.GetFD(), this->m_DefectManager.GetGD());
	}

	return;
}

//-------------------------------------------------------------------------------------------------
void CdlgRDTResultPage::OnRadioGD()
{
	// TODO: Add your control notification handler code here
	
    if ((this->m_DefectManager.IsInitSucceed() == false) || (this->m_FwMode == ROM_SAFE_MODE)) {
        return;
    }

	// show defect count to IDC_LIST_DEFECT
    this->ShowDefectCount(&this->m_ListCtrlDefect, this->m_DefectManager.GetGD());


	// show defect info to IDC_LIST_RSLT
	if ((this->m_FwMode == BURNER_MODE) || (this->m_FwMode == PRODUCT_FW_MODE)) {
		this->ShowDefectInfo(&this->m_ListCtrlRslt, this->m_DefectManager.GetGD(), this->m_DefectManager.GetGD());
	}

	return;
}

//-------------------------------------------------------------------------------------------------
bool CdlgRDTResultPage::IsGD(IN int ch, IN int ce, IN int lun, IN int plane, IN UINT16 LunBlock, IN DEFECT_INFO *pGD)
{
	UINT32 BlkCnt = pGD->Ch[ch].Ce[ce].Lun[lun].Plane[plane].Defect_Block.size();

	for (UINT32 i = 0; i < BlkCnt; i++) {
		if (LunBlock == pGD->Ch[ch].Ce[ce].Lun[lun].Plane[plane].Defect_Block[i]) {
			return true;
		}
	}
	
	return false;
}

//-------------------------------------------------------------------------------------------------
void CdlgRDTResultPage::ClearUI()
{
	CEdit *pEdit;


	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_RDT_SETTING_INFO);
	pEdit->SetWindowText("");


	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_STATUS);
	pEdit->SetWindowText("");

	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_MP_VER);
	pEdit->SetWindowText("");


	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_FW_VERSION);
	pEdit->SetWindowText("");

	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_TOTAL_SPEND_TIME);
	pEdit->SetWindowText("");

	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_TLC_FULL_DIE_TIME);
	pEdit->SetWindowText("");

	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_SLC_FULL_DIE_TIME);
	pEdit->SetWindowText("");

	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_TLC_SAMPLING_TIME);
	pEdit->SetWindowText("");

	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_SLC_SAMPLING_TIME);
	pEdit->SetWindowText("");

	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_MAX_TEMPERATURE);
	pEdit->SetWindowText("");
	
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_TOTAL_FAIL);
	pEdit->SetWindowText("");

	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_UECC_FAIL);
	pEdit->SetWindowText("");

	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_PROGRAM_FAIL);
	pEdit->SetWindowText("");

	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_ERASE_FAIL);
	pEdit->SetWindowText("");

	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_OVER_THRESHOLD_FAIL);
	pEdit->SetWindowText("");

	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_FD);
	pEdit->SetWindowText("");

	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_OTHER_FAIL);
	pEdit->SetWindowText("");


	this->m_ListCtrlDefect.DeleteAllItems();
	this->m_ListCtrlRslt.DeleteAllItems();

	return;
}

//-------------------------------------------------------------------------------------------------


