#ifndef __NAND_INFO_MANAGER_H__
#define __NAND_INFO_MANAGER_H__

//-------------------------------------------------------------------------------------------------
#include "SSD_Utility.h"
#include "FileManager.h"
#include "AES.h"

//-------------------------------------------------------------------------------------------------
extern BYTE  g_AES_KEY[];
#define CIPHER_SIGNATURE  "3system"


#pragma pack(1)

// 64 bytes
typedef struct _CIPHER_HEADER
{
	char    Signature[16];
	UINT32  Size;
	UINT32  CRC;
	BYTE    Rsv[40];
} CIPHER_HEADER, *PCIPHER_HEADER;

#pragma pack()


//-------------------------------------------------------------------------------------------------
class CNandInfoManager
{
    public:
        CNandInfoManager();
        ~CNandInfoManager();
        
        int  Init(IN int PhyDrvNum, IN HANDLE hDevice, IN char *pBurnerFullPath);
        
        // interface
        cfg_tbl_nand_info_t  *GetNandInfo();
        int                  GetFlashID(IN int CH, IN int CE, OUT BYTE *pID);
		bool                 IsInitSucceed();
        
    private:
        CFileManager         m_FileManager;
		bool                 m_InitSucceed;
        
        cfg_tbl_nand_info_t  m_NandInfo;
        BYTE                 m_FlashID[8][8];
		

		void  InitMember();
        int   DownloadBurner(IN int PhyDrvNum, IN HANDLE hDevice, IN char *pBurnerFullPath);
};

//-------------------------------------------------------------------------------------------------

#endif  // end #ifndef __NAND_INFO_MANAGER_H__
