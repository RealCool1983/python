// dlgSettingPage1.cpp : implementation file
//

#include "stdafx.h"
#include "SSDMP.h"
#include "dlgSettingPage1.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

///////////////////////////////////////////////////////////////////////////////////////////////////
// CdlgSettingPage1 dialog


CdlgSettingPage1::CdlgSettingPage1(CWnd* pParent /*=NULL*/)
	: CDialog(CdlgSettingPage1::IDD, pParent)
{
	//{{AFX_DATA_INIT(CdlgSettingPage1)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

//-------------------------------------------------------------------------------------------------
void CdlgSettingPage1::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CdlgSettingPage1)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

//-------------------------------------------------------------------------------------------------
BEGIN_MESSAGE_MAP(CdlgSettingPage1, CDialog)
	//{{AFX_MSG_MAP(CdlgSettingPage1)
	ON_BN_CLICKED(IDC_BTN_SAVE, OnBtnSave)
	ON_BN_CLICKED(IDC_BTN_SAVE_AS, OnBtnSaveAs)
	ON_BN_CLICKED(IDC_BTN_APPLY_MASK, OnBtnApplyMask)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

///////////////////////////////////////////////////////////////////////////////////////////////////
// CdlgSettingPage1 message handlers

BOOL CdlgSettingPage1::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here	

	this->InitUI();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

//-------------------------------------------------------------------------------------------------
void CdlgSettingPage1::InitUI()
{
	CEdit *pEdit;


	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_START_SN);
	pEdit->SetLimitText(SN_LEN);

    pEdit = (CEdit*)GetDlgItem(IDC_EDIT_END_SN);
	pEdit->SetLimitText(SN_LEN);

    pEdit = (CEdit*)GetDlgItem(IDC_EDIT_MASK);
	pEdit->SetLimitText(SN_LEN);

	return;
}

//-------------------------------------------------------------------------------------------------
int CdlgSettingPage1::Init(IN char *pMPIniFullPath, IN char *pSNIniFullPath)
{
	CString  StrMsg;
	BOOL     IsFileExist;
	char     SectionName[64];
	char     KeyValue[256];
    BOOL     IsSNIniExist;
	int      Rslt;


	IsFileExist = this->m_FileManager.IsFileExist(pMPIniFullPath);
	if (IsFileExist == FALSE) {
		StrMsg.Format("file is not exit. file = %s", pMPIniFullPath);
		MessageBox(StrMsg, NULL, MB_OK | MB_ICONERROR);
		return 1;
	}

	::memset(this->m_MPIniFullPath, 0, sizeof(this->m_MPIniFullPath));
	::strncpy(this->m_MPIniFullPath, pMPIniFullPath, sizeof(this->m_MPIniFullPath));


    ::memset(this->m_SNIniFullPath, 0, sizeof(this->m_SNIniFullPath));
    ::strncpy(this->m_SNIniFullPath, pSNIniFullPath, sizeof(this->m_SNIniFullPath));

    
    IsSNIniExist = this->m_FileManager.IsFileExist(pSNIniFullPath);


    //======================================================
	//               [Setting] section
	//======================================================
	::memset(SectionName, 0, sizeof(SectionName));
	::strcpy(SectionName, "Setting");


	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(pMPIniFullPath, SectionName, "Port_Alignment_Mode", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_PortAlignmentMode = ::atoi(KeyValue);


	::memset(KeyValue, 0, sizeof(KeyValue));
    if (IsSNIniExist == TRUE) {
        Rslt = this->m_FileManager.ReadIniFile(pSNIniFullPath, SectionName, "Start_SN", KeyValue, sizeof(KeyValue));
    }
    else {
        Rslt = this->m_FileManager.ReadIniFile(pMPIniFullPath, SectionName, "Start_SN", KeyValue, sizeof(KeyValue));
    }
    if (Rslt != 0) {
        ::strcpy(KeyValue, "0");  // default value
    }
	::memset(this->m_StartSN, 0, sizeof(this->m_StartSN));
	::strncpy(this->m_StartSN, KeyValue, SN_LEN);


    ::memset(KeyValue, 0, sizeof(KeyValue));
    if (IsSNIniExist == TRUE) {
        Rslt = this->m_FileManager.ReadIniFile(pSNIniFullPath, SectionName, "End_SN", KeyValue, sizeof(KeyValue));
    }
    else {
        Rslt = this->m_FileManager.ReadIniFile(pMPIniFullPath, SectionName, "End_SN", KeyValue, sizeof(KeyValue));
    }
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	::memset(this->m_EndSN, 0, sizeof(this->m_EndSN));
	::strncpy(this->m_EndSN, KeyValue, SN_LEN);


    ::memset(KeyValue, 0, sizeof(KeyValue));
    if (IsSNIniExist == TRUE) {
        Rslt = this->m_FileManager.ReadIniFile(pSNIniFullPath, SectionName, "Mask_SN", KeyValue, sizeof(KeyValue));
    }
    else {
        Rslt = this->m_FileManager.ReadIniFile(pMPIniFullPath, SectionName, "Mask_SN", KeyValue, sizeof(KeyValue));
    }
	if (Rslt != 0) {
		::strcpy(KeyValue, "#");  // default value
	}
	::memset(this->m_Mask, 0, sizeof(this->m_Mask));
	::strncpy(this->m_Mask, KeyValue, SN_LEN);


	// update setting to UI
	this->SettingToUI();

	return 0;
}

//-------------------------------------------------------------------------------------------------
void CdlgSettingPage1::SettingToUI()
{
	CEdit  *pEdit;


	//======================================================
	//               setting group
	//======================================================
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_START_SN);
	pEdit->SetWindowText(this->m_StartSN);

    pEdit = (CEdit*)GetDlgItem(IDC_EDIT_END_SN);
	pEdit->SetWindowText(this->m_EndSN);

    pEdit = (CEdit*)GetDlgItem(IDC_EDIT_MASK);
	pEdit->SetWindowText(this->m_Mask);


	return;
}

//-------------------------------------------------------------------------------------------------
int CdlgSettingPage1::UIToSetting()
{
	CEdit  *pEdit;
    int    Rslt;


	//======================================================
	//               setting group
	//======================================================
    char  TempStartSN[SN_LEN + 1] = {0};
    char  TempEndSN[SN_LEN + 1]   = {0};
    char  TempMask[SN_LEN + 1]    = {0};

		
    pEdit = (CEdit*)GetDlgItem(IDC_EDIT_START_SN);
	pEdit->GetWindowText(TempStartSN, sizeof(TempStartSN));
    	
    pEdit = (CEdit*)GetDlgItem(IDC_EDIT_END_SN);
	pEdit->GetWindowText(TempEndSN, sizeof(TempEndSN));
    
    pEdit = (CEdit*)GetDlgItem(IDC_EDIT_MASK);
	pEdit->GetWindowText(TempMask, sizeof(TempMask));

    CSNManager SNManager;
    Rslt = SNManager.Init(TempStartSN, TempEndSN, TempMask);
    if (Rslt != 0) {
        MessageBox("incorrect SN format", NULL, MB_OK | MB_ICONERROR);
        return 1;
    }

	::memset(this->m_StartSN, 0, sizeof(this->m_StartSN));
	::strncpy(this->m_StartSN, TempStartSN, SN_LEN);

	::memset(this->m_EndSN, 0, sizeof(this->m_EndSN));
	::strncpy(this->m_EndSN, TempEndSN, SN_LEN);

    ::memset(this->m_Mask, 0, sizeof(this->m_Mask));
    pEdit = (CEdit*)GetDlgItem(IDC_EDIT_MASK);
	pEdit->GetWindowText(this->m_Mask, sizeof(this->m_Mask));


	return 0;
}

//-------------------------------------------------------------------------------------------------
int CdlgSettingPage1::SaveSetting()
{
	char  SectionName[64];
	int   Rslt;


	//=============================================================
	//                  [Setting] section
    //=============================================================
	::memset(SectionName, 0, sizeof(SectionName));
	::strcpy(SectionName, "Setting");

	Rslt = this->m_FileManager.WriteIniFile(this->m_MPIniFullPath, SectionName, "Start_SN", this->m_StartSN);
	if (Rslt != 0) {
		MessageBox("save Start_SN fail", NULL, MB_OK | MB_ICONERROR);
		return 1;
	}

    Rslt = this->m_FileManager.WriteIniFile(this->m_MPIniFullPath, SectionName, "End_SN", this->m_EndSN);
	if (Rslt != 0) {
		MessageBox("save End_SN fail", NULL, MB_OK | MB_ICONERROR);
		return 1;
	}

    Rslt = this->m_FileManager.WriteIniFile(this->m_MPIniFullPath, SectionName, "Mask_SN", this->m_Mask);
	if (Rslt != 0) {
		MessageBox("save Mask_SN fail", NULL, MB_OK | MB_ICONERROR);
		return 1;
    }

	return 0;
}

//-------------------------------------------------------------------------------------------------
int CdlgSettingPage1::SaveCurrentSN()
{
	char  SectionName[64];
	int   Rslt;


	//=============================================================
	//                  [Setting] section
    //=============================================================
	::memset(SectionName, 0, sizeof(SectionName));
	::strcpy(SectionName, "Setting");

	Rslt = this->m_FileManager.WriteIniFile(this->m_SNIniFullPath, SectionName, "Start_SN", this->m_StartSN);
	if (Rslt != 0) {
		MessageBox("save Start_SN fail", NULL, MB_OK | MB_ICONERROR);
		return 1;
	}

    Rslt = this->m_FileManager.WriteIniFile(this->m_SNIniFullPath, SectionName, "End_SN", this->m_EndSN);
	if (Rslt != 0) {
		MessageBox("save End_SN fail", NULL, MB_OK | MB_ICONERROR);
		return 1;
	}


    Rslt = this->m_FileManager.WriteIniFile(this->m_SNIniFullPath, SectionName, "Mask_SN", this->m_Mask);
	if (Rslt != 0) {
		MessageBox("save Mask_SN fail", NULL, MB_OK | MB_ICONERROR);
		return 1;
	}

	return 0;
}

//-------------------------------------------------------------------------------------------------
bool CdlgSettingPage1::IsHexNumString(IN char *pStr, IN int StrLen)
{
	for (int i = 0; i < StrLen; i++) {
		if (!::isxdigit(pStr[i])) {
            return false;
        }
	}
    
    return true;
}

//-------------------------------------------------------------------------------------------------
void CdlgSettingPage1::OnBtnSave() 
{
	// TODO: Add your control notification handler code here
	
	int   Rslt;
	

	Rslt = this->UIToSetting();
    if (Rslt != 0) {
		return;
	}
    
    // also save to c:/SSD_SN.ini
	Rslt = this->SaveCurrentSN();
	if (Rslt != 0) {
		return;
	}


	// re-init g_SNManager
	::SendMessage(AfxGetMainWnd()->m_hWnd, WM_CHANGE_SN, 0, 0);

    
	// save to SSDMP.ini
    Rslt = this->SaveSetting();
	if (Rslt != 0) {
		return;
	}
	

	MessageBox("save successfully", NULL, MB_OK);

	return;
}

//-------------------------------------------------------------------------------------------------
void CdlgSettingPage1::OnBtnSaveAs() 
{
	// TODO: Add your control notification handler code here
	
}

//-------------------------------------------------------------------------------------------------
void CdlgSettingPage1::OnBtnApplyMask() 
{
	// TODO: Add your control notification handler code here
	
	CEdit  *pEdit;
	char   TempMask[SN_LEN + 1];	
	char   TempStartSN[SN_LEN + 1];
	char   TempEndSN[SN_LEN + 1];
	

	::memset(TempStartSN, 0, sizeof(TempStartSN));
    pEdit = (CEdit*)GetDlgItem(IDC_EDIT_START_SN);
	pEdit->GetWindowText(TempStartSN, sizeof(TempStartSN));
    
	::memset(TempEndSN, 0, sizeof(TempEndSN));
    pEdit = (CEdit*)GetDlgItem(IDC_EDIT_END_SN);
	pEdit->GetWindowText(TempEndSN, sizeof(TempEndSN));

	::memset(TempMask, 0, sizeof(TempMask));
    pEdit = (CEdit*)GetDlgItem(IDC_EDIT_MASK);
	pEdit->GetWindowText(TempMask, sizeof(TempMask));


	// set mask
	this->SetMask(TempStartSN, TempMask);
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_START_SN);
	pEdit->SetWindowText(TempStartSN);

	this->SetMask(TempEndSN, TempMask);
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_END_SN);
	pEdit->SetWindowText(TempEndSN);

	return;
}

//-------------------------------------------------------------------------------------------------
void CdlgSettingPage1::SetMask(OUT char *pStr, IN char *pMask)
{
	int Len = (::strlen(pStr) > (::strlen(pMask))) ? (::strlen(pMask)) : (::strlen(pStr));
	
	for (int i = 0; i < Len; i++) {
		if (pMask[i] == '#') {
			continue;
		}

		pStr[i] = pMask[i];
	}

	return;
}

//-------------------------------------------------------------------------------------------------
