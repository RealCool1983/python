// dlgMPPage.cpp : implementation file
//

#include "stdafx.h"
#include "SSDMP.h"
#include "dlgMPPage.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


//-------------------------------------------------------------------------------------------------

// status bar column index
enum ENUM_STATUS_BAR_COLUMN {
    TOTAL_COUNT_COLUMN,
    PASS_COUNT_COLUMN,
    FAIL_COUNT_COLUMN,
	KEY_PRO_COUNT_COLUMN,
    RESERVE_COLUMN,
    SYS_TIME_COLUMN,
    COLUMN_COUNT  // for record toatl item count
};


enum ENUM_MP_LIST_CTRL_COLUMN_INDEX
{
	NUMBER_INDEX,
	PORT_INDEX,
	DRIVE_NUM_INDEX,
	PROGRESS_INDEX,
	STATUS_INDEX,
    CAPACITY_INDEX
};


MP_LIST_CTRL_FORMAT g_MPListCtrlFormat[] =
{
	// column caption  alignment       column width  column index
	{"No",             LVCFMT_CENTER,  70,           NUMBER_INDEX},
	{"Item",           LVCFMT_CENTER,  130,          PORT_INDEX},
	{"Drive Num",      LVCFMT_CENTER,  115,          DRIVE_NUM_INDEX},
	{"Progress",       LVCFMT_CENTER,  230,          PROGRESS_INDEX},
	{"Status",         LVCFMT_CENTER,  100,          STATUS_INDEX},
    {"Capacity",       LVCFMT_CENTER,  100,          CAPACITY_INDEX},
};


// timer number
#define  TIMER_SYS_TIME    (1)


//-------------------------------------------------------------------------------------------------


///////////////////////////////////////////////////////////////////////////////////////////////////
// CdlgMPPage dialog


CdlgMPPage::CdlgMPPage(CWnd* pParent /*=NULL*/)
	: CDialog(CdlgMPPage::IDD, pParent)
{
	//{{AFX_DATA_INIT(CdlgMPPage)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CdlgMPPage::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CdlgMPPage)
	DDX_Control(pDX, IDC_STATIC_DESCRIPTION, m_StaticDescription);
	DDX_Control(pDX, IDC_LIST_MP_INFO, m_ListCtrlMPInfo);
	DDX_Control(pDX, IDC_STATIC_RUNTIME, m_StaticRunTime);
	DDX_Control(pDX, IDC_STATIC_RUNTIME2, m_StaticRunTime_title);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CdlgMPPage, CDialog)
	//{{AFX_MSG_MAP(CdlgMPPage)
	ON_BN_CLICKED(IDC_BTN_START, OnBtnStart)
	ON_BN_CLICKED(IDC_BTN_SCAN, OnBtnScan)
	ON_WM_TIMER()
	ON_NOTIFY(NM_DBLCLK, IDC_LIST_MP_INFO, OnDblclkListMpInfo)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

///////////////////////////////////////////////////////////////////////////////////////////////////
// CdlgMPPage message handlers

BOOL CdlgMPPage::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	
    this->InitUI();
    this->InitStatusBar(&this->m_StatusBar);
    
    SetTimer(TIMER_SYS_TIME, 500, NULL);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

//-------------------------------------------------------------------------------------------------
int CdlgMPPage::Init(IN PORT_DATA *pPortData, IN char *pCommonBurnerFullPath)
{
	CString  StrMsg;
	BOOL     IsFileExist;


	this->m_pPortData = pPortData;

	IsFileExist = this->m_FileManager.IsFileExist(pCommonBurnerFullPath);
	if (IsFileExist == FALSE) {
		StrMsg.Format("common burner doesn't exist. path = %s", pCommonBurnerFullPath);
		MessageBox(StrMsg, NULL, MB_OK | MB_ICONERROR);
		return 1;
	}
    ::memset(this->m_CommonBurnerFullPath, 0, sizeof(this->m_CommonBurnerFullPath));
    ::strncpy(this->m_CommonBurnerFullPath, pCommonBurnerFullPath, MAX_PATH);

	return 0;
}

//-------------------------------------------------------------------------------------------------
void CdlgMPPage::InitUI()
{
    int ColumnCount;


    // IDC_LIST_MP_INFO list control
	ColumnCount = sizeof(g_MPListCtrlFormat) / sizeof(MP_LIST_CTRL_FORMAT);
	this->InitListCtrl(&this->m_ListCtrlMPInfo, g_MPListCtrlFormat, ColumnCount);


    // IDC_STATIC_DESCRIPTION static control
    this->m_StaticDescription.SetBold(TRUE);
	this->m_StaticDescription.SetFont(_T("Arial"),  46);
	this->m_StaticDescription.SetTextColor(COLOR_RED);
	
	
	this->m_StaticRunTime.SetFontSize(27);	
	this->m_StaticRunTime.SetTextColor(RGB(64, 64, 64));
	this->m_StaticRunTime.SetText(_T("00:00"));
	this->m_StaticRunTime.SetFontBold(true);
	this->m_StaticRunTime.SetBkColor(RGB(192, 192, 192));

	this->m_StaticRunTime_title.SetTextColor(RGB(96, 96, 96));
	this->m_StaticRunTime_title.SetFontBold(true);
	
	
    return;
}

//-------------------------------------------------------------------------------------------------
/*
void CdlgMPPage::InitListCtrl(IN CXListCtrl *pList)
{
	LV_COLUMN  lvcolumn;
	CRect      Rect;
	DWORD      ExStyle;
	int        i;


    char *pHeaders[] = {"No", "Item", "Drive Num", "Progress", "Status", NULL};
    int  ColWidths[] = {10, 15, 15, 40, 20};  // total sum = 100

	// set style
	ExStyle = LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES;
	this->m_ListCtrlMPInfo.SetExtendedStyle(ExStyle);
	

	// set font
	this->m_ListCtrlFont.CreatePointFont(110, "Arial");
    this->m_ListCtrlMPInfo.SetFont(&this->m_ListCtrlFont);    


	// add columns according to window rect
	pList->GetWindowRect(&Rect);

	for (i = 0; ;i++) {
		if (pHeaders[i] == NULL) {
			break;
		}

		::memset(&lvcolumn, 0, sizeof(lvcolumn));

		lvcolumn.mask     = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
		lvcolumn.fmt      = LVCFMT_CENTER;
		lvcolumn.pszText  = pHeaders[i];
		lvcolumn.iSubItem = i;
		lvcolumn.cx       = ((Rect.Width() - 2) * ColWidths[i]) / 100;
		pList->InsertColumn(i, &lvcolumn);
	}


	// iterate through header items and attach the image list
	HDITEM hditem;

	for (i = 0; i < pList->m_HeaderCtrl.GetItemCount(); i++) {
		hditem.mask = HDI_IMAGE | HDI_FORMAT;
		pList->m_HeaderCtrl.GetItem(i, &hditem);
		hditem.fmt |=  HDF_IMAGE;
		if (i == 0) {
			hditem.iImage = XHEADERCTRL_UNCHECKED_IMAGE;
		}
		else {
			hditem.iImage = XHEADERCTRL_NO_IMAGE;
		}

		pList->m_HeaderCtrl.SetItem(i, &hditem);
	}	


	// insert row
	for (i = 0; i < SUPPORT_PORT_COUNT; i++) {
		CString Str;
		Str.Format(_T("%d"), i);
		pList->InsertItem(i, Str);
		
        // set this column "check box attribute"
        pList->SetCheckbox(i, NUMBER_COLUMN, 0);

		Str.Format("Port %d", i);
		pList->SetItemText(i, PORT_COLUMN, Str);

        // set this column "progress attribute"
		pList->SetProgress(i, PROGRESS_COLUMN);
	}

	return;
}
*/

//-------------------------------------------------------------------------------------------------
void CdlgMPPage::InitListCtrl(IN CXListCtrl *pListCtrl, IN MP_LIST_CTRL_FORMAT *pListFormat, IN int ColumnCount)
{
	LV_COLUMN  lvcolumn;
	CRect      Rect;
	DWORD      ExStyle;
	int        i;


	// set style
	ExStyle = LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES;
	pListCtrl->SetExtendedStyle(ExStyle);
    
    // set font
    this->m_ListCtrlFont.CreatePointFont(110, "Arial");
    this->m_ListCtrlMPInfo.SetFont(&this->m_ListCtrlFont);
    

	// add columns according to window rect
	pListCtrl->GetWindowRect(&Rect);
	
	for (i = 0; i < ColumnCount; i++) {
		::memset(&lvcolumn, 0, sizeof(lvcolumn));

		lvcolumn.mask     = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
		lvcolumn.fmt      = pListFormat[i].Alignment;
		lvcolumn.pszText  = pListFormat[i].Title;
		lvcolumn.iSubItem = pListFormat[i].ColumnIndex;
		/*
		lvcolumn.cx       = ((Rect.Width() - 2) * g_DefectListCtrlFormat[i].Width) / 100;
		*/
		lvcolumn.cx = pListFormat[i].Width;
		pListCtrl->InsertColumn(pListFormat[i].ColumnIndex, &lvcolumn);
	}

    // iterate through header items and attach the image list
	HDITEM hditem;

	for (i = 0; i < pListCtrl->m_HeaderCtrl.GetItemCount(); i++) {
		hditem.mask = HDI_IMAGE | HDI_FORMAT;
		pListCtrl->m_HeaderCtrl.GetItem(i, &hditem);
		hditem.fmt |=  HDF_IMAGE;
		if (i == 0) {
			hditem.iImage = XHEADERCTRL_UNCHECKED_IMAGE;
		}
		else {
			hditem.iImage = XHEADERCTRL_NO_IMAGE;
		}

		pListCtrl->m_HeaderCtrl.SetItem(i, &hditem);
	}	


	// insert row
	for (i = 0; i < SUPPORT_PORT_COUNT; i++) {
		CString Str;
		Str.Format(_T("%d"), i);
		pListCtrl->InsertItem(i, Str);
		
        // set this column "check box attribute"
        pListCtrl->SetCheckbox(i, NUMBER_INDEX, 0);

		Str.Format("Port %d", i);
		pListCtrl->SetItemText(i, PORT_INDEX, Str);

        // set this column "progress attribute"
		pListCtrl->SetProgress(i, PROGRESS_INDEX);
	}

	return;
}

//-------------------------------------------------------------------------------------------------
void CdlgMPPage::InitStatusBar(IN CStatusBar *pStatusBar)
{
    const COLORREF DEEP_GRAY  = RGB(225, 225, 225);
    const int TestCountColumn   = 100;
	const int PassCountColumn   = 100;	
	const int FailCountColumn   = 100;
	const int KeyProCountColumn = 80;
    const int SytTimeColumn     = 110;


    pStatusBar->Create(this);  // create the status bar
	pStatusBar->SetIndicators(NULL, COLUMN_COUNT);  // Set the number of panes

    CRect rect;
	GetClientRect(&rect);

	// size the two panes
    int Ramin = rect.Width() - (TestCountColumn + PassCountColumn + FailCountColumn + KeyProCountColumn + SytTimeColumn);
	pStatusBar->SetPaneInfo(TOTAL_COUNT_COLUMN, NULL, SBPS_NORMAL, TestCountColumn);
	pStatusBar->SetPaneInfo(PASS_COUNT_COLUMN, NULL, SBPS_NORMAL, PassCountColumn);
	pStatusBar->SetPaneInfo(FAIL_COUNT_COLUMN, NULL, SBPS_NORMAL, FailCountColumn);
    pStatusBar->SetPaneInfo(KEY_PRO_COUNT_COLUMN, NULL, SBPS_NORMAL, KeyProCountColumn);
	pStatusBar->SetPaneInfo(RESERVE_COLUMN, NULL, SBPS_NORMAL, Ramin);
    pStatusBar->SetPaneInfo(SYS_TIME_COLUMN, NULL, SBPS_NORMAL, SytTimeColumn);

    // this is where we actually draw it on the screen
	RepositionBars(AFX_IDW_CONTROLBAR_FIRST, AFX_IDW_CONTROLBAR_LAST, NULL);	
    
    // seems not works under windows 10 with xp style ui
	pStatusBar->GetStatusBarCtrl().SetBkColor(DEEP_GRAY);


    pStatusBar->SetPaneText(TOTAL_COUNT_COLUMN, "Total: 0");
    pStatusBar->SetPaneText(PASS_COUNT_COLUMN, "Pass: 0");
    pStatusBar->SetPaneText(FAIL_COUNT_COLUMN, "Fail: 0");
	pStatusBar->SetPaneText(KEY_PRO_COUNT_COLUMN, "Key: 0");

    return;
}

//-------------------------------------------------------------------------------------------------
void CdlgMPPage::OnBtnStart() 
{
	// TODO: Add your control notification handler code here
	
    ::SendMessage(AfxGetMainWnd()->m_hWnd, WM_START_RUN, 0, 0);
    return;
}

//-------------------------------------------------------------------------------------------------
void CdlgMPPage::OnBtnScan() 
{
	// TODO: Add your control notification handler code here

    ::SendMessage(AfxGetMainWnd()->m_hWnd, WM_SCAN_DRIVE, 0, 0);
    return;
}

//-------------------------------------------------------------------------------------------------
void CdlgMPPage::EnableAllUI(IN bool IsEnable)
{	
	GetDlgItem(IDC_BTN_START)->EnableWindow(IsEnable);
	GetDlgItem(IDC_BTN_SCAN)->EnableWindow(IsEnable);
	this->m_ListCtrlMPInfo.EnableWindow(IsEnable);

	return;
}

//-------------------------------------------------------------------------------------------------
void CdlgMPPage::EnableRunTimer(IN bool IsEnable)
{	
	if(IsEnable)
	{
		nRunTimeSec = 0;
		nRunTimeMin = 0;
		SetTimer(777, 1000, NULL);
	}
	else
	{
		KillTimer(777);
	}
	return;
}


//-------------------------------------------------------------------------------------------------
void CdlgMPPage::UpdatePortDataUI(IN PORT_DATA *pPortData)
{
	COLORREF  crText;
    COLORREF  crBackground;
    char      Temp[16];

    
    if (pPortData->PhyDrvNum == -1) {
        this->m_ListCtrlMPInfo.SetCheckbox(pPortData->MapIndex, NUMBER_INDEX, 0);       // set check box uncheck state
        this->m_ListCtrlMPInfo.SetItemText(pPortData->MapIndex, DRIVE_NUM_INDEX, "");
        this->m_ListCtrlMPInfo.UpdateProgress(pPortData->MapIndex, PROGRESS_INDEX, 0);  // set progress to 0
        this->m_ListCtrlMPInfo.SetItemText(pPortData->MapIndex, STATUS_INDEX, "");
        this->m_ListCtrlMPInfo.SetItemText(pPortData->MapIndex, CAPACITY_INDEX, "");
    }
    else {
        this->m_ListCtrlMPInfo.SetCheckbox(pPortData->MapIndex, NUMBER_INDEX, 1);  // assign to check box attribute
        
        ::memset(Temp, 0, sizeof(Temp));
        ::sprintf(Temp, "%d", pPortData->PhyDrvNum);
        this->m_ListCtrlMPInfo.SetItemText(pPortData->MapIndex, DRIVE_NUM_INDEX, Temp);
        
		this->m_ListCtrlMPInfo.GetItemColors(pPortData->MapIndex, STATUS_INDEX, crText, crBackground);
        this->m_ListCtrlMPInfo.SetItemText(pPortData->MapIndex, STATUS_INDEX, DRIVE_READY, COLOR_BLUE, crBackground);
		
		::memset(Temp, 0, sizeof(Temp));
		/*
		if (pPortData->CardSize >= 2097152) {  // if over 1GB size, use GB to be the unit
			double GB = this->UINT64ToDouble(pPortData->CardSize) / 2 / 1024 / 1024;
			::sprintf(Temp, "%.2f GB", GB);
		}
		else {  // use MB to be the unint
			UINT32 MB = pPortData->CardSize / 2 / 1024;
		    ::sprintf(Temp, "%d MB", MB);
		}
		*/
		if (pPortData->IdentifyDevice.Number_Of_User_Addressable_Logical_Sectors >= 2097152) {  // if over 1GB size, use GB to be the unit
			double GB = this->UINT64ToDouble(pPortData->IdentifyDevice.Number_Of_User_Addressable_Logical_Sectors) / 2 / 1024 / 1024;
			::sprintf(Temp, "%.2f GB", GB);
		}
		else {  // use MB to be the unint
			UINT32 MB = pPortData->IdentifyDevice.Number_Of_User_Addressable_Logical_Sectors / 2 / 1024;
		    ::sprintf(Temp, "%d MB", MB);
		}
		
		this->m_ListCtrlMPInfo.SetItemText(pPortData->MapIndex, CAPACITY_INDEX, Temp);
    }
    
    return;
}

//-------------------------------------------------------------------------------------------------
void CdlgMPPage::ClearPort(IN int ItemIndex)
{
    this->m_ListCtrlMPInfo.SetCheckbox(ItemIndex, NUMBER_INDEX, 0);       // set check box uncheck state
    this->m_ListCtrlMPInfo.SetItemText(ItemIndex, DRIVE_NUM_INDEX, "");
    this->m_ListCtrlMPInfo.UpdateProgress(ItemIndex, PROGRESS_INDEX, 0);  // set progress to 0
    this->m_ListCtrlMPInfo.SetItemText(ItemIndex, STATUS_INDEX, "");
    this->m_ListCtrlMPInfo.SetItemText(ItemIndex, CAPACITY_INDEX, "");

    return;
}

//-------------------------------------------------------------------------------------------------
void CdlgMPPage::UpdatePhyDrvNum(IN int ItemIndex, IN int PhyDrvNum)
{
    char Buffer[16];
    
    
    ::memset(Buffer, 0, sizeof(Buffer));

    if (PhyDrvNum != -1) {
        ::sprintf(Buffer, "%d", PhyDrvNum);
    }
    
    this->m_ListCtrlMPInfo.SetItemText(ItemIndex, DRIVE_NUM_INDEX, Buffer);

    return;
}

//-------------------------------------------------------------------------------------------------
void CdlgMPPage::UpdateProgress(IN int ItemIndex, IN int Progress)
{
    this->m_ListCtrlMPInfo.UpdateProgress(ItemIndex, PROGRESS_INDEX, Progress);
    return;
}

//-------------------------------------------------------------------------------------------------
void CdlgMPPage::UpdateStatus(IN int ItemIndex, IN char *pStatus, COLORREF TextColor)
{
    COLORREF  crText;
    COLORREF  crBackground;
    
    
    this->m_ListCtrlMPInfo.GetItemColors(ItemIndex, STATUS_INDEX, crText, crBackground);
    this->m_ListCtrlMPInfo.SetItemText(ItemIndex, STATUS_INDEX, pStatus, TextColor, crBackground);
    
    return;
}

//-------------------------------------------------------------------------------------------------
void CdlgMPPage::UpdateCapacity(IN int ItemIndex, IN char *pStr)
{
    this->m_ListCtrlMPInfo.SetItemText(ItemIndex, CAPACITY_INDEX, pStr);
    
    return;
}

//-------------------------------------------------------------------------------------------------
void CdlgMPPage::ShowDescription(IN char *pStr)
{
    this->m_StaticDescription.SetWindowText(pStr);

    return;
}

//-------------------------------------------------------------------------------------------------
void CdlgMPPage::ShowErrorCode(IN int ItemIndex, IN int ErrorCode)
{
    COLORREF  crText;
    COLORREF  crBackground;
    char      Buffer[16];
    
    
    this->m_ListCtrlMPInfo.GetItemColors(ItemIndex, STATUS_INDEX, crText, crBackground);
    ::memset(Buffer, 0, sizeof(Buffer));
    
    if (ErrorCode == 0) {
        ::sprintf(Buffer, "%s", "pass");
        this->m_ListCtrlMPInfo.SetItemText(ItemIndex, STATUS_INDEX, Buffer, COLOR_GREEN, crBackground);
    }
    else {
        ::sprintf(Buffer, "%d", ErrorCode);
        this->m_ListCtrlMPInfo.SetItemText(ItemIndex, STATUS_INDEX, Buffer, COLOR_RED, crBackground);
    }
    
    return;
}

//-------------------------------------------------------------------------------------------------
BOOL CdlgMPPage::IsItemChecked(IN int ItemIndex)
{
    return (this->m_ListCtrlMPInfo.GetItemCheckedState(ItemIndex, NUMBER_INDEX) == 1) ? TRUE : FALSE;
}

//-------------------------------------------------------------------------------------------------
void CdlgMPPage::SetStatusBarTotalCount(IN int Count)
{
    char  Buffer[64];

    ::memset(Buffer, 0, sizeof(Buffer));
    ::sprintf(Buffer, "Total: %d", Count);
    this->m_StatusBar.SetPaneText(TOTAL_COUNT_COLUMN, Buffer);
}

//-------------------------------------------------------------------------------------------------
void CdlgMPPage::SetStatusBarPassCount(IN int Count)
{
    char Buffer[64];

    ::memset(Buffer, 0, sizeof(Buffer));
    ::sprintf(Buffer, "Pass: %d", Count);
    this->m_StatusBar.SetPaneText(PASS_COUNT_COLUMN, Buffer);
}

//-------------------------------------------------------------------------------------------------
void CdlgMPPage::SetStatusBarFailCount(IN int Count)
{
    char Buffer[64];

    ::memset(Buffer, 0, sizeof(Buffer));
    ::sprintf(Buffer, "Fail: %d", Count);
    this->m_StatusBar.SetPaneText(FAIL_COUNT_COLUMN, Buffer);
}

//-------------------------------------------------------------------------------------------------
void CdlgMPPage::SetStatusBarKeyProCount(IN int Count)
{
	char Buffer[64];

    ::memset(Buffer, 0, sizeof(Buffer));
    ::sprintf(Buffer, "Key: %d", Count);
    this->m_StatusBar.SetPaneText(KEY_PRO_COUNT_COLUMN, Buffer);
}

//-------------------------------------------------------------------------------------------------
void CdlgMPPage::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	
    SYSTEMTIME  SystemTime;
	char        Buffer[64];


    switch(nIDEvent) {
        case TIMER_SYS_TIME:
            // show system time
			::GetLocalTime(&SystemTime);
			::memset(Buffer, 0, sizeof(Buffer));
			::sprintf(Buffer, "%.2d:%.2d:%.2d", SystemTime.wHour, SystemTime.wMinute, SystemTime.wSecond);
			this->m_StatusBar.SetPaneText(SYS_TIME_COLUMN, Buffer);
            break;
		case 777:
			::memset(Buffer, 0, sizeof(Buffer));
			
			nRunTimeSec++;
			if ( nRunTimeSec == 59 )
			{
				nRunTimeSec = 0;
				nRunTimeMin++;			
			}
			::sprintf(Buffer, "%.2d:%.2d", nRunTimeMin, nRunTimeSec);
			SetDlgItemText(IDC_STATIC_RUNTIME,Buffer);
			break;
    }

	CDialog::OnTimer(nIDEvent);
}

//-------------------------------------------------------------------------------------------------
void CdlgMPPage::OnDblclkListMpInfo(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here

	int  SelectIndex;
	int  PhyDrvNum;
	int  Rslt;
	

	SelectIndex = this->m_ListCtrlMPInfo.GetSelectionMark();
	PhyDrvNum   = this->m_pPortData[SelectIndex].PhyDrvNum;

	if (PhyDrvNum == -1) {
		return;
	}

	Rslt = this->m_pPortData[SelectIndex].NandInfoManager.Init(PhyDrvNum, NULL, this->m_CommonBurnerFullPath);
	if (Rslt != 0) {
		MessageBox("nand info manager init fail", NULL, MB_OK | MB_ICONERROR);
	}
	
	
	CH_ID_INFO IdInfo = {0};
	cfg_tbl_nand_info_t NandInfo = {0};

	// if rom safe mode case, download common burner can't get nand info
	/*
	Rslt = this->m_pPortData[SelectIndex].NandInfoManager.GetNandInfo(&NandInfo);

	for (int ch = 0; ch < NandInfo.support_channel; ch++) {
		for (int ce = 0; ce < NandInfo.support_ce; ce++) {
			BYTE FlashID[FLASH_ID_LENGTH] = {0};
			Rslt = this->m_pPortData[SelectIndex].NandInfoManager.GetFlashID(ch, ce, FlashID);
			::memcpy(IdInfo.CH[ch].CE[ce].FlashID, FlashID, FLASH_ID_LENGTH);
		}
	}
	*/
	for (int ch = 0; ch < MAX_CH; ch++) {
		for (int ce = 0; ce < 4; ce++) {
			BYTE FlashID[FLASH_ID_LENGTH] = {0};
			Rslt = this->m_pPortData[SelectIndex].NandInfoManager.GetFlashID(ch, ce, FlashID);
			::memcpy(IdInfo.CH[ch].CE[ce].FlashID, FlashID, FLASH_ID_LENGTH);
		}
	}

	CdlgNandInfo dlg;
	dlg.Init(&IdInfo);
	dlg.DoModal();

	*pResult = 0;
}

//-------------------------------------------------------------------------------------------------
double CdlgMPPage::UINT64ToDouble(UINT64 ui64)
{
  __int64  i64 = (ui64 & 0x7FFFFFFFFFFFFFF);
  double   dbl = (double)i64;

  if (ui64 & 0x8000000000000000) {
	  dbl += (double) 0x8000000000000000;
  }

  return dbl;
}

//-------------------------------------------------------------------------------------------------



