// dlgShowCEPage.cpp : implementation file
//

#include "stdafx.h"
#include "SSDMP.h"
#include "dlgShowCEPage.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CdlgShowCEPage dialog


CdlgShowCEPage::CdlgShowCEPage(CWnd* pParent /*=NULL*/, IN const CH_ID_INFO *pIdInfo)
	: CDialog(CdlgShowCEPage::IDD, pParent)
{
	::memset(&this->m_IdInfo, 0, sizeof(CH_ID_INFO));
	::memcpy(&this->m_IdInfo, pIdInfo, sizeof(CH_ID_INFO));	
	//{{AFX_DATA_INIT(CdlgShowCEPage)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CdlgShowCEPage::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX,IDC_EDIT_DISPLAYALL_CH0,m_edit_show_ce0);
	DDX_Control(pDX,IDC_EDIT_DISPLAYALL_CH1,m_edit_show_ce1);
	//{{AFX_DATA_MAP(CdlgShowCEPage)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CdlgShowCEPage, CDialog)
	//{{AFX_MSG_MAP(CdlgShowCEPage)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()



/////////////////////////////////////////////////////////////////////////////
// CdlgShowCEPage message handlers

BOOL CdlgShowCEPage::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here

	this->InitUI();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CdlgShowCEPage::InitUI()
{

	CString Str, s_ShowAllCE;
	int i = 0;
	for(int j = 0 ; j < 4 ; j ++){
		Str.Format("%X  %X  %X  %X  %X  %X\r\n", this->m_IdInfo.CH[i].CE[j].FlashID[0],
                                 this->m_IdInfo.CH[i].CE[j].FlashID[1],
							     this->m_IdInfo.CH[i].CE[j].FlashID[2],
							     this->m_IdInfo.CH[i].CE[j].FlashID[3],
							     this->m_IdInfo.CH[i].CE[j].FlashID[4],
							     this->m_IdInfo.CH[i].CE[j].FlashID[5]);
		s_ShowAllCE += Str;
	}
	m_edit_show_ce0.SetWindowText(s_ShowAllCE);
	UpdateData(FALSE);

	i = 1;
	s_ShowAllCE = "";
	for(j = 0 ; j < 4 ; j ++){
		Str.Format("%X  %X  %X  %X  %X  %X\r\n", this->m_IdInfo.CH[i].CE[j].FlashID[0],
                                 this->m_IdInfo.CH[i].CE[j].FlashID[1],
							     this->m_IdInfo.CH[i].CE[j].FlashID[2],
							     this->m_IdInfo.CH[i].CE[j].FlashID[3],
							     this->m_IdInfo.CH[i].CE[j].FlashID[4],
							     this->m_IdInfo.CH[i].CE[j].FlashID[5]);
		s_ShowAllCE += Str;
	}	

	m_edit_show_ce1.SetWindowText(s_ShowAllCE);
	UpdateData(FALSE);

	//pWnd = GetDlgItem(IDC_EDIT_DISPLAYALL_CH0)->SetWindowText(_T(str));
	// pEdit = (CEdit*)GetDlgItem(IDC_EDIT_DISPLAYALL_CH0);
	// pEdit->SetFont(m_pListFont);
	// pEdit->SetWindowText(str);

	//CH_ID_INFO IdInfo = {0};
	//cfg_tbl_nand_info_t NandInfo = {0};
	return;
}

