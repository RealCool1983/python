// MTableManager.cpp: implementation of the CMTableManager class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SSDMP.h"
#include "MTableManager.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

///////////////////////////////////////////////////////////////////////////////////////////////////
// Construction/Destruction
///////////////////////////////////////////////////////////////////////////////////////////////////

CMTableManager::CMTableManager()
{
	this->m_Item.clear();
}

//-------------------------------------------------------------------------------------------------
CMTableManager::~CMTableManager()
{
	this->m_Item.clear();
}

//-------------------------------------------------------------------------------------------------
int CMTableManager::Init(IN BYTE *pFlashID, IN char *pMTableFullPath)
{
    BOOL  IsFileExist;
	int   Rslt;


	::memset(this->m_FlashID, 0, FLASH_ID_LENGTH);
	::memcpy(this->m_FlashID, pFlashID, FLASH_ID_LENGTH);

	::memset(this->m_MTableFullPath, 0, sizeof(this->m_MTableFullPath));
	::strncpy(this->m_MTableFullPath, pMTableFullPath, sizeof(this->m_MTableFullPath));

	IsFileExist = this->m_FileManager.IsFileExist(this->m_MTableFullPath);
	if (IsFileExist == FALSE) {
		return 1;
	}


	// parse mapping table by flash id
	this->m_Item.clear();

	Rslt = this->ParseMTable(this->m_FlashID, this->m_MTableFullPath);
	if (Rslt != 0) {
		return 1;
	}

	return 0;
}

//-------------------------------------------------------------------------------------------------
int CMTableManager::GetItem(OUT SETTING_ITEM *pItem, IN int Index)
{
	int size = this->m_Item.size();
	if (Index > (this->m_Item.size() - 1)) {
		return 1;
	}

	*pItem = this->m_Item[Index];

	return 0;
}

//-------------------------------------------------------------------------------------------------
int CMTableManager::GetItemCount()
{
	return this->m_Item.size();
}

//-------------------------------------------------------------------------------------------------
int CMTableManager::ParseMTable(IN BYTE *pFlashID, IN char *pMTableFullPath)
{
	SETTING_ITEM  Item;
	char          *pSection;
	char          KeyName[16];
	char          Buffer[MAX_PATH];
	BYTE          TempID[FLASH_ID_LENGTH + 1];
	int           Rslt;


	switch (pFlashID[0]) {
	    case 0x98:  pSection = SECTION_HEADER_TOSHIBA;  break;
		case 0xAD:  pSection = SECTION_HEADER_HYNIX;    break;
		case 0x89:  pSection = SECTION_HEADER_INTEL;    break;
        case 0x2C:  pSection = SECTION_HEADER_MICRON;   break;
		case 0xEC:  pSection = SECTION_HEADER_SAMSUNG;  break;
		case 0x45:  pSection = SECTION_HEADER_SANDISK;  break;
		default:  return 1;
	}		
	

	for (int i = 0; i <= ITEM_COUNT; i++) {
		::memset(KeyName, 0, sizeof(KeyName));
		::sprintf(KeyName, "ID_%d", i);
		::memset(Buffer, 0, sizeof(Buffer));
		Rslt = this->m_FileManager.ReadIniFile(pMTableFullPath, pSection, KeyName, Buffer, MAX_PATH);
		if (Rslt != 0) {
			continue;
		}

		
		// compare id
		::memset(TempID, 0, sizeof(TempID));
        ::sscanf(Buffer, "%2hx %2hx %2hx %2hx %2hx %2hx", &TempID[0],
			                                              &TempID[1],
														  &TempID[2],
														  &TempID[3],
														  &TempID[4],
														  &TempID[5]);

		if (::memcmp(pFlashID, TempID, FLASH_ID_LENGTH) != 0) {
			continue;
		}


		// read possible ini / fw full path
		::memset(&Item, 0, sizeof(SETTING_ITEM));
		
		::memset(KeyName, 0, sizeof(KeyName));
		::sprintf(KeyName, "Task_%d", i);
		this->m_FileManager.ReadIniFile(pMTableFullPath, pSection, KeyName, Buffer, MAX_PATH);
		Item.Task = this->GetTask(Buffer);

		::memset(KeyName, 0, sizeof(KeyName));
		::sprintf(KeyName, "FW_%d", i);
		Rslt = this->m_FileManager.ReadIniFile(pMTableFullPath, pSection, KeyName, Buffer, MAX_PATH);
		if (Rslt == 0) {
			::strncpy(Item.FwFullPath, Buffer, sizeof(Item.FwFullPath));
		}

		::memset(KeyName, 0, sizeof(KeyName));
		::sprintf(KeyName, "INI_%d", i);
		Rslt = this->m_FileManager.ReadIniFile(pMTableFullPath, pSection, KeyName, Buffer, MAX_PATH);
		if (Rslt == 0) {
			::strncpy(Item.IniFullPath, Buffer, sizeof(Item.IniFullPath));
		}

		::memset(KeyName, 0, sizeof(KeyName));
		::sprintf(KeyName, "Comment_%d", i);
		Rslt = this->m_FileManager.ReadIniFile(pMTableFullPath, pSection, KeyName, Buffer, MAX_PATH);
		if (Rslt == 0) {
			::strncpy(Item.Comment, Buffer, sizeof(Item.Comment));
		}

		// add setting item
		this->m_Item.push_back(Item);
	}

	return 0;
}

//-------------------------------------------------------------------------------------------------
int CMTableManager::GetTask(IN char *pKeyWord)
{
	if (::stricmp(pKeyWord, "FTA") == 0) {
		return FTA_FLOW;
	}
	else if (::stricmp(pKeyWord, "FTB") == 0) {
		return FTB_FLOW;
	}
	else if (::stricmp(pKeyWord, "QC") == 0) {
		return QC_FLOW;
	}

	return UNKNOW_TASK;
}

//-------------------------------------------------------------------------------------------------


