// LogManager.h: interface for the CLogManager class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LOGMANAGER_H__F6876251_932B_47E7_82CD_4F1B7BC28567__INCLUDED_)
#define AFX_LOGMANAGER_H__F6876251_932B_47E7_82CD_4F1B7BC28567__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


//-------------------------------------------------------------------------------------------------
#include "FileManager.h"


//-------------------------------------------------------------------------------------------------
class CLogManager  
{
public:
	CLogManager();
	virtual ~CLogManager();

    
    int   Init(IN TCHAR *pLogFullPath, IN TCHAR *pOpenMode);
    
    // interface
    void   DebugMsg(IN TCHAR *pFormat, ...);
	void   LogToFile(IN bool IsRecordTime, IN bool IsWithNewLine, IN TCHAR *pFormat, ...);
    TCHAR  *GetLogFullPath();
    TCHAR  *GetLogPath();
    TCHAR  *GetLogName();
    bool   IsInitSucceed();
    

    
private:
    void  InitMember();
    
    
    CRITICAL_SECTION  m_CriticalSection;
    CFileManager      m_FileManager;
    TCHAR             m_LogFullPath[MAX_PATH];
    TCHAR             m_LogPath[MAX_PATH];
    TCHAR             m_LogName[_MAX_FNAME];
    TCHAR             m_OpenMode[8];  // open file mode
    bool              m_InitSucceed;
};

//-------------------------------------------------------------------------------------------------

#endif // !defined(AFX_LOGMANAGER_H__F6876251_932B_47E7_82CD_4F1B7BC28567__INCLUDED_)
