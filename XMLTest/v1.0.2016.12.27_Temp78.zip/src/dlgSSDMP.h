// dlgSSDMP.h : header file
//

#if !defined(AFX_DLGSSDMP_H__1DAD9E33_1A97_4131_B523_C9D9F569A24A__INCLUDED_)
#define AFX_DLGSSDMP_H__1DAD9E33_1A97_4131_B523_C9D9F569A24A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


//-------------------------------------------------------------------------------------------------
// standard header
#include <Dbt.h>      // for using struct PDEV_BROADCAST_HDR ...
#include <process.h>  // for using _beginthreadex
#pragma comment(lib, "Version.lib")
#pragma comment(lib, "SHELL32.lib")
//C:\\Program Files (x86)\\Windows Kits\\8.0\\Lib\\win8\\um\\x86
// user header
#include "ErrorCode.h"
#include "MPDefine.h"
#include "dlgMPPage.h"
#include "dlgSettingPage1.h"
#include "dlgSettingPage2.h"
#include "dlgRDTResultPage.h"
#include "FileManager.h"
#include "MPIniManager.h"
#include "UserDefineHubMapManager.h"
#include "Volume.h"
#include "HubManager.h"
#include "SSD_Utility.h"
#include "SNManager.h"
#include "KeyProGen.h"
#include "NandInfoManager.h"

//-------------------------------------------------------------------------------------------------

///////////////////////////////////////////////////////////////////////////////////////////////////
// CdlgSSDMP dialog

class CdlgSSDMP : public CDialog
{
// Construction
public:
	CdlgSSDMP(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CdlgSSDMP)
	enum { IDD = IDD_SSDMP_DIALOG };
	CTabCtrl	m_TabMainSheet;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CdlgSSDMP)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	virtual LRESULT WindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CdlgSSDMP)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg BOOL OnDeviceChange(UINT nEventType, DWORD dwData);
	afx_msg void OnSelChangeTabMainSheet(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	CdlgMPPage                m_MPPage;
	CdlgSettingPage1          m_SettingPage1;
	CdlgSettingPage2          m_SettingPage2;
	CdlgRDTResultPage         m_RDTPage;
    
	HDEVNOTIFY                m_hDevNotify;
	HINSTANCE                 m_hKeyProDLL;
    
	CFileManager              m_FileManager;
    CUserDefineHubMapManager  m_UserDefineHubMapManager;
	CHubManager               m_HubManager;
    
    PORT_DATA                 m_PortData[SUPPORT_PORT_COUNT];
    
	char                      m_MPIniFullPath[MAX_PATH];         // SSDMP.ini
	char                      m_IniFullPath[MAX_PATH];           // FTA / FTB ini
    char                      m_MTableFullPath[MAX_PATH];        // MTable.set
    char                      m_CommonBurnerFullPath[MAX_PATH];  // CommonBurner.bin
	char                      m_SpecialPath[MAX_PATH];
	char                      m_KeyProDllFullPath[MAX_PATH];
	char                      m_MPFullPath[MAX_PATH];      // 3S_SSD_MP.exe
    char                      m_SNIniFullPath[MAX_PATH];
    HUB_INFO_TABLE            *m_pExt4PortHubInfo;
	HUB_INFO_TABLE            *m_pExt7PortHubInfo;
	char                      m_KeyProDrive;  // key pro drive letter
	int                       m_OP;           // over-provisioning (OP) percentage is decided by combo fw

	
	int     Init();
	void    InitUI();
	void    SwapTab();
	void    ShowAppVer();  // show application version to window caption

	int     RegDevNotification();  // register device notification for OnDeviceChange()

	int     InitPortDataByAllHubMode();
	int     InitPortDataByExt4PortMode();
	int     InitPortDataByExt7PortMode();
    
	int     GetMapPortIndex(IN char *HubName, IN int PortNumber, OUT int *pMapIndex);
	int     GetMapPortIndexEx(IN char *pHubName, IN int PortNumber, OUT int *pMapIndex);
	int     GetMapPortIndexByAllHubMode(IN char *HubName, IN int PortNumber, OUT int *pMapIndex);
	int     GetMapPortIndexByExt4PortMode(IN TCHAR *szHubName, IN int dwPortNumber, OUT int *pnMapIndex);
	int     GetMapPortIndexByExt7PortMode(IN TCHAR *szHubName, IN int dwPortNumber, OUT int *pnMapIndex);
    void    AddPortData(IN int PhyDrvNum, IN int MapIndex, IN char *pHubName, IN int PortNumber, IN int HubNumber);
    void    RemovePortData(IN int MapIndex);
	int     InsertDrive(IN int PhyDrvNum);
    int     RemoveDrive();
    int     GetRemoveMapPortIndex(IN int PhyDrvNum, OUT int *pMapIndex);
    int     GetRemovedPhyDrvNum(OUT int *pPhyDrvNum);
	int     GetPassFailCout(OUT int *pPass, OUT int *Fail);
	int     GetKeyProDrive(OUT char *pDrive, OUT int *pKeyCount);
	int     DetectKeyProDriveRemoved(IN DEV_BROADCAST_VOLUME *pDBV);
    int     GetCMDLineParam(OUT CMD_LINE_MP_PARAM *pParam);
	int     CheckCMDLineParam(IN CMD_LINE_MP_PARAM *pParam);
	int     GetOPByComboFW(IN char *pFullPath, OUT int *pOP);  // 0: 0%, 1: 7%
    int     QuerySizeTable(IN int OP, IN UINT32 MB, OUT UINT64 *pSector);
	void    RenamePortDataLog(IN int MapIndex);

    
    // release resource
    void    CloseHandleAllWorkingThread();


	// key pro dll export function
	FReadCounterFromBadBlock  fnReadCounterFromBadBlock;
	FWriteCounterToBadBlock   fnWriteCounterToBadBlock;
    FCheckCardIsValidEx       fnCheckCardIsValidEx;

    
    // response user message
    int     OnMsgStartRun();
    void    OnMsgUpdateProgress(IN int MapIndex, IN int Progress);
    void    OnMsgThreadTerminate(IN int MapIndex);
    void    OnMsgAllThreadTerminate();
    int     OnMsgScanDrive();
	void    OnMsgChangeSN();
    void    OnMsgUpdateDescription(IN int IniMode);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGSSDMP_H__1DAD9E33_1A97_4131_B523_C9D9F569A24A__INCLUDED_)
