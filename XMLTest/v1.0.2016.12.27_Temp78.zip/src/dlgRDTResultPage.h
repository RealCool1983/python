#if !defined(AFX_DLGRDTRESULTPAGE_H__6EC8661E_26CF_4689_A22C_3848F95167E7__INCLUDED_)
#define AFX_DLGRDTRESULTPAGE_H__6EC8661E_26CF_4689_A22C_3848F95167E7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// dlgRDTResultPage.h : header file
//


//-------------------------------------------------------------------------------------------------
#include <algorithm>  // for std::sort

#include "ColorEdit.h"
#include "MPDefine.h"
#include "RDTResultManager.h"
#include "DefectManager.h"

//-------------------------------------------------------------------------------------------------
// User define for the flaw of compiler 
#define for if(0); else for


#define LEFT_BRACKET   '['
#define RIGHT_BRACKET  ']'

enum ENUM_RADIO_DEFECT {TOTAL_DEFECT_INDEX, FD_INDEX, GD_INDEX};


#pragma pack(1)

typedef struct _LIST_CTRL_FORMAT
{
	char    Title[64];
	UINT32  Alignment;
	UINT32  Width;
	UINT16  ColumnIndex;
} LIST_CTRL_FORMAT, *PLIST_CTRL_FORMAT;

typedef struct _STATUS_DESCRIPTION
{
	char      Text[64];
	COLORREF  Color;
} STATUS_DESCRIPTION, *PSTATUS_DESCRIPTION;


#pragma pack()

//-------------------------------------------------------------------------------------------------

/////////////////////////////////////////////////////////////////////////////
// CdlgRDTResultPage dialog

class CdlgRDTResultPage : public CDialog
{
// Construction
public:
	CdlgRDTResultPage(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CdlgRDTResultPage)
	enum { IDD = IDD_RDT_RSLT_PAGE_DIALOG };
	CColorEdit	m_EditStatus;
	CListCtrl	m_ListCtrlDefect;
	CListCtrl	m_ListCtrlRslt;
	int		m_RadioDefect;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CdlgRDTResultPage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CdlgRDTResultPage)
	virtual BOOL OnInitDialog();
	afx_msg void OnBtnReadRslt();
	virtual void OnOK();
	afx_msg void OnRadioTotalDefect();
	afx_msg void OnRadioFD();
	afx_msg void OnRadioGD();
	afx_msg void OnSelChangeComboPort();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

public:
	int   Init(IN PORT_DATA *pPortData);
	void   ShowProductionInfo();

private:
	PORT_DATA           *m_pPortData;
	CRDTResultManager   m_RDTManager;
    CDefectManager      m_DefectManager;
	ENUM_FIRMWARE_MODE  m_FwMode;
	bool                m_IsInitSucceed;

	void  InitUI();
	void  InitListCtrl(IN CListCtrl *pListCtrl, IN LIST_CTRL_FORMAT *pListFormat, IN int ColumnCount);

	void  ShowRDTRslt();
	void  ShowMPVer();
    void  ShowDefectInfo(IN CListCtrl *pListCtrl, IN DEFECT_INFO *pDefect, IN DEFECT_INFO *pGD);
	void  AllRDTRsltToListCtrl(IN CListCtrl *pListCtrl, IN RDT_BLOCK_INFO *pBlockInfo);
	void  FullDieRsltToListCtrl(IN CListCtrl *pListCtrl, IN std::vector<RDT_BLOCK_RESULT> *pBlock, IN char *pSignature);
	void  SamplingRsltToListCtrl(IN CListCtrl *pListCtrl, IN std::vector<RDT_BLOCK_RESULT> *pBlock, IN char *pSignature);
	int   UserRDTSettingInfoFormat(IN std::string *pSettingContent, OUT CString *pUserContent);
    void  ShowDefectCount(IN CListCtrl *pListCtrl, IN DEFECT_INFO *pDefect);
	bool  IsGD(IN int ch, IN int ce, IN int lun, IN int plane, IN UINT16 LunBlock, IN DEFECT_INFO *pGD);
	void  ClearUI();


	int Read_INI_File_Ex(IN  char *pSection,
		                 IN  char *pKey,
						 OUT char *pKey_Value,
						 IN  int  Key_Value_Buffer_Size,
						 IN  char *pDefault_Value,
						 IN  const char *pContent_Buffer);

	int Parse_INI_File(IN  char       *pSection,
		               IN  char       *pKey,
					   IN  const char *pFile_Buffer,
					   OUT UINT32     *pSection_Start_Offset,
					   OUT UINT32     *pSection_End_Offset,
					   OUT UINT32     *pKey_Start_Offset,
					   OUT UINT32     *pKey_End_Offset,
					   OUT UINT32     *pKey_Value_Start_Offset,
					   OUT UINT32     *pKey_Value_End_Offset);
	bool CdlgRDTResultPage::Is_End_Char(IN char c);
	bool Is_Left_Bracket(IN char c);
	bool Is_Right_Bracket(IN char c);
	bool Is_New_Line_Char(IN char c);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGRDTRESULTPAGE_H__6EC8661E_26CF_4689_A22C_3848F95167E7__INCLUDED_)
