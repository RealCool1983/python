// NandInfo.cpp : implementation file
//

#include "stdafx.h"
#include "SSDMP.h"
#include "dlgNandInfo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CdlgNandInfo dialog


CdlgNandInfo::CdlgNandInfo(CWnd* pParent /*=NULL*/)
	: CDialog(CdlgNandInfo::IDD, pParent)
{
	//{{AFX_DATA_INIT(CdlgNandInfo)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

//-------------------------------------------------------------------------------------------------
void CdlgNandInfo::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CdlgNandInfo)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

//-------------------------------------------------------------------------------------------------
BEGIN_MESSAGE_MAP(CdlgNandInfo, CDialog)
	//{{AFX_MSG_MAP(CdlgNandInfo)
	ON_CBN_SELCHANGE(IDC_COMBO_CE, OnSelChangeComboCe)
	ON_BN_CLICKED(IDC_BTN_SHOWALLCE, OnBtnShowAllCe)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


void CdlgNandInfo::OnBtnShowAllCe() 
{
	// TODO: Add your control notification handler code here

	CdlgShowCEPage dlg(NULL,&this->m_IdInfo);
	dlg.DoModal();

    return;
}


/////////////////////////////////////////////////////////////////////////////
// CdlgNandInfo message handlers


//-------------------------------------------------------------------------------------------------
int CdlgNandInfo::Init(IN CH_ID_INFO *pIdInfo)
{
	::memset(&this->m_IdInfo, 0, sizeof(CH_ID_INFO));
	::memcpy(&this->m_IdInfo, pIdInfo, sizeof(CH_ID_INFO));

	return 0;
}

//-------------------------------------------------------------------------------------------------
void CdlgNandInfo::InitUI()
{
	CComboBox *pComboBox;


	pComboBox = (CComboBox*)GetDlgItem(IDC_COMBO_CE);
	pComboBox->AddString("CE0");
	pComboBox->AddString("CE1");
	pComboBox->AddString("CE2");
	pComboBox->AddString("CE3");

	pComboBox->SetCurSel(0);
	this->OnSelChangeComboCe();

	return;
}

//-------------------------------------------------------------------------------------------------
BOOL CdlgNandInfo::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	
	this->InitUI();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

//-------------------------------------------------------------------------------------------------
void CdlgNandInfo::OnSelChangeComboCe() 
{
	// TODO: Add your control notification handler code here

	CComboBox  *pComboBox;
	CString    Str;
	int        CurSel;


	pComboBox = (CComboBox*)GetDlgItem(IDC_COMBO_CE);
	CurSel = pComboBox->GetCurSel();

	if (CurSel == CB_ERR) {
		return;
	}

	// ch0
	Str.Format("%X  %X  %X  %X  %X  %X", this->m_IdInfo.CH[0].CE[CurSel].FlashID[0],
		                                 this->m_IdInfo.CH[0].CE[CurSel].FlashID[1],
									     this->m_IdInfo.CH[0].CE[CurSel].FlashID[2],
									     this->m_IdInfo.CH[0].CE[CurSel].FlashID[3],
									     this->m_IdInfo.CH[0].CE[CurSel].FlashID[4],
									     this->m_IdInfo.CH[0].CE[CurSel].FlashID[5]);

	GetDlgItem(IDC_EDIT_CH0)->SetWindowText(Str);
	
	// ch1
	Str.Format("%X  %X  %X  %X  %X  %X", this->m_IdInfo.CH[1].CE[CurSel].FlashID[0],
		                                 this->m_IdInfo.CH[1].CE[CurSel].FlashID[1],
									     this->m_IdInfo.CH[1].CE[CurSel].FlashID[2],
									     this->m_IdInfo.CH[1].CE[CurSel].FlashID[3],
									     this->m_IdInfo.CH[1].CE[CurSel].FlashID[4],
									     this->m_IdInfo.CH[1].CE[CurSel].FlashID[5]);

	GetDlgItem(IDC_EDIT_CH1)->SetWindowText(Str);

}

//-------------------------------------------------------------------------------------------------
