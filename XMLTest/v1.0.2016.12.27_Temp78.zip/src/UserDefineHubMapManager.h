// UserDefineHubMapManager.h: interface for the CUserDefineHubMapManager class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_USERDEFINEHUBMAPMANAGER_H__3964522B_2D0C_4624_9198_5737A6D630BC__INCLUDED_)
#define AFX_USERDEFINEHUBMAPMANAGER_H__3964522B_2D0C_4624_9198_5737A6D630BC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//--------------------------------------------------------------------------------------------------
#include "FileManager.h"
#include "MPDefine.h"

//--------------------------------------------------------------------------------------------------
#define USER_DEFINE_HUB_COUNT  (4)

typedef struct _USER_DEFINE_HUB_MAP
{
	char  HubName[256];
    int   HubNumber;  // number of index
    int   PortCount;  // the port count of a hub
} USER_DEFINE_HUB_MAP, *PUSER_DEFINE_HUB_MAP;

//--------------------------------------------------------------------------------------------------
class CUserDefineHubMapManager  
{
public:
	CUserDefineHubMapManager();
	virtual ~CUserDefineHubMapManager();


    USER_DEFINE_HUB_MAP  m_HubMap[USER_DEFINE_HUB_COUNT];
	int                  m_PortAlignmentMode;


	int Init(IN char *pFullPathName);

private:
	CFileManager  m_FileManager;
    
    BOOL  IsStringDecNumeric(IN char *pStr, IN DWORD dwStrLength);
};

#endif // !defined(AFX_USERDEFINEHUBMAPMANAGER_H__3964522B_2D0C_4624_9198_5737A6D630BC__INCLUDED_)
