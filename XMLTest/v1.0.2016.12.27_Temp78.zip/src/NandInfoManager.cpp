#include "stdafx.h"
#include "NandInfoManager.h"


//-------------------------------------------------------------------------------------------------
BYTE g_AES_KEY[] = { 0x2c, 0x7f, 0x16, 0x17, 0x29, 0xaf, 0xd3, 0xa7, 0xac, 0xf8, 0x16, 0x89, 0x10, 0xd0, 0x50, 0x3d };

//-------------------------------------------------------------------------------------------------
CNandInfoManager::CNandInfoManager()
{
    this->InitMember();
}

//-------------------------------------------------------------------------------------------------
CNandInfoManager::~CNandInfoManager()
{
}

//-------------------------------------------------------------------------------------------------
int CNandInfoManager::Init(int PhyDrvNum, IN HANDLE hDevice, IN char *pBurnerFullPath)
{
    LOG_EXT_CONFIG_B0  ReadLogB0;
    LOG_EXT_CONFIG_A0  ReadLogA0;
    int  Mode;
    int  Rslt;

    
	this->InitMember();

    Rslt = SSD_Utility_Get_FW_Mode(PhyDrvNum, NULL, 0, &Mode);
    if ((Rslt != 0) || (Mode == UNKNOW_MODE)) {
        return 1;
    }
	
    if (Mode == ROM_SAFE_MODE) {
		if (pBurnerFullPath == NULL) {
			return 1;
		}

        Rslt = this->DownloadBurner(PhyDrvNum, hDevice, pBurnerFullPath);
        if (Rslt != 0) {
            return 1;
        }

        // sleep a while for download burner ready
        ::Sleep(200);
        
        ::memset(&ReadLogA0, 0, sizeof(LOG_EXT_CONFIG_A0));
        Rslt = SSD_Utility_Get_Burner_Status(PhyDrvNum, hDevice, &ReadLogA0);
        if (Rslt != 0) {
            return 1;
        }

        // actually common burner will not report nand info.
        ::memcpy(&this->m_NandInfo, &ReadLogA0.cfg_tbl_nand_info, sizeof(cfg_tbl_nand_info_t));
        
        for (int i = 0; i < 8; i++) {
            ::memcpy(&this->m_FlashID[i], &ReadLogA0.Flash_ID[i], 8);
        }
    }
    else if (Mode == BURNER_MODE) {
        ::memset(&ReadLogA0, 0, sizeof(LOG_EXT_CONFIG_A0));
        Rslt = SSD_Utility_Get_Burner_Status(PhyDrvNum, hDevice, &ReadLogA0);
        if (Rslt != 0) {
            return 1;
        }

        ::memcpy(&this->m_NandInfo, &ReadLogA0.cfg_tbl_nand_info, sizeof(cfg_tbl_nand_info_t));
        for (int i = 0; i < 8; i++) {
            ::memcpy(&this->m_FlashID[i], &ReadLogA0.Flash_ID[i], 8);
        }
    }
    else {  // read config to get nand info
        ::memset(&ReadLogB0, 0, sizeof(LOG_EXT_CONFIG_B0));
        Rslt = SSD_Utility_Get_Log_Ext_Config_B0(PhyDrvNum, hDevice, 0, &ReadLogB0);
        if (Rslt != 0) {
            return 1;
        }
        
        ::memcpy(&this->m_NandInfo, &ReadLogB0.MP_Use_Data_Config.A0_Info.cfg_tbl_nand_info, sizeof(cfg_tbl_nand_info_t));
        for (int i = 0; i < 8; i++) {
            ::memcpy(&this->m_FlashID[i], &ReadLogB0.MP_Use_Data_Config.A0_Info.Flash_ID[i], 8);
        }
    }
    
	this->m_InitSucceed = true;

    return 0;
}

//-------------------------------------------------------------------------------------------------
cfg_tbl_nand_info_t *CNandInfoManager::GetNandInfo()
{
    return (this->m_InitSucceed == false) ? NULL : &this->m_NandInfo;
}

//-------------------------------------------------------------------------------------------------
int CNandInfoManager::GetFlashID(IN int CH, IN int CE, OUT BYTE *pID)
{
    int Index;
    
	
	if (this->m_InitSucceed == false) {
		return 1;
	}

	/*
    if ((CH > this->m_NandInfo.support_channel) || (CE > this->m_NandInfo.support_ce)) {
        return 1;
    }
	*/
    
    if ((CH % 2) == 0) {  // ch#0
        Index = CE * 2;
    }
    else {  // ch#1
        Index = CE * 2 + 1;
    }
    
    ::memcpy(pID, this->m_FlashID[Index], FLASH_ID_LENGTH);
    
    return 0; 
}

//-------------------------------------------------------------------------------------------------
bool CNandInfoManager::IsInitSucceed()
{
	return this->m_InitSucceed;
}

//-------------------------------------------------------------------------------------------------
void CNandInfoManager::InitMember()
{
	this->m_InitSucceed = false;
    
    ::memset(&this->m_NandInfo, 0, sizeof(cfg_tbl_nand_info_t));
    
    for (int i = 0; i < 8; i++) {
        ::memset(&m_FlashID[i], 0, 8);
    }

	return;
}

//-------------------------------------------------------------------------------------------------
int CNandInfoManager::DownloadBurner(IN int PhyDrvNum, IN HANDLE hDevice, IN char *pBurnerFullPath)
{
    FILE     *pFile;
    __int64  FileSize;
    UINT32   ReadSize;
    BYTE     *pBuffer;
    int      Rslt;



    //===================================================
    //                 read file
    //===================================================
    Rslt = this->m_FileManager.GetFileSize(pBurnerFullPath, &FileSize);
    if (Rslt != 0) {
        return 1;
    }

    pFile = ::fopen(pBurnerFullPath, "rb");
    if (pFile == NULL) {
        return 1;
    }
    
    pBuffer = (BYTE*)::malloc((UINT32)FileSize * sizeof(BYTE));
    if (pBuffer == NULL) {
        ::fclose(pFile);
        pFile = NULL;
        return 1;
    }
    
    ::memset(pBuffer, 0, (UINT32)FileSize * sizeof(BYTE));
    ReadSize = ::fread(pBuffer, sizeof(BYTE), (UINT32)FileSize, pFile);
    if (ReadSize != FileSize) {
        ::fclose(pFile);
        pFile = NULL;
        ::free(pBuffer);
        pBuffer = NULL;
        return 1;
    }
    
    
    //===================================================
    //                decrypt by AES
    //===================================================
    int  HeaderSize;
    int  DownloadSize;
    AES  aes(g_AES_KEY);
    
    aes.InvCipher(pBuffer, (int)FileSize);
    CIPHER_HEADER *pHeader = (CIPHER_HEADER*)pBuffer;

    if (::memcmp(pHeader->Signature, CIPHER_SIGNATURE, ::strlen(CIPHER_SIGNATURE)) == 0) {  // has been decrypted
        HeaderSize   = sizeof(CIPHER_HEADER);
        DownloadSize = pHeader->Size;
    }
    else {  // didn't be decrypted
        ::rewind(pFile);
        
        ::memset(pBuffer, 0, (UINT32)FileSize);
        ReadSize = ::fread(pBuffer, sizeof(BYTE), (UINT32)FileSize, pFile);
        if (ReadSize != FileSize) {
            ::fclose(pFile);
            pFile = NULL;
            ::free(pBuffer);
            pBuffer = NULL;
            return 1;
        }
        HeaderSize = 0;
        DownloadSize = (UINT32)FileSize;
    }
    
    // release resource
    ::fclose(pFile);
    pFile = NULL;


    //===================================================
    //               download microcode
    //===================================================
    Rslt = SSD_CMD_Download_Microcode(PhyDrvNum, hDevice, (pBuffer + HeaderSize), DownloadSize);
    if (Rslt != 0) {
        ::free(pBuffer);
        pBuffer = NULL;
        return 1;
    }

    // release resource
    ::free(pBuffer);
    pBuffer = NULL;

    return 0;
}

//-------------------------------------------------------------------------------------------------

