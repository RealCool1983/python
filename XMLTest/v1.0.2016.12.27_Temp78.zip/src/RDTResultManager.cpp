// RDTResultManager.cpp: implementation of the CRDTResultManager class.
//
///////////////////////////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SSDMP.h"
#include "RDTResultManager.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

///////////////////////////////////////////////////////////////////////////////////////////////////
// Construction/Destruction
///////////////////////////////////////////////////////////////////////////////////////////////////

CRDTResultManager::CRDTResultManager()
{
	this->InitMember();
}

//-------------------------------------------------------------------------------------------------
CRDTResultManager::~CRDTResultManager()
{

}

//-------------------------------------------------------------------------------------------------
int CRDTResultManager::Init(IN int PhyDrvNum, IN HANDLE hDevice, IN ENUM_READ_LOG_EXT_MODE ReadMode, IN PRELOAD_MODE PreloadMode)
{
    BYTE        Buffer[32 * 512];  // 16 KBytes (32 sector) buffer for read log ext 0xB1
    RDT_RESULT  *pRDT_Result;
    char        Signature[8];
    int         Rslt;

    
	this->InitMember();

    
    //=======================================================================
    //                      read RDT setting
    //=======================================================================
    this->ReadRDTSetting(PhyDrvNum, hDevice, ReadMode, &this->m_RDTSetting);
    
    
    //=======================================================================
    //   read log ext 0xB1 to get how many 16K are recorded by RDT stage
    //=======================================================================
    ::memset(Buffer, 0, sizeof(Buffer));

    Rslt = SSD_CMD_Read_Log_Ext_LBA(PhyDrvNum, hDevice, ReadMode, Buffer, 32, 0xB1);
    if (Rslt != 0) {
        return 1;
    }
    
    pRDT_Result = (RDT_RESULT*)Buffer;
    if (this->IsRsltSignatureCorrect(pRDT_Result) == false) {
        return 1;
    }
    ::Sleep(5);
    
    this->ParseCycleDoneInfo(pRDT_Result, &this->m_CycleDoneInfo, &this->m_IsRDTDone);
    this->ParseSpendTimeInfo(pRDT_Result, &this->m_SpendTimeInfo);
    
    
    //=======================================================================
    //         RDT result (block info result) starts from 0xB2
    //=======================================================================
    RDT_RESULT    Temp_RDT_Result;
    CYCLE_RESULT  Temp_Cycle_Result;
    
    
    this->m_RsltCnt = pRDT_Result->head.h.total_rdt_result_cnt;
    
    for (UINT32 i = 0; i < this->m_RsltCnt; i++) {
        ::memset(Buffer, 0, sizeof(Buffer));
        
        switch (ReadMode) {
            case  READ_LOG_EXT_NONE_SEGMENT:  Rslt = SSD_CMD_Read_Log_Ext_LBA(PhyDrvNum, hDevice, 0, Buffer, 32, ((i << 8) | 0xB2));              break;
            case  READ_LOG_EXT_SEGMENT:       Rslt = SSD_CMD_Segment_Read_Log_Ext_RDT_Result(PhyDrvNum, hDevice, Buffer, 32, ((i << 8) | 0xB2));  break;
			default:  Rslt = SSD_CMD_Read_Log_Ext_LBA(PhyDrvNum, hDevice, 0, Buffer, 32, ((i << 8) | 0xB2));
        }

        if (Rslt != 0) {
            return 1;
        }
        
        pRDT_Result = (RDT_RESULT*)Buffer;

        ::memset(Signature, 0, sizeof(Signature));
        Signature[0] = (pRDT_Result->head.h.signature & 0xFF);
        Signature[1] = ((pRDT_Result->head.h.signature >> 8) & 0xFF);
		
		if (::strcmp(Signature, RDT_RESULT_FULL_DIE_TLC_SIGNATURE) == 0) {  // TLC full die
			::memset(&Temp_RDT_Result, 0, sizeof(RDT_RESULT));
            ::memcpy(&Temp_RDT_Result, (RDT_RESULT*)Buffer, sizeof(RDT_RESULT));
            this->m_RsltInfo.TLCFullDieRslt.push_back(Temp_RDT_Result);
		}
		else if (::strcmp(Signature, RDT_RESULT_FULL_DIE_SLC_SIGNATURE) == 0) {  // SLC full die
			::memset(&Temp_RDT_Result, 0, sizeof(RDT_RESULT));
            ::memcpy(&Temp_RDT_Result, (RDT_RESULT*)Buffer, sizeof(RDT_RESULT));
			this->m_RsltInfo.SLCFullDieRslt.push_back(Temp_RDT_Result);
		}
		else if (::strcmp(Signature, RDT_RESULT_SAMPLING_TLC_SIGNATURE) == 0) {  // TLC sampling
			::memset(&Temp_RDT_Result, 0, sizeof(RDT_RESULT));
            ::memcpy(&Temp_RDT_Result, (RDT_RESULT*)Buffer, sizeof(RDT_RESULT));
			this->m_RsltInfo.TLCSamplingRslt.push_back(Temp_RDT_Result);
		}
		else if (::strcmp(Signature, RDT_RESULT_SAMPLING_SLC_SIGNATURE) == 0) {  // SLC sampling
			::memset(&Temp_RDT_Result, 0, sizeof(RDT_RESULT));
            ::memcpy(&Temp_RDT_Result, (RDT_RESULT*)Buffer, sizeof(RDT_RESULT));
			this->m_RsltInfo.SLCSamplingRslt.push_back(Temp_RDT_Result);
		}
        else if (::strcmp(Signature, RDT_RESULT_CYCLE_INFO_SIGNATURE) == 0) {  // cycle time info.
            ::memset(&Temp_Cycle_Result, 0, sizeof(CYCLE_RESULT));
            ::memcpy(&Temp_Cycle_Result, (CYCLE_RESULT*)Buffer, sizeof(CYCLE_RESULT));
            this->m_RsltInfo.CycleRslt.push_back(Temp_Cycle_Result);
        }
        else if (::strcmp(Signature, RDT_RESULT_POWER_CYCLE_SIGNATURE) == 0) {  // power cycle info
            ::memset(&Temp_RDT_Result, 0, sizeof(RDT_RESULT));
            ::memcpy(&Temp_RDT_Result, (RDT_RESULT*)Buffer, sizeof(RDT_RESULT));
            this->m_RsltInfo.PowerRslt.push_back(Temp_RDT_Result);
        }
        else {  // signature error
            return 1;
        }
        
        ::Sleep(5);
    }

    this->ParseFullDieBlockInfo(&this->m_RsltInfo.TLCFullDieRslt, &this->m_BlockInfo.TLCFullDie);
    this->ParseFullDieBlockInfo(&this->m_RsltInfo.SLCFullDieRslt, &this->m_BlockInfo.SLCFullDie);
    this->ParseSamplingBlockInfo(&this->m_RsltInfo.TLCSamplingRslt, PreloadMode, &this->m_BlockInfo.TLCSampling);
    this->ParseSamplingBlockInfo(&this->m_RsltInfo.SLCSamplingRslt, PreloadMode, &this->m_BlockInfo.SLCSampling);
	
	this->ParseFailInfo(&this->m_BlockInfo.TLCFullDie, true, &this->m_TestFailInfo.TLCFullDie);
	this->ParseFailInfo(&this->m_BlockInfo.SLCFullDie, true, &this->m_TestFailInfo.SLCFullDie);
	this->ParseFailInfo(&this->m_BlockInfo.TLCSampling, false, &this->m_TestFailInfo.TLCSampling);
	this->ParseFailInfo(&this->m_BlockInfo.SLCSampling, false, &this->m_TestFailInfo.SLCSampling);

	this->ParseMaxTempInfo(&this->m_BlockInfo.TLCFullDie, &this->m_MaxTempInfo.TLCFullDieMaxTemp);
	this->ParseMaxTempInfo(&this->m_BlockInfo.SLCFullDie, &this->m_MaxTempInfo.SLCFullDieMaxTemp);
	this->ParseMaxTempInfo(&this->m_BlockInfo.TLCSampling, &this->m_MaxTempInfo.TLCSamplingMaxTemp);
	this->ParseMaxTempInfo(&this->m_BlockInfo.SLCSampling, &this->m_MaxTempInfo.SLCSamplingMaxTemp);
    

	this->m_InitSucceed = true;
    
	return 0;
}

//-------------------------------------------------------------------------------------------------
void CRDTResultManager::InitMember()
{
    this->m_InitSucceed = false;
    this->m_IsRDTDone   = false;
	this->m_RsltCnt     = 0;
    this->m_RDTSetting  = "";
    
    this->m_RsltInfo.TLCFullDieRslt.clear();
	this->m_RsltInfo.SLCFullDieRslt.clear();
	this->m_RsltInfo.TLCSamplingRslt.clear();
	this->m_RsltInfo.SLCSamplingRslt.clear();
	this->m_RsltInfo.CycleRslt.clear();
	this->m_RsltInfo.PowerRslt.clear();
    
    this->m_BlockInfo.TLCFullDie.clear();
    this->m_BlockInfo.SLCFullDie.clear();
    this->m_BlockInfo.TLCSampling.clear();
    this->m_BlockInfo.SLCSampling.clear();
    
	::memset(&this->m_SpendTimeInfo, 0, sizeof(RDT_SPEND_TIME_INFO));
    ::memset(&this->m_CycleDoneInfo, 0, sizeof(CYCLE_DONE_INFO));
	::memset(&this->m_TestFailInfo, 0, sizeof(TEST_FAIL_INFO));
	::memset(&this->m_MaxTempInfo, 0, sizeof(MAX_TEMPERATURE_INFO));
    
    return;
}

//-------------------------------------------------------------------------------------------------
int CRDTResultManager::ParseCycleDoneInfo(IN RDT_RESULT *pRslt, OUT CYCLE_DONE_INFO *pInfo, OUT bool *pIsDone)
{
    bool  Is_RDT_Done;

    
    if (this->IsRsltSignatureCorrect(pRslt) == false) {
		*pIsDone = false;
        return 1;
    }
    
	Is_RDT_Done = true;
    
    // SLC full die
    if (pRslt->head.h.slc_full_die_timestamp < pRslt->head.h.slc_full_die_cycle) {
        Is_RDT_Done = false;
    }
    
    pInfo->SLC_Full_Die_Cycle_Done    = pRslt->head.h.slc_full_die_timestamp;
    pInfo->SLC_Full_Die_Target_Cycle  = pRslt->head.h.slc_full_die_cycle;
    pInfo->Is_SLC_Full_Die_Cycle_Done = Is_RDT_Done;
    
    
    // TLC full die
    if (pRslt->head.h.tlc_full_die_timestamp < pRslt->head.h.tlc_full_die_cycle) {
        Is_RDT_Done = false;
    }
    
    pInfo->TLC_Full_Die_Cycle_Done    = pRslt->head.h.tlc_full_die_timestamp;
    pInfo->TLC_Full_Die_Target_Cycle  = pRslt->head.h.tlc_full_die_cycle;
    pInfo->Is_TLC_Full_Die_Cycle_Done = Is_RDT_Done;
    
    
    // SLC sampling
    if (pRslt->head.h.slc_sampling_timestamp < pRslt->head.h.slc_sampling_cycle) {
        Is_RDT_Done = false;
    }
    
    pInfo->SLC_Sampling_Cycle_Done    = pRslt->head.h.slc_sampling_timestamp;
    pInfo->SLC_Sampling_Target_Cycle  = pRslt->head.h.slc_sampling_cycle;
    pInfo->Is_SLC_Sampling_Cycle_Done = Is_RDT_Done;
    
    
    // TLC sampling
    if (pRslt->head.h.tlc_sampling_timestamp < pRslt->head.h.tlc_sampling_cycle) {
        Is_RDT_Done = false;
    }
    
    pInfo->TLC_Sampling_Cycle_Done    = pRslt->head.h.tlc_sampling_timestamp;
    pInfo->TLC_Sampling_Target_Cycle  = pRslt->head.h.tlc_sampling_cycle;
    pInfo->Is_TLC_Sampling_Cycle_Done = Is_RDT_Done;
    
    *pIsDone = Is_RDT_Done;
    
    return 0;
}

//-------------------------------------------------------------------------------------------------
int CRDTResultManager::ParseSpendTimeInfo(IN RDT_RESULT *pRslt, OUT RDT_SPEND_TIME_INFO *pInfo)
{
    UINT32  Spend_Time;
    
    
    if (this->IsRsltSignatureCorrect(pRslt) == false) {
        return 1;
    }
    
    
    // total spend time
    if (pRslt->head.h.end_time < pRslt->head.h.start_time) {
        Spend_Time = 0;
    }
    else {
        Spend_Time = ((pRslt->head.h.end_time / 10) * 10) - ((pRslt->head.h.start_time / 10) * 10);  // ignore 1st decimal place
    }
    pInfo->Total_Spend_Time = Spend_Time;
    
    
    // SLC full die spend time
    if (pRslt->head.h.SLC_full_end_time < pRslt->head.h.SLC_full_start_time) {
        Spend_Time = 0;
    }
    else {
        Spend_Time = ((pRslt->head.h.SLC_full_end_time / 10) * 10) - ((pRslt->head.h.SLC_full_start_time / 10) * 10);
    }
    pInfo->SLC_Full_Die_Spend_Time = Spend_Time;
    
    
    // TLC full die spend time
    if (pRslt->head.h.TLC_full_end_time < pRslt->head.h.TLC_full_start_time) {
        Spend_Time = 0;
    }
    else {
        Spend_Time = ((pRslt->head.h.TLC_full_end_time / 10) * 10) - ((pRslt->head.h.TLC_full_start_time / 10) * 10);
    }
    pInfo->TLC_Full_Die_Spend_Time = Spend_Time;
    
    
    // SLC sampling spend time
    if (pRslt->head.h.SLC_sampling_end_time < pRslt->head.h.SLC_sampling_start_time) {
        Spend_Time = 0;
    }
    else {
        Spend_Time = ((pRslt->head.h.SLC_sampling_end_time / 10) * 10) - ((pRslt->head.h.SLC_sampling_start_time / 10) * 10);  // for ignore millisecond
    }
    pInfo->SLC_Sampling_Spend_Time = Spend_Time;
    
    
    // TLC sampling spend time
    if (pRslt->head.h.TLC_sampling_end_time < pRslt->head.h.TLC_sampling_start_time) {
        Spend_Time = 0;
    }
    else {
        Spend_Time = ((pRslt->head.h.TLC_sampling_end_time / 10) * 10) - ((pRslt->head.h.TLC_sampling_start_time / 10) * 10);  // for ignore millisecond
    }
    pInfo->TLC_Sampling_Spend_Time = Spend_Time;
    
    
    return 0;
}

//-------------------------------------------------------------------------------------------------
void CRDTResultManager::ParseFailInfo(IN std::vector<RDT_BLOCK_RESULT> *pRslt, IN bool IsIgnoreFD, OUT FAIL_TYPE_COUNT_INFO *pFailInfo)
{
	BYTE  Empty[16] = {0};
	BYTE  Fail_Type;

	
	::memset(pFailInfo, 0, sizeof(FAIL_TYPE_COUNT_INFO));

	for (int i = 0; i < pRslt->size(); i++) {
        Fail_Type = (*pRslt)[i].rec.Failed_Type;
        
        if (Fail_Type == RDT_RESULT_PASS) {
            continue;
        }
        
        if ((IsIgnoreFD == true) && (Fail_Type == RDT_RESULT_ORG_DEFECT)) {
            continue;
        }

        // avoid fw return unexpected value
        if (Fail_Type > RDT_RESULT_OTHER_FAIL) {
            Fail_Type = RDT_RESULT_OTHER_FAIL;
        }
        
        switch (Fail_Type) {
            case RDT_RESULT_UNC_FAIL:     pFailInfo->uECCFailCount++;           break;
            case RDT_RESULT_PRG_FAIL:     pFailInfo->ProgramFailCount++;        break;
            case RDT_RESULT_ER_FAIL:      pFailInfo->EraseFailCount++;          break;
            case RDT_RESULT_OV_THR_FAIL:  pFailInfo->OverThresholdFailCount++;  break;
            case RDT_RESULT_ORG_DEFECT:   pFailInfo->FactoryDefectCount++;      break;
            case RDT_RESULT_OTHER_FAIL:   pFailInfo->OtherFailCount++;          break;
        }

        pFailInfo->TotalFailCount++;
	}

	return;
}

//-------------------------------------------------------------------------------------------------
void CRDTResultManager::ParseMaxTempInfo(IN std::vector<RDT_BLOCK_RESULT> *pBlockInfo, OUT int *pMaxTemp)
{
	BYTE  Empty[16] = {0};
	int   Max = 0;


	for (int i = 0; i < pBlockInfo->size(); i++) {
        if ((*pBlockInfo)[i].rec.Temp > Max) {
            Max = (*pBlockInfo)[i].rec.Temp;
        }
	}

	*pMaxTemp = Max;

	return;
}

//-------------------------------------------------------------------------------------------------
void CRDTResultManager::ParseFullDieBlockInfo(IN std::vector<RDT_RESULT> *pRslt, OUT std::vector<RDT_BLOCK_RESULT> *pBlockInfo)
{
    BYTE  Empty[16] = {0};
    bool  IsRepeated;
    
    
    // parse RDT result to get block info
    for (int i = 0; i < pRslt->size(); i++) {
		for (int Count = 0; Count < MAX_RESULT_COUNT; Count++) {
            
            // check there is block info
			if (::memcmp((*pRslt)[i].Blk_Result[Count].rev, Empty, 16) == 0) {
				break;
			}
			
            //
            // check block info is repeated
            // if block is tested fail (full die test). this block will not be tested in the next cycle
            // so we check repeated in every cycle condition
            //
            IsRepeated = false;
            
            for (int j = 0; j < pBlockInfo->size(); j++) {
                if (((*pRslt)[i].Blk_Result[Count].rec.CH    == (*pBlockInfo)[j].rec.CH)    && 
                    ((*pRslt)[i].Blk_Result[Count].rec.CE    == (*pBlockInfo)[j].rec.CE)    &&
                    ((*pRslt)[i].Blk_Result[Count].rec.Die   == (*pBlockInfo)[j].rec.Die)   &&
                    ((*pRslt)[i].Blk_Result[Count].rec.Plane == (*pBlockInfo)[j].rec.Plane) &&
                    ((*pRslt)[i].Blk_Result[Count].rec.Block == (*pBlockInfo)[j].rec.Block)) {
                        IsRepeated = true;
                        break;
                    }
            }
            
            if (IsRepeated == true) {
                continue;
            }
            
            pBlockInfo->push_back((*pRslt)[i].Blk_Result[Count]);
		}
	}
    
    return;
}

//-------------------------------------------------------------------------------------------------
void CRDTResultManager::ParseSamplingBlockInfo(IN  std::vector<RDT_RESULT>       *pRslt,
                                               IN  PRELOAD_MODE                  PreloadMode,
                                               OUT std::vector<RDT_BLOCK_RESULT> *pBlockInfo)
{
	BYTE  Empty[16] = {0};
    bool  IsRepeated;
    
    
    // parse RDT result to get block info
    for (int i = 0; i < pRslt->size(); i++) {
		for (int Count = 0; Count < MAX_RESULT_COUNT; Count++) {
            
            // check there is block info
			if (::memcmp((*pRslt)[i].Blk_Result[Count].rev, Empty, 16) == 0) {
				break;
			}
            
            if ((*pRslt)[i].head.h.stage != PreloadMode) {
				continue;
			}
			
            //
            // check block info is repeated
            // if block is tested fail (sampling test). this block will still be tested until target cycle
            // so we check repeated in the same cycle condition
            //
            IsRepeated = false;
            
            for (int j = 0; j < pBlockInfo->size(); j++) {
                if (((*pRslt)[i].Blk_Result[Count].rec.CH    == (*pBlockInfo)[j].rec.CH)    && 
                    ((*pRslt)[i].Blk_Result[Count].rec.CE    == (*pBlockInfo)[j].rec.CE)    &&
                    ((*pRslt)[i].Blk_Result[Count].rec.Die   == (*pBlockInfo)[j].rec.Die)   &&
                    ((*pRslt)[i].Blk_Result[Count].rec.Plane == (*pBlockInfo)[j].rec.Plane) &&
                    ((*pRslt)[i].Blk_Result[Count].rec.Block == (*pBlockInfo)[j].rec.Block) &&
                    ((*pRslt)[i].Blk_Result[Count].rec.Cycle == (*pBlockInfo)[j].rec.Cycle)) {
                        IsRepeated = true;
                        break;
                    }
            }
            
            if (IsRepeated == true) {
                continue;
            }
            
            pBlockInfo->push_back((*pRslt)[i].Blk_Result[Count]);
		}
	}

    return;
}

//-------------------------------------------------------------------------------------------------
bool CRDTResultManager::IsRsltSignatureCorrect(IN RDT_RESULT *pRslt)
{
    char  Signature[8];
    
    
    // check signature
    ::memset(Signature, 0, sizeof(Signature));
    Signature[0] = (pRslt->head.h.signature & 0xFF);
    Signature[1] = ((pRslt->head.h.signature >> 8) & 0xFF);

    if ((::strcmp(Signature, RDT_RESULT_FULL_DIE_SLC_SIGNATURE) != 0) &&
		(::strcmp(Signature, RDT_RESULT_FULL_DIE_TLC_SIGNATURE) != 0) &&
        (::strcmp(Signature, RDT_RESULT_SAMPLING_SLC_SIGNATURE) != 0) &&
		(::strcmp(Signature, RDT_RESULT_SAMPLING_TLC_SIGNATURE) != 0) &&
        (::strcmp(Signature, RDT_RESULT_CYCLE_INFO_SIGNATURE) != 0) &&
		(::strcmp(Signature, RDT_RESULT_POWER_CYCLE_SIGNATURE))) {
        
        return false;
    }
    
    return true;
}

//-------------------------------------------------------------------------------------------------
int CRDTResultManager::ReadRDTSetting(IN int PhyDrvNum, IN HANDLE hDevice, IN ENUM_READ_LOG_EXT_MODE Mode, OUT std::string *pStr)
{
    LOG_EXT_CONFIG_B0  Read_Log_Ext_B0;
    int  Rslt;
    
  
    ::memset(&Read_Log_Ext_B0, 0, sizeof(LOG_EXT_CONFIG_B0));
    
    Rslt = SSD_Utility_Get_Log_Ext_Config_B0(-1, hDevice, Mode, &Read_Log_Ext_B0);
    if (Rslt != 0) {
        return 1;
    }

    // check header
    if (::memcmp(Read_Log_Ext_B0.Image_Header_Config.Signature, IMAGE_HEADER_SIGNATURE, sizeof(Read_Log_Ext_B0.Image_Header_Config.Signature)) != 0) {
        return 1;
    }

    // log RDT INI content that are written in FTA flow --> Write_FTA_Configuration
    UINT32  Index = 0;
    char    Temp_Buffer[256 + 1];

    
    if (::strcmp(Read_Log_Ext_B0.MP_Use_Data_Config.RDT_INI_Info.Signature, RDT_INI_INFO_SIGNATURE) != 0) {
        return 1;
    }

    (*pStr) = "";
    
    UINT32 ContentSize = Read_Log_Ext_B0.MP_Use_Data_Config.RDT_INI_Info.Content_Size;        
    while (ContentSize) {
        
        // avoid incorrect size to cause access violation
        if (Index >= sizeof(Read_Log_Ext_B0.MP_Use_Data_Config.RDT_INI_Info.Content)) {
            break;
        }
        
        UINT32 Append_Size = (ContentSize >= 256) ? 256 : ContentSize;
        
        ::memset(Temp_Buffer, 0, sizeof(Temp_Buffer));
        ::memcpy(Temp_Buffer, (char*)&Read_Log_Ext_B0.MP_Use_Data_Config.RDT_INI_Info.Content[Index], Append_Size);
        
        (*pStr) += Temp_Buffer;
        Index += Append_Size;
        ContentSize -= Append_Size;
    }
    
    return 0;
}

//-------------------------------------------------------------------------------------------------
int CRDTResultManager::GetRsltCnt()
{
	return (this->m_InitSucceed == false) ? 0 : this->m_RsltCnt;
}

//-------------------------------------------------------------------------------------------------
RDT_RESULT_INFO *CRDTResultManager::GetRsltInfo()
{
	return (this->m_InitSucceed == false) ? NULL : &this->m_RsltInfo;
}

//-------------------------------------------------------------------------------------------------
RDT_BLOCK_INFO *CRDTResultManager::GetBlockInfo()
{
    return (this->m_InitSucceed == false) ? NULL : &this->m_BlockInfo;
}

//-------------------------------------------------------------------------------------------------
RDT_SPEND_TIME_INFO *CRDTResultManager::GetSpendTimeInfo()
{
	return (this->m_InitSucceed == false) ? NULL : &this->m_SpendTimeInfo;
}

//-------------------------------------------------------------------------------------------------
CYCLE_DONE_INFO *CRDTResultManager::GetCycleDoneInfo()
{
	return (this->m_InitSucceed == false) ? NULL : &this->m_CycleDoneInfo;
}

//-------------------------------------------------------------------------------------------------
std::string *CRDTResultManager::GetRDTSetting()
{
    return (this->m_InitSucceed == false) ? NULL : &this->m_RDTSetting;
}

//-------------------------------------------------------------------------------------------------
TEST_FAIL_INFO *CRDTResultManager::GetTestFailInfo()
{
	return (this->m_InitSucceed == false) ? NULL : &this->m_TestFailInfo;
}

//-------------------------------------------------------------------------------------------------
bool CRDTResultManager::IsRDTDone()
{
    return (this->m_InitSucceed == false) ? false : this->m_IsRDTDone;
}

//-------------------------------------------------------------------------------------------------
int CRDTResultManager::GetMaxTemperature()
{
	int Temp[4];

	
	Temp[0] = this->m_MaxTempInfo.TLCFullDieMaxTemp;
	Temp[1] = this->m_MaxTempInfo.SLCFullDieMaxTemp;
	Temp[2] = this->m_MaxTempInfo.TLCSamplingMaxTemp;
	Temp[3] = this->m_MaxTempInfo.SLCSamplingMaxTemp;

	std::sort(Temp, Temp + sizeof(Temp) / sizeof(int));

	return Temp[3];
}

//-------------------------------------------------------------------------------------------------
UINT32 CRDTResultManager::GetDurationTime(IN char *pSignature, IN int Cycle)
{
	bool    Is_Find;
	char    Cycle_Time_Signature[4];
	UINT32  Duration_Time;
	

	if (this->m_InitSucceed == false) {
		return 0;
	}

	Is_Find = false;
	
	for (UINT32 i = 0; i < this->m_RsltInfo.CycleRslt.size(); i++) {
		
		UINT32 Cycle_Result_Count = this->m_RsltInfo.CycleRslt[i].head.h.cycle_rec_idx + 1;
		
		for (UINT32 j = 0; j < Cycle_Result_Count; j++) {
			::memset(Cycle_Time_Signature, 0, sizeof(Cycle_Time_Signature));
			Cycle_Time_Signature[0] = (this->m_RsltInfo.CycleRslt[i].C_Result[j].rec.signature & 0xFF);
			Cycle_Time_Signature[1] = ((this->m_RsltInfo.CycleRslt[i].C_Result[j].rec.signature >> 8) & 0xFF);
            
			if ((this->m_RsltInfo.CycleRslt[i].C_Result[j].rec.g_cycle == Cycle) && (::strcmp(pSignature, Cycle_Time_Signature) == 0)) {
				Duration_Time = this->m_RsltInfo.CycleRslt[i].C_Result[j].rec.duration_time;
				Is_Find = true;
				break;
			}
		}
		
		if (Is_Find == true) {
			break;
		}
	}
	
	if (Is_Find != true) {
		Duration_Time = 0;
	}

	return Duration_Time;
}

//-------------------------------------------------------------------------------------------------
void CRDTResultManager::Convert_RDT_Time_To_String(IN UINT32 Time, IN int Format, OUT char *pStr)
{
    int   Hour;
    BYTE  Minute;
    BYTE  Second;
    
    
    Time   = Time / 10;  // convert to second, ignore float
    Hour   = Time / 3600;
    Minute = (Time % 3600) / 60;
    Second = (Time % 3600) % 60;
    
    switch (Format) {
        case 1:   ::sprintf(pStr, "%04d:%02d:%02d", Hour, Minute, Second);     break;
        case 2:   ::sprintf(pStr, "%04dH %02dM %02dS", Hour, Minute, Second);  break;
        default:  ::sprintf(pStr, "%04d:%02d:%02d", Hour, Minute, Second);
    }
    
    return;
}

//-------------------------------------------------------------------------------------------------

