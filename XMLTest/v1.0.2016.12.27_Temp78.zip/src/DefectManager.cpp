// DefectManager.cpp: implementation of the CDefectManager class.
//
///////////////////////////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SSDMP.h"
#include "DefectManager.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

///////////////////////////////////////////////////////////////////////////////////////////////////
// Construction/Destruction
///////////////////////////////////////////////////////////////////////////////////////////////////

CDefectManager::CDefectManager()
{
	this->InitMember();
}

//-------------------------------------------------------------------------------------------------
CDefectManager::~CDefectManager()
{

}

//-------------------------------------------------------------------------------------------------
int CDefectManager::Init(IN int PhyDrvNum, IN HANDLE hDevice, IN ENUM_READ_LOG_EXT_MODE Mode)
{
    BYTE       FDTable[FD_TABLE_SIZE * 512];
    BYTE       GDTable[GD_TABLE_SIZE * 512];
    int        Rslt;
    
    
	this->InitMember();
    
    //===========================================================
    //                  read defect table
    //===========================================================
    image_hdr  *pHeader;  // defect header
    UINT32     OriginalCRC;
    UINT32     CalculateCRC;
    
    
    // read factory defect
    ::memset(FDTable, 0, sizeof(FDTable));
    Rslt = SSD_CMD_Read_Log_Ext_LBA(PhyDrvNum, hDevice, Mode, FDTable, FD_TABLE_SIZE, FD_ADDR);
    if (Rslt != 0) {
        return 1;
    }
    
    // check header
    pHeader      = (image_hdr*)FDTable;
    OriginalCRC  = pHeader->crc;
    CalculateCRC = SSD_Utility_Calculate_CRC(FDTable);
    
    if ((::memcmp(pHeader->signature, FD_HEADER, sizeof(pHeader->signature)) != 0) && (OriginalCRC != CalculateCRC)) {
        return 1;
    }
    
    // read grown defect
    ::memset(GDTable, 0, sizeof(GDTable));
    Rslt = SSD_CMD_Read_Log_Ext_LBA(PhyDrvNum, hDevice, Mode, GDTable, GD_TABLE_SIZE, GD_ADDR);
    if (Rslt != 0) {
        return 1;
    }
    
    // check header
    pHeader = (image_hdr*)GDTable;
    OriginalCRC  = pHeader->crc;
    CalculateCRC = SSD_Utility_Calculate_CRC(GDTable);
    
    if ((::memcmp(pHeader->signature, GD_HEADER, sizeof(pHeader->signature)) != 0) && (OriginalCRC != CalculateCRC)) {
        return 1;
    }
    
    
    //===========================================================
    //           read config table to get nand info
    //===========================================================
    LOG_EXT_CONFIG_B0    ConfigTable;
    cfg_tbl_nand_info_t  *pNandInfo;
    
    
    ::memset(&ConfigTable, 0, sizeof(ConfigTable));
    
    Rslt = SSD_Utility_Get_Log_Ext_Config_B0(PhyDrvNum, hDevice, Mode, &ConfigTable);
    if (Rslt != 0) {
        return 1;
    }
    
    // check header
    if (::memcmp(ConfigTable.Image_Header_Config.Signature, IMAGE_HEADER_SIGNATURE, sizeof(ConfigTable.Image_Header_Config.Signature)) != 0) {
        return 1;
    }
    
    pNandInfo = &ConfigTable.MP_Use_Data_Config.A0_Info.cfg_tbl_nand_info;
    
    
    //===========================================================
    //                   parse defect
    //===========================================================
    udev_addr_t  Map[NAND_MAP_SIZE];
    int          MapSize;
    int          TotalGoodWeru;
    
    // FD
    ::memset(Map, 0, sizeof(Map));
    Rslt = Decode_NAND_Map(FDTable, Map, &MapSize);
    if (Rslt != 0) {
        return 1;
    }
    
    if (MapSize == 0) {
        SSD_Utility_Parse_Defect_Table(FDTable, pNandInfo, &this->m_FD, &TotalGoodWeru);
    }
    else {
        SSD_Utility_Parse_Defect_Table_Ex(FDTable, pNandInfo, Map, MapSize, &this->m_FD, &TotalGoodWeru);
    }
    
    
    // all defect
    ::memset(Map, 0, sizeof(Map));
    Rslt = Decode_NAND_Map(GDTable, Map, &MapSize);
    if (Rslt != 0) {
        return 1;
    }
    
    if (MapSize == 0) {
        SSD_Utility_Parse_Defect_Table(GDTable, pNandInfo, &this->m_AllDefect, &TotalGoodWeru);
    }
    else {
        SSD_Utility_Parse_Defect_Table_Ex(GDTable, pNandInfo, Map, MapSize, &this->m_AllDefect, &TotalGoodWeru);
    }
    
    // GD
    this->m_GD = this->m_AllDefect;
    this->FilterToGetGD(&this->m_FD, &this->m_GD);
    
    
    this->m_InitSucceed = true;
    
	return 0;
}

//-------------------------------------------------------------------------------------------------
void CDefectManager::InitMember()
{
    this->m_InitSucceed = false;
    
    for (int ch = 0; ch < MAX_CH; ch++) {
        for (int ce = 0; ce < MAX_CE; ce++) {
            for (int lun = 0; lun < MAX_LUN; lun++) {
                for (int plane = 0; plane < MAX_PLANE; plane++) {
                    this->m_FD.Ch[ch].Ce[ce].Lun[lun].Plane[plane].Defect_Block.clear();
                    this->m_GD.Ch[ch].Ce[ce].Lun[lun].Plane[plane].Defect_Block.clear();
                    this->m_AllDefect.Ch[ch].Ce[ce].Lun[lun].Plane[plane].Defect_Block.clear();
                }
            }
        }
    }
    
    return;
}

//-------------------------------------------------------------------------------------------------
void CDefectManager::FilterToGetGD(IN DEFECT_INFO *pFD, IN OUT DEFECT_INFO *pGD)
{
    for (int ch = 0; ch < MAX_CH; ch++) {
        for (int ce = 0; ce <MAX_CE; ce++) {
            for (int lun = 0; lun < MAX_LUN; lun++) {
                for (int plane = 0; plane < MAX_PLANE; plane++) {

                    // remove same block from grown defect
                    for (std::vector<UINT16>::iterator it1 = pFD->Ch[ch].Ce[ce].Lun[lun].Plane[plane].Defect_Block.begin(); it1 < pFD->Ch[ch].Ce[ce].Lun[lun].Plane[plane].Defect_Block.end(); it1++) {
                        for (std::vector<UINT16>::iterator it2 = pGD->Ch[ch].Ce[ce].Lun[lun].Plane[plane].Defect_Block.begin() ; it2 < pGD->Ch[ch].Ce[ce].Lun[lun].Plane[plane].Defect_Block.end(); it2++) {
                            if ((*it1) == (*it2)) {
                                pGD->Ch[ch].Ce[ce].Lun[lun].Plane[plane].Defect_Block.erase(it2);
                                break;
                            }
                        }
                    }
                }
            }
        }
    }

    return;
}

//-------------------------------------------------------------------------------------------------
DEFECT_INFO *CDefectManager::GetFD()
{
    return &this->m_FD;
}

//-------------------------------------------------------------------------------------------------
DEFECT_INFO *CDefectManager::GetGD()
{
    return &this->m_GD;
}
    
//-------------------------------------------------------------------------------------------------
DEFECT_INFO *CDefectManager::GetAllDefect()
{
    return &this->m_AllDefect;
}
    
//-------------------------------------------------------------------------------------------------
bool CDefectManager::IsInitSucceed()
{
    return this->m_InitSucceed;
}

//-------------------------------------------------------------------------------------------------

