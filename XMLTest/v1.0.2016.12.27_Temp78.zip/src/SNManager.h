// SNManager.h: interface for the CSNManager class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SNMANAGER_H__5EE247B4_46E2_467C_A3E8_502EECC5E3F1__INCLUDED_)
#define AFX_SNMANAGER_H__5EE247B4_46E2_467C_A3E8_502EECC5E3F1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//-------------------------------------------------------------------------------------------------
#include "MPDefine.h"

//-------------------------------------------------------------------------------------------------

// for the flaw of compiler
#define for if(0); else for

//-------------------------------------------------------------------------------------------------
class CSNManager  
{
public:
	CSNManager();
	virtual ~CSNManager();

	int  Init(IN char *pStartSN, IN char *pEndSN, IN char *pMask);
    
	int  GenerateSN(OUT char *pSN);
	int  GetCurrentSN(OUT char *pSN);

private:
	CRITICAL_SECTION  m_CriticalSection;

    bool  m_IsInitSucceed;
	int   m_CurrentSN[SN_LEN + 1];  // the lowest number is fomr arr[0]. +1 --> for the highest number maybe carry
    int   m_EndSN[SN_LEN + 1];
    
    int   m_SNLen;                  // current sn length
    bool  m_IsFirstGenSN;           // to let user get the sn from the start sn
        
    bool  IsStartBiggerThanEnd(IN BYTE *pStart, IN BYTE *pEnd, IN int CheckLen);
    bool  IsHexNumString(IN char *pStr, IN int StrLen);
    bool  IsDecString(IN char *pStr, IN int StrLen);
    
    
    
    
    int   m_Addend[SN_LEN];  // 
    
    char  *m_pFixPart;
    BYTE  *m_pCurrentCounterPart;
    BYTE  *m_pEndCounterPart;
    
    int   m_FixPartLen;
    int   m_CounterPartLen;
    void  ReleaseResource();
};

#endif // !defined(AFX_SNMANAGER_H__5EE247B4_46E2_467C_A3E8_502EECC5E3F1__INCLUDED_)
