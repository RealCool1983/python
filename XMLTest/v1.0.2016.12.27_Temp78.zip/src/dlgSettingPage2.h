#if !defined(AFX_DLGSETTINGPAGE2_H__E1FA6E47_6156_4A7C_9E74_D2AA769AF19E__INCLUDED_)
#define AFX_DLGSETTINGPAGE2_H__E1FA6E47_6156_4A7C_9E74_D2AA769AF19E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// dlgSettingPage2.h : header file
//

//-------------------------------------------------------------------------------------------------
#include "MPDefine.h"
#include "FileManager.h"
#include "MTableManager.h"
#include "NandInfoManager.h"

//-------------------------------------------------------------------------------------------------
enum ENUM_INI_MODE
{
    UNKNOW_INI_MODE = -1,
    AUTO_INI_MODE,
    MANUAL_INI_MODE
};


///////////////////////////////////////////////////////////////////////////////////////////////////
// CdlgSettingPage2 dialog

class CdlgSettingPage2 : public CDialog
{
// Construction
public:
	CdlgSettingPage2(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CdlgSettingPage2)
	enum { IDD = IDD_SETTING_PAGE2_DIALOG };
	int		m_RadioSelectIniMode;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CdlgSettingPage2)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CdlgSettingPage2)
	virtual BOOL OnInitDialog();
	afx_msg void OnBtnSave();
	afx_msg void OnBtnSaveAs();
	afx_msg void OnBtnDetect();
	afx_msg void OnBtnBrowseIni();
	afx_msg void OnBtnBrowseFw();
	afx_msg void OnRadioAuto();
	afx_msg void OnRadioManual();
	afx_msg void OnSelChangeComboIni();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

public:
    int   Init(IN PORT_DATA *pPortData, IN char *pMTableFullPath, IN char *pCommonBurnerFullPath);

	// interface
	int   GetIniFullPath(OUT char *pBuffer, IN int BufferLen);
	int   GetFwFullPath(OUT char *pBuffer, IN int BufferLen);
    int   GetTask(OUT int *pTask);
    int   GetDescription(OUT char *pBuffer, IN int BufferLen);

private:
    PORT_DATA       *m_pPortData;
    CFileManager    m_FileManager;
    CMTableManager  m_MTableManager;
    char            m_MTableFullPath[MAX_PATH];
    char            m_CommonBurnerFullPath[MAX_PATH];

    // interface parameter
	char            m_IniFullPath[MAX_PATH];  // FTA / FTB ini full path
    char            m_FwFullPath[MAX_PATH];
    int             m_Task;  // FTA / FTB
    
    // read / write ini parameter
	RDT_INI_SETTING m_RDTSetting;
	MP_INI_SETTING  m_MPSetting;


	void            InitUI();

    int             ReadRDTSetting();
    int             SaveRDTSetting();

    int             ReadMPSetting();
    int             SaveMPSetting();

    void            RDTSettingToUI();
    void            MPSettingToUI();
	
    int             UIToRDTSetting();
    int             UIToMPSetting();

    int             GetTaskByParseINI(IN char *pIniFullPath, OUT int *pTask);
	int             ParseString(IN char *pString, OUT int *pInteger, OUT int *pDecimal);
	int             ParseFlashIdString(IN char *pString, OUT BYTE *pFlashID);
	void            EnableRDTGroupCtrl(IN BOOL IsEnable);
	void            EnableMPGroupCtrl(IN BOOL IsEnable);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGSETTINGPAGE2_H__E1FA6E47_6156_4A7C_9E74_D2AA769AF19E__INCLUDED_)
