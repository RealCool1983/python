#if !defined(AFX_NANDINFO_H__8585A1C5_954F_4087_AC33_7A048FDE527A__INCLUDED_)
#define AFX_NANDINFO_H__8585A1C5_954F_4087_AC33_7A048FDE527A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// dlgNandInfo.h : header file
//

//-------------------------------------------------------------------------------------------------
#include "MPDefine.h"
#include "dlgShowCEPage.h"


/////////////////////////////////////////////////////////////////////////////
// CdlgNandInfo dialog

class CdlgNandInfo : public CDialog
{
// Construction
public:
	CdlgNandInfo(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CdlgNandInfo)
	enum { IDD = IDD_NAND_INFO_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CdlgNandInfo)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CdlgNandInfo)
	virtual BOOL OnInitDialog();
	afx_msg void OnSelChangeComboCe();
	afx_msg void OnBtnShowAllCe();

	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

public:
	int  Init(IN CH_ID_INFO *pIdInfo);
private:
	void  InitUI();


	CH_ID_INFO  m_IdInfo;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_NANDINFO_H__8585A1C5_954F_4087_AC33_7A048FDE527A__INCLUDED_)
