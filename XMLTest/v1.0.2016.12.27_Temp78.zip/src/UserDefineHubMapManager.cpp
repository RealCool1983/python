// UserDefineHubMapManager.cpp: implementation of the CUserDefineHubMapManager class.
//
///////////////////////////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SSDMP.h"
#include "UserDefineHubMapManager.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

///////////////////////////////////////////////////////////////////////////////////////////////////
// Construction/Destruction
///////////////////////////////////////////////////////////////////////////////////////////////////

CUserDefineHubMapManager::CUserDefineHubMapManager()
{
	::memset(&this->m_HubMap, 0, sizeof(this->m_HubMap));
	this->m_PortAlignmentMode = UNKNOW_HUB_MODE;
}

//-------------------------------------------------------------------------------------------------
CUserDefineHubMapManager::~CUserDefineHubMapManager()
{

}

//-------------------------------------------------------------------------------------------------
int CUserDefineHubMapManager::Init(IN char *pFullPathName)
{
	char  SectionName[64];
	char  KeyValue[256];
	BOOL  bIsStringDecNumeric;
	int   Rslt;
	
	
	//======================================================
	//           read section [Operator]
	//======================================================
	::memset(SectionName, 0, sizeof(SectionName));
	::strcpy(SectionName, "Operator");
	
	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(pFullPathName, SectionName, "PortAlignmentMode", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		return 1;
	}
	
	this->m_PortAlignmentMode = ::atoi(KeyValue);
	
	
	//======================================================
	//               read section [Hub]
	//======================================================
	::memset(SectionName, 0, sizeof(SectionName));
	::strcpy(SectionName, "Hub");
	
	
	TCHAR  szTopicName[MAX_PATH];
	int    nKeyValue; 
	int	   HubCount = 0;    //Anjoy_0205	
	//max 16 port ,so up to 4 hub
	for(int i = 0; i < 8; i++){    //4*2 => U2/U3 hub name is different,so  give 8 opportunity
		BOOL bAddDrive = FALSE;
		//Hubname
		::memset(KeyValue, 0, sizeof(KeyValue));
		::memset(szTopicName, 0, sizeof(szTopicName));
		::_stprintf(szTopicName, _T("HubName%d"), i+1);
		Rslt = this->m_FileManager.ReadIniFile(pFullPathName, SectionName, szTopicName, KeyValue, sizeof(KeyValue));
		
		if(Rslt != 0) {
			continue;
		}
		//need to check is the same hub for U2/U3
		for(HubCount=0; HubCount < 4; HubCount++) {
			if(::_tcscmp(this->m_HubMap[HubCount].HubName, KeyValue) == 0) {    //the same hub, no need to record to m_szHubName
				break;
			}
			else if(::_tcslen(this->m_HubMap[HubCount].HubName) == 0) {           //check HubInfo Hubname is empty or not
				::_tcscpy(this->m_HubMap[HubCount].HubName, KeyValue);          //new hub, need to record to m_szHubName
				bAddDrive = TRUE;				
				break;	
			}
			else{   //check this HubName is the same U2/U3 or new Hub
				//Analysis this Hubname
				TCHAR szHubNameTempSave[MAX_PATH];
				TCHAR szHubNameSearch[MAX_PATH];
				TCHAR szHubNameTemp[MAX_PATH];
				TCHAR *pHubNameTempStart;
				TCHAR *pHubNameTempEnd;
				
				//Find "pid" string
				::memset(szHubNameSearch, 0 ,sizeof(szHubNameSearch));
				::_tcscpy(szHubNameSearch, _T("pid"));
				pHubNameTempStart = ::_tcsstr(KeyValue,szHubNameSearch);
				if(pHubNameTempStart == NULL){
					::memset(szHubNameSearch, 0 ,sizeof(szHubNameSearch));
					::_tcscpy(szHubNameSearch, _T("PID"));
					pHubNameTempStart = ::_tcsstr(KeyValue,szHubNameSearch);
					if(pHubNameTempStart == NULL){
						continue;
					}
				}
				//copy PID to szHubNamePID
				TCHAR szHubNameTempPID[8];
				::memset(szHubNameTempPID, 0 ,sizeof(szHubNameTempPID));
				::memcpy(szHubNameTempPID, pHubNameTempStart, sizeof(szHubNameTempPID));
				
				//find #~~~#
				::memset(szHubNameSearch, 0 ,sizeof(szHubNameSearch));
				::_tcscpy(szHubNameSearch, _T("#"));
				pHubNameTempStart = ::_tcsstr(pHubNameTempStart,szHubNameSearch);
				if(pHubNameTempStart == NULL){
					continue;
				}
				
				//cpy to szHubNameTemp
				pHubNameTempStart++;//ignaor #
				::memset(szHubNameTemp, 0 ,sizeof(szHubNameTemp));
				::memcpy(szHubNameTemp, pHubNameTempStart, sizeof(TCHAR) * MAX_PATH);
				
				//find next #
				::memset(szHubNameSearch, 0 ,sizeof(szHubNameSearch));
				::_tcscpy(szHubNameSearch, _T("#"));
				pHubNameTempEnd = ::_tcsstr(pHubNameTempStart,szHubNameSearch);
				if(pHubNameTempEnd == NULL){
					continue;
				}
				pHubNameTempEnd --;//move to number before # 
				TCHAR ExHubPortNumber = *pHubNameTempEnd;
				pHubNameTempEnd --;//ignor external hub port number
				
				//copy to szHubNameTempSave
				::memset(szHubNameTempSave, 0 ,sizeof(szHubNameTempSave));
				for(int a = 0;  pHubNameTempStart <= pHubNameTempEnd ; a++){
					szHubNameTempSave[a] =szHubNameTemp[a];
					pHubNameTempStart++;
				}
				
				//Analysis Ext-4port HunInfo Hubname
				TCHAR szExtHubNameSearch[MAX_PATH];
				TCHAR szExtHubNameTempSave[MAX_PATH];
				TCHAR szExtHubNameTemp[MAX_PATH];
				TCHAR *pExtHubNameTempStart;
				TCHAR *pExtHubNameTempEnd;
				
				//Find "pid" string
				::memset(szExtHubNameSearch, 0 ,sizeof(szExtHubNameSearch));
				::_tcscpy(szExtHubNameSearch, _T("pid"));
				pExtHubNameTempStart = ::_tcsstr(this->m_HubMap[HubCount].HubName,szExtHubNameSearch);
				if(pExtHubNameTempStart == NULL){
					::memset(szExtHubNameSearch, 0 ,sizeof(szExtHubNameSearch));
					::_tcscpy(szExtHubNameSearch, _T("PID"));
					pExtHubNameTempStart = ::_tcsstr(this->m_HubMap[HubCount].HubName,szExtHubNameSearch);
					if(pExtHubNameTempStart == NULL){
						continue;
					}
				}
				
				//copy PID to szExt4PorHubNamePID
				TCHAR szExtHubNameTempPID[8];
				::memset(szExtHubNameTempPID, 0 ,sizeof(szExtHubNameTempPID));
				::memcpy(szExtHubNameTempPID, pExtHubNameTempStart, sizeof(szExtHubNameTempPID));
				
				//find #~~~#
				::memset(szExtHubNameSearch, 0 ,sizeof(szExtHubNameSearch));
				::_tcscpy(szExtHubNameSearch, _T("#"));
				pExtHubNameTempStart = ::_tcsstr(pExtHubNameTempStart,szExtHubNameSearch);
				if(pExtHubNameTempStart == NULL){
					continue;
				}
				
				//cpy to szHubNameTemp
				pExtHubNameTempStart++;//ignaor #
				::memset(szExtHubNameTemp, 0 ,sizeof(szExtHubNameTemp));
				::memcpy(szExtHubNameTemp, pExtHubNameTempStart, sizeof(TCHAR) * MAX_PATH);
				
				//find next #
				pExtHubNameTempEnd = ::_tcsstr(pExtHubNameTempStart,szExtHubNameSearch);
				if(pExtHubNameTempEnd == NULL){
					continue;
				}
				
				pExtHubNameTempEnd--;
				TCHAR ExtHubNumber = *pExtHubNameTempEnd;
				pExtHubNameTempEnd--;
				
				//copy to szExtHubNameTempSave
				::memset(szExtHubNameTempSave, 0 ,sizeof(szExtHubNameTempSave));
				for(int b = 0;  pExtHubNameTempStart <= pExtHubNameTempEnd ; b++){
					szExtHubNameTempSave[b] =szExtHubNameTemp[b];
					pExtHubNameTempStart++;
				}
				
				//check the name #~~~~~# is the same or not 
				if(::_tcscmp(szExtHubNameTempSave, szHubNameTempSave) != 0) {
					continue;
				}
				//check is it one on U2 mode and one on U3 mode,if yes, maybe thay the same hub 
				if(::memcmp(szExtHubNameTempPID, szHubNameTempPID, sizeof(szExtHubNameTempPID)) == 0){//Anjoy_0207
					continue;
				}
				//check are they the same hub 
				ExtHubNumber = (ExtHubNumber % 2);
				ExHubPortNumber = (ExHubPortNumber % 2);
				
				//NEC 3.0 Root Hub 1,2 => U3; 3,4 => U2 & 1/3 one ext-hub for U3/U2 , 2/4 one ext-hub for U3/U2
				if(ExtHubNumber == ExHubPortNumber){//the same hub, no need to record to m_szHubName
					//Anjoy_0212 for warning user to do Scan Hub again
					CString  strText = "Please Scan Hub again, and make sure all devices under U2 mode";
					::AfxMessageBox(strText);
					return 1;
				}
			}
		}
		
		if (bAddDrive == FALSE) { 
			continue;
		}
		
		//HubNumber
		::memset(KeyValue, 0, sizeof(KeyValue));
		::memset(szTopicName, 0, sizeof(szTopicName));
		::_stprintf(szTopicName, _T("HubNumber%d"), i+1);
		Rslt = this->m_FileManager.ReadIniFile(pFullPathName, SectionName, szTopicName, KeyValue, sizeof(KeyValue));
		if (Rslt == 0) {
			bIsStringDecNumeric = IsStringDecNumeric(KeyValue, ::_tcslen(KeyValue));
			if(bIsStringDecNumeric == TRUE) {				
				nKeyValue = ::_ttoi(KeyValue);
				//	this->m_HubNumber[i] = nKeyValue;
				this->m_HubMap[HubCount].HubNumber = nKeyValue;//Anjoy_0205
			}
			
		}
		
		//PortCount	
		::memset(KeyValue, 0, sizeof(KeyValue));
		::memset(szTopicName, 0, sizeof(szTopicName));
		::_stprintf(szTopicName, _T("PortCount%d"), i+1);
		Rslt = this->m_FileManager.ReadIniFile(pFullPathName, SectionName, szTopicName, KeyValue, sizeof(KeyValue));
		if (Rslt == 0) {
			bIsStringDecNumeric = IsStringDecNumeric(KeyValue, ::_tcslen(KeyValue));
			if(bIsStringDecNumeric == TRUE) {
				nKeyValue = ::_ttoi(KeyValue);
				//	this->m_PortCount[i] = nKeyValue;
				this->m_HubMap[HubCount].PortCount = nKeyValue;  //Anjoy_0205
			}
		}
	}
    
    return 0;
}

//-------------------------------------------------------------------------------------------------
BOOL CUserDefineHubMapManager::IsStringDecNumeric(IN char *pStr, IN DWORD dwStrLength)
{
	if (dwStrLength <= 0) {
		return FALSE;
	}

	for (DWORD i=0; i<dwStrLength; i++) {
		if (!::isdigit(pStr[i]))
			return FALSE;
	}

	return TRUE;
}

//-------------------------------------------------------------------------------------------------
