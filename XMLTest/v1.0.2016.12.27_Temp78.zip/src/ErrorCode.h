#ifndef __ERROR_CODE_H__
#define __ERROR_CODE_H__


//-------------------------------------------------------------------------------------------------

enum ENUM_ERROR_CODE
{
    MP_NO_ERROR,

    // let UI error code start from 1000
    ERR_GET_DEV_HANLDE = 1000,        // 1000
    ERR_GET_FW_MODE,                  // 1001
    ERR_GENERATE_SN,                  // 1002
    ERR_CREATE_STDOUT_PIPE,           // 1003
    ERR_CREATE_STDIN_PIPE,            // 1004
    ERR_CREATE_PROCESS,               // 1005
    ERR_PARSE_RECV_STRING,            // 1006
    ERR_WAIT_DEV_REMOUNT_TIME_OUT,    // 1007
    ERR_WRITE_DATA_TO_PIPE,           // 1008
    ERR_OUT_OF_KEY,                   // 1009
    ERR_KEY_PRO_DRIVE_REMOVED,        // 1010
    ERR_INIT_PORT_LOG_MANAGER,        // 1011
    ERR_GET_PATH_TO_LOG,              // 1012
    ERR_GET_PATH_FOR_COMMAND_LINE,    // 1013
    
    
    // command fail
    ERR_CMD_REBOOT_TO_FW = 1300,      // 1300
    ERR_CMD_IDENTIFY_DEVICE           // 1301
};


//-------------------------------------------------------------------------------------------------

#endif  // __ERROR_CODE_H__
