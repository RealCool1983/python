// RDTResultManager.h: interface for the CRDTResultManager class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_RDTRESULTMANAGER_H__541D45D8_A04B_4286_B3CA_8F04B89C2C24__INCLUDED_)
#define AFX_RDTRESULTMANAGER_H__541D45D8_A04B_4286_B3CA_8F04B89C2C24__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//-------------------------------------------------------------------------------------------------
#include <vector>
#include <algorithm>  // for std::sort

#include "SSD_Command.h"
#include "SSD_Utility.h"

//-------------------------------------------------------------------------------------------------
enum PRELOAD_MODE { PRELOAD_NORMAL_MODE, PRELOAD_ONE_SHOT_MODE, PRELOAD_VERIFY_ONLY_MODE };


#pragma pack(1)


typedef struct _RDT_SPEND_TIME_INFO
{
    UINT32  Total_Spend_Time;
    UINT32  SLC_Full_Die_Spend_Time;
    UINT32  TLC_Full_Die_Spend_Time;
    UINT32  SLC_Sampling_Spend_Time;
    UINT32  TLC_Sampling_Spend_Time;
} RDT_SPEND_TIME_INFO, *PRDT_SPEND_TIME_INFO;


typedef struct _CYCLE_DONE_INFO
{
    UINT32  SLC_Full_Die_Cycle_Done;
    UINT32  SLC_Full_Die_Target_Cycle;
    bool    Is_SLC_Full_Die_Cycle_Done;
    
    UINT32  TLC_Full_Die_Cycle_Done;
    UINT32  TLC_Full_Die_Target_Cycle;
    bool    Is_TLC_Full_Die_Cycle_Done;
    
    UINT32  SLC_Sampling_Cycle_Done;
    UINT32  SLC_Sampling_Target_Cycle;
    bool    Is_SLC_Sampling_Cycle_Done;
    
    UINT32  TLC_Sampling_Cycle_Done;
    UINT32  TLC_Sampling_Target_Cycle;
    bool    Is_TLC_Sampling_Cycle_Done;
} CYCLE_DONE_INFO, *PCYCLE_DONE_INFO;


typedef struct _RDT_RESULT_INFO
{
	std::vector<RDT_RESULT>    TLCFullDieRslt;   // TLC full die RDT result
	std::vector<RDT_RESULT>    SLCFullDieRslt;   // SLC full die RDT result
	std::vector<RDT_RESULT>    TLCSamplingRslt;  // TLC sampling RDT result
	std::vector<RDT_RESULT>    SLCSamplingRslt;  // SLC smapling RDT result
	std::vector<CYCLE_RESULT>  CycleRslt;
	std::vector<RDT_RESULT>    PowerRslt;
} RDT_RESULT_INFO, *PRDT_RESULT_INFO;


typedef struct _RDT_BLOCK_INFO
{
    std::vector<RDT_BLOCK_RESULT>  TLCFullDie;   // TLC full die block
    std::vector<RDT_BLOCK_RESULT>  SLCFullDie;   // SLC full die block
    std::vector<RDT_BLOCK_RESULT>  TLCSampling;  // TLC sampling block
    std::vector<RDT_BLOCK_RESULT>  SLCSampling;  // SLC sampling block
} RDT_BLOCK_INFO, *PRDT_BLOCK_INFO;


typedef struct _FAIL_TYPE_COUNT_INFO
{
	int  uECCFailCount;
	int  ProgramFailCount;
	int  EraseFailCount;
	int  OverThresholdFailCount;
	int  FactoryDefectCount;
	int  OtherFailCount;
	int  TotalFailCount;
} FAIL_TYPE_COUNT_INFO, *PFAIL_TYPE_COUNT_INFO;


typedef struct _TEST_FAIL_INFO
{
	FAIL_TYPE_COUNT_INFO  TLCFullDie;
	FAIL_TYPE_COUNT_INFO  SLCFullDie;
	FAIL_TYPE_COUNT_INFO  TLCSampling;
	FAIL_TYPE_COUNT_INFO  SLCSampling;
} TEST_FAIL_INFO, *PTEST_FAIL_INFO;


typedef struct _MAX_TEMPERATURE_INFO
{
	int  TLCFullDieMaxTemp;
	int  SLCFullDieMaxTemp;
	int  TLCSamplingMaxTemp;
	int  SLCSamplingMaxTemp;
} MAX_TEMPERATURE_INFO, *PMAX_TEMPERATURE_INFO;


#pragma pack()


//-------------------------------------------------------------------------------------------------
class CRDTResultManager  
{
public:
	static void  Convert_RDT_Time_To_String(IN UINT32 Time, IN int Format, OUT char *pStr);

public:
	CRDTResultManager();
	virtual ~CRDTResultManager();

	int                  Init(IN int PhyDrvNum, IN HANDLE hDevice, IN ENUM_READ_LOG_EXT_MODE ReadMode, IN PRELOAD_MODE PreloadMode);

	// interface
	int                  GetRsltCnt();
	RDT_RESULT_INFO      *GetRsltInfo();
    RDT_BLOCK_INFO       *GetBlockInfo();
	RDT_SPEND_TIME_INFO  *GetSpendTimeInfo();
	CYCLE_DONE_INFO      *GetCycleDoneInfo();
    std::string          *GetRDTSetting();
	TEST_FAIL_INFO       *GetTestFailInfo();
	int                  GetMaxTemperature();
    bool                 IsRDTDone();
	UINT32               GetDurationTime(IN char *pSignature, IN int Cycle);
	

private:
	bool                  m_InitSucceed;
    
    bool                  m_IsRDTDone;
	UINT32                m_RsltCnt;     // total result count that read from 0xB2
    std::string           m_RDTSetting;  // RDT setting info that is record in the config MP area
	RDT_RESULT_INFO       m_RsltInfo;
    RDT_BLOCK_INFO        m_BlockInfo;
    RDT_SPEND_TIME_INFO   m_SpendTimeInfo;
    CYCLE_DONE_INFO       m_CycleDoneInfo;
	TEST_FAIL_INFO        m_TestFailInfo;
	MAX_TEMPERATURE_INFO  m_MaxTempInfo;    


    void  InitMember();
    int   ParseCycleDoneInfo(IN RDT_RESULT *pRslt, OUT CYCLE_DONE_INFO *pInfo, OUT bool *pIsDone);  // input: 0xB1 result
    int   ParseSpendTimeInfo(IN RDT_RESULT *pRslt, OUT RDT_SPEND_TIME_INFO *pInfo);
	void  ParseFailInfo(IN std::vector<RDT_BLOCK_RESULT> *pRslt, IN bool IsIgnoreFD, OUT FAIL_TYPE_COUNT_INFO *pFailInfo);
	void  ParseMaxTempInfo(IN std::vector<RDT_BLOCK_RESULT> *pBlockInfo, OUT int *pMaxTemp);
    void  ParseFullDieBlockInfo(IN std::vector<RDT_RESULT> *pRslt, OUT std::vector<RDT_BLOCK_RESULT> *pBlockInfo);
    void  ParseSamplingBlockInfo(IN std::vector<RDT_RESULT> *pRslt, IN PRELOAD_MODE PreloadMode, OUT std::vector<RDT_BLOCK_RESULT> *pBlockInfo);
	
    bool  IsRsltSignatureCorrect(IN RDT_RESULT *pRslt);
    int   ReadRDTSetting(IN int PhyDrvNum, IN HANDLE hDevice, IN ENUM_READ_LOG_EXT_MODE Mode, OUT std::string *pStr);
};

//-------------------------------------------------------------------------------------------------

#endif // !defined(AFX_RDTRESULTMANAGER_H__541D45D8_A04B_4286_B3CA_8F04B89C2C24__INCLUDED_)
