// MPIniManager.cpp: implementation of the CMPIniManager class.
//
///////////////////////////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SSDMP.h"
#include "MPIniManager.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

///////////////////////////////////////////////////////////////////////////////////////////////////
// Construction/Destruction
///////////////////////////////////////////////////////////////////////////////////////////////////

CMPIniManager::CMPIniManager()
{

}

//-------------------------------------------------------------------------------------------------
CMPIniManager::~CMPIniManager()
{

}

//-------------------------------------------------------------------------------------------------
int CMPIniManager::Init(IN char *pFullPathName)
{
	CString  StrMsg;
	BOOL     IsFileExist;
	char     SectionName[64];
	char     KeyValue[256];
	int      Rslt;

	IsFileExist = this->m_FileManager.IsFileExist(pFullPathName);
	if (IsFileExist == FALSE) {
		StrMsg.Format("file is not exit. file = %s", pFullPathName);
		::AfxMessageBox(StrMsg, MB_OK | MB_ICONERROR);
		return 1;
	}


    //======================================================
	//            read section [Setting]
	//======================================================
	::memset(SectionName, 0, sizeof(SectionName));
	::strcpy(SectionName, _T("Setting"));


	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(pFullPathName, SectionName, "Port_Alignment_Mode", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	this->m_PortAlignmentMode = ::atoi(KeyValue);


	::memset(KeyValue, 0, sizeof(KeyValue));
	Rslt = this->m_FileManager.ReadIniFile(pFullPathName, SectionName, "Start_SN", KeyValue, sizeof(KeyValue));
	if (Rslt != 0) {
		::strcpy(KeyValue, "0");  // default value
	}
	::memset(this->m_SN, 0, sizeof(this->m_SN));
	::strncpy(this->m_SN, KeyValue, SN_LEN);

	return 0;
}

//-------------------------------------------------------------------------------------------------
