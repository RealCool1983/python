#if !defined(AFX_DLGSETTINGPAGE1_H__D248A15B_9C41_4AFC_B6E6_0D7CFFB30DB3__INCLUDED_)
#define AFX_DLGSETTINGPAGE1_H__D248A15B_9C41_4AFC_B6E6_0D7CFFB30DB3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// dlgSettingPage1.h : header file
//

//-------------------------------------------------------------------------------------------------
#include "FileManager.h"
#include "SNManager.h"

//-------------------------------------------------------------------------------------------------

///////////////////////////////////////////////////////////////////////////////////////////////////
// CdlgSettingPage1 dialog

class CdlgSettingPage1 : public CDialog
{
// Construction
public:
	CdlgSettingPage1(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CdlgSettingPage1)
	enum { IDD = IDD_SETTING_PAGE1_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CdlgSettingPage1)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CdlgSettingPage1)
	virtual BOOL OnInitDialog();
	afx_msg void OnBtnSave();
	afx_msg void OnBtnSaveAs();
	afx_msg void OnBtnApplyMask();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()


public:
    int   Init(IN char *pMPIniFullPath, IN char *pSNIniFullPath);


	int   m_PortAlignmentMode;
    char  m_StartSN[SN_LEN + 1];
    char  m_EndSN[SN_LEN + 1];
    char  m_Mask[SN_LEN + 1];

private:	
    CFileManager  m_FileManager;
	char          m_MPIniFullPath[MAX_PATH];  // .\SSDMP.ini
    char          m_SNIniFullPath[MAX_PATH];  // C:\SSD_SN.ini

	void          InitUI();
	void          SettingToUI();
	int           UIToSetting();
	int           SaveSetting();
	int           SaveCurrentSN();
	bool          IsHexNumString(IN char *pStr, IN int StrLen);
	void          SetMask(OUT char *pStr, IN char *pMask);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGSETTINGPAGE1_H__D248A15B_9C41_4AFC_B6E6_0D7CFFB30DB3__INCLUDED_)
