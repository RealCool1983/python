#ifndef __MPDEFINE_H__
#define __MPDEFINE_H__

//-------------------------------------------------------------------------------------------------
#include "SSD_Utility.h"
#include "NandInfoManager.h"
#include "LogManager.h"

//-------------------------------------------------------------------------------------------------
enum ENUM_PORT_ALIGNMENT { UNKNOW_HUB_MODE, ALL_HUB_MODE, EXT_4PORT_MODE, EXT_7PORT_MODE };
enum ENUM_KEY_PRO_STATUS { NO_NEED_KEY, NEED_KEY, OUT_OF_KEY };

// user message
#define WM_START_RUN             (WM_USER + 1)
#define WM_UPDATE_PROGRESS       (WM_USER + 2)
#define WM_THREAD_TERMINATE      (WM_USER + 3)
#define WM_ALL_THREAD_TERMINATE  (WM_USER + 4)
#define WM_SCAN_DRIVE            (WM_USER + 5)
#define WM_CHANGE_SN             (WM_USER + 6)
#define WM_UPDATE_DESCRIPTION    (WM_USER + 7)


// color
#define COLOR_BLUE   RGB(0, 0, 255)
#define COLOR_GREEN  RGB(0, 139, 0)
#define COLOR_RED    RGB(255, 0, 0)


// environment
#define MAX_USB_DRIVE_COUNT    (128)  // defined by usb spec
#define SUPPORT_PORT_COUNT     (16)
#define EXT_4PORT_HUB_COUNT    (4)
#define EXT_7PORT_HUB_COUNT    (2)
#define WAIT_REBOOT_TIME_OUT   (10 * 1000)  // unit: second
#define WAIT_PROCESS_TIME_OUT  (5 * 1000)   // unit: second
//#define FLASH_ID_LENGTH        (6)


// ata identify device
#define  MODEL_NAME_LEN  (40)  // unit: char
#define  SN_LEN          (20)  // unit: char


// receive key word string from MP
#define RECV_TEST_PASS         "Pass"
#define RECV_TEST_FAIL         "Fail"
#define RECV_PROGRESS          "[Progress]"
#define RECV_REBOOT_TO_ROM     "[reboot to rom]"
#define RECV_WAIT_NEW_DRV_NUM  "wait new physical drive number"
#define RECV_ERR_CODE          "[Error_Code]"
#define RECV_TEST_RSLT         "[Test_Result]"


#define TLC_SAMPLED_WERU_BITMAP_SIZE  (181)  // unit: byte
#define SLC_SAMPLED_WERU_BITMAP_SIZE  (181)  // unit: byte

#define FTA_TASK  "FTA"
#define FTB_TASK  "FTB"

//-------------------------------------------------------------------------------------------------
#pragma pack(1)

typedef struct _HUB_DATA
{
    char   HubName[256];
    int    PortNumber;
    int    HubNumber;  // virtual hub number
    BOOL   IsRootHub;
} HUB_DATA, *PHUB_DATA;


typedef struct _CMD_LINE_MP_PARAM
{
    char  Task[16];                  // record MP, RDT or QC task name
    char  ConfigFullPath[MAX_PATH];  // config ini path
    char  FWFullPath[MAX_PATH];      // fw bin file path
    char  WO[16];                    // work order number
    char  SN[20 + 1];                // serial number
    char  LogFullPath[MAX_PATH];     // log path
    BYTE  WWN[8];                    // world wide name
} CMD_LINE_MP_PARAM, *PCMD_LINE_MP_PARAM;


typedef struct _TIME_INFO {
	SYSTEMTIME  StartTime;
	SYSTEMTIME  EndTime;
} TIME_INFO, *PTIME_INFO;


typedef struct _PORT_DATA
{
    int                PhyDrvNum;
    int                MapIndex;
    HANDLE             hWorkThread;
    
    int                ErrorCode;
    HUB_DATA           HubData;
    char               MPExeFullPath[MAX_PATH];
    CMD_LINE_MP_PARAM  MPParam;
	int                Mode;         // original firmware mode
    bool               IsReduceKey;  // record is need to reduce key count this run
	int                KeyProStatus;
    UINT64             CardSize;     // unit: sector
	CNandInfoManager   NandInfoManager;
	CLogManager        LogManager;
	TIME_INFO          TimeInfo;
	char               UILogFullPath[MAX_PATH];
	char               UILogPath[MAX_PATH];
	char               UILogName[MAX_PATH];
	ATA_IDENTIFY_CONFIG_INFO  IdentifyDevice;
	
    
    // user info
	int                PassCount;  // will be kept until user reset
	int                FailCount;  // will be kept until user reset
    
} PORT_DATA, *PPORT_DATA;


typedef struct _PIPE_STDIN
{
    HANDLE  hWrite;
    HANDLE  hRead;
} PIPE_STDIN, *PPIPE_STDIN;


typedef struct _PIPE_STDOUT
{
    HANDLE  hWrite;
    HANDLE  hRead;
} PIPE_STDOUT, *PPIPE_STDOUT;


typedef struct _ANONYMOUS_PIPE_INFO
{
    PIPE_STDIN   Stdin;   // pipe for child process stdin
	PIPE_STDOUT  Stdout;  // pipe for child process stdout
} ANONYMOUS_PIPE_INFO, *PANONYMOUS_PIPE_INFO;


typedef struct _RDT_INI_SETTING
{
    // [SSD_Info]
    char  BOM_No[128];                       // Part Number of 99 ,16 bytes
    char  Controller_Name[64];
    char  Model_Name[MODEL_NUMBER_LEN + 1];  // Kingston product name, need to write this into SSD
    char  Controller_Vendor[64];
    char  Chamber_Port_ID[64];

    // [Tool_Info]
    char  Firmware_Version[16];              // FW version
    char  Tool_Name[128];
    char  Tool_Vendor[64];

    // [FW bin file path]
    char  Burner_Path[MAX_PATH];

    // [Test_Condition]
    char  Previous_Stage[16];
    char  Current_Stage[16];                 // Test Stage, FTA or FTB or QC ...

    int   TLC_Full_Die_Cycles;               // TLC full die test cycle
    int   SLC_Full_Die_Cycles;               // SLC full die test cycle

    int   Mark_Bad;                          // Mark the sample block as early bad block after test, '1' means enable this function
    int   MP_Test;
    int   Preload_Data;                      // 0 --> normal sampling test, 1 --> 1 shot + verification, 2 --> verification only
    int   Bad_Sample_Block_Per_CE;           // If sample block fail with ECC threshold in the end or program/erase/UECC happen in the middle of the cycle then it count as bad block. If the number is more than this setting. Then the MP FW download should not countinue.

    int   TLC_Dwell_Time;                    // wait time for test next weru. unit: 100 millisecond
    int   TLC_Sampling_Cycle;                // TLC sample block test cycle
    int   TLC_ECC_Log_Interval;              // for sampling test. ex: get a raw bit error log per 10 cycle.
    int   TLC_Start_Select_Block;            // Sample block test start from this block
    int   TLC_End_Select_Block;              // Sample block test end with this block
    int   TLC_Random_Block;  		         // Select by address=0, random select =1
    int   TLC_Sampling_Block_Quantity;       // TLC samplingBlock qty
    int   TLC_Sampling_ECC_Bit_Threshold;    // bit error threshold. both sampling and full die refer to this setting
    BYTE  TLC_Sampled_WERU_Bitmap[TLC_SAMPLED_WERU_BITMAP_SIZE];

    int   SLC_Dwell_Time;                    // wait time for test next weru. unit: 100 millisecond
    int   SLC_Sampling_Cycle;                // SLC sample block test cycle
    int   SLC_ECC_Log_Interval;              // for sampling test. ex: get a raw bit error log per 10 cycle.
    int   SLC_Random_Block;                  // Select by address=0, random select =1
    int   SLC_Sampling_Block_Quantity;       // SLC samplingBlock qty
    int   SLC_Start_Select_Block;            // Sample block test start from this block
    int   SLC_End_Select_Block;              // Sample block test end with this block
    int   SLC_Sampling_ECC_Bit_Threshold;    // bit error threshold. both sampling and full die refer to this setting
    BYTE  SLC_Sampled_WERU_Bitmap[SLC_SAMPLED_WERU_BITMAP_SIZE];

    int   TLC_Full_Die_ECC_Log_Interval;     // for full die test. interval cycle to read verify. if set 0, will verify in the last cycle
    int   SLC_Full_Die_ECC_Log_Interval;     // for full die test. interval cycle to read verify. if set 0, will verify in the last cycle

    BYTE  LED_Mode;                          // LED flash mode. 0: for KDI, 1: for ADATA
    /*
    int  Level_1_throttling;
    int  Level_2_throttling;                // the degree to start thermal throttling
    */
    BYTE  Pattern_Mode;
    
    UINT32  RDT_GD_TH;                      // RDT grown defect threshold
    BYTE    LED_Light_Time;
    BYTE    LED_Dark_Time;
    BYTE    LDPC_Switch;
    BYTE    Full_Die_Deep_Read_Retry_Option;  // 1: full die test turn on Deep Read Retry, 2: full die test turn off deep read retry
    UINT16  Full_Die_Erase_Count_Threshold;   // if weru�s erase count >= Erase_Count_Threshold, RDT will by pass this weru when TLC full die test.
                                              // set 0 will not check weru's erase count
                                              
    UINT16  Bypass_SLC_Weru_For_TLC_Full_Die_Test;
    UINT32  TLC_Full_Die_ECC_Bit_Threshold;
    UINT32  SLC_Full_Die_ECC_Bit_Threshold;
    

    // [Production_Setting]
    int   Serial_Number;
    int   SN_Length;
    char  SKU[128];

    // [MP_Option]
    bool   Is_Force_Erase_All;
    bool   Is_Keep_Setting;
    bool   Is_Backup_Table;                               // backup EC, FD, GD tables, file name of these files are with serial number
    char   Backup_Table_Folder_Full_Path_Name[MAX_PATH];  // backup table folder
    bool   Is_Ignore_Scan_Later_Defect;                   // for new card flow. ignore fw scan later defect condition (1k page with 30 zero bit)
    UINT16 Good_Block_Per_Plane;                          // MP block critera
    UINT16 Total_Good_WERU;                               // MP block critera
    UINT32 Replace_Table_Bit_Map;                         // set 1 to replace table.  bit#0: EC, bit#1: FD, bit#2: GD
    bool   Mark_Bad_Sampling_Block;                       // if sampling test blocks are not done, mark bad them to the grown defect table
    int    CE_Count;
    BYTE   Flash_ID[FLASH_ID_LENGTH];
    char   Manual_Mark_Bad_Table_Full_Path_Name[MAX_PATH];
    int    Download_FW_Retry;
    int    Non_Preprogram_Safe_Erase_All_Retry;
    UINT32 Endurance;                                     // SSD life left info

    // using Is_Recv_Drv_Num_By_UI option instead
    /*
    bool   Enable_Named_Pipe;                             // for windows version. need server send new physical drive number when do reboot
    */

    char   Remote_IP[16];                                 // check KeyPro by remote drive mode
    char   Local_Path[16];                                // check KeyPro by local drive mode
    bool   Enable_Check;                                  // cancel check KeyPro. just temp function, because check KeyPro function should always enable !!
    bool   Is_Log_Event_Log;
    bool   Is_Recv_Drv_Num_By_UI;                         // get physical drive number from UI
    BYTE   Nand_Phy_Calibration;                          // bit#0 of 6th byte in the burner binary
                                                          // 0: nand flash run as toggle 2 and only set feature Vref (single end mode)
                                                          // 1: nand flash run as toggle 2 and set featrue Vref, DQS_Bar, RE (differential mode)
    BYTE   Bypass_Preprogram;                             // bit#1 of 6th byte in the burner binary
                                                          // 0: not bypss  1: bypass
    bool   Is_Read_Sorting_Table;
    char   User_FW_Revision[8 + 1];                       // fw revision length of identify device is 8 bytes ata string (pad the string with spece --> 20h)
    bool   Is_Too_Many_Defect_Error_Safe_Erase;
    int    Read_Log_Ext_Mode;
    BYTE   DA_Read;
    
    BYTE   ADATA_Scan_DF_Mode;                            // 0: normal scan defect  1: only scan original defect and sorting mark mad
    BYTE   Toggle_Speed;
    

} RDT_INI_SETTING, *PRDT_INI_SETTING;


typedef struct _MP_INI_SETTING
{
    // [SSD_Info]
    char  BOM_No[128];                       // Part Number of 99 ,16 bytes
    char  Controller_Name[64];
    char  Model_Name[MODEL_NUMBER_LEN + 1];  // Kingston product name, need to write this into SSD
    char  Controller_Vendor[64];
    char  Chamber_Port_ID[64];

    // [Tool_Info]
    char  Firmware_Version[16];              // FW version
    char  Tool_Name[128];
    char  Tool_Vendor[64];

    // [Test_Condition]
    char  Previous_Stage[16];
    char  Current_Stage[16];                 // Test Stage, FTA or FTB or QC...
    int   Preload_Data;                      // according to Preload_Data type to read back RDT sampling result

    // [Production_Setting]
    int   Serial_Number;
    int   SN_Length;
    char  SKU[128];

    // [FW bin file path]
    char  Burner_Path[MAX_PATH];

    // [MP_Option]
    bool   Is_Force_Erase_All;
    bool   Is_Force_ReMP;
    bool   Is_Ignore_RDT_Result;                          // for RDT result miss bug.
    bool   Is_Read_RDT_Result_Only;                       // only read RDT result, will not do MP
    bool   Is_Keep_Setting;                               // keep config, factory defect, grown defect, and erase count table
    bool   Is_Backup_Table;                               // backup EC, FD, GD tables, file name of these files are with serial number
    char   Backup_Table_Folder_Full_Path_Name[MAX_PATH];  // backup table folder
    bool   Is_Ignore_Scan_Later_Defect;                   // for new card flow. ignore fw scan later defect condition (1k page with 30 zero bit)
    UINT16 Good_Block_Per_Plane;                          // MP block critera
    UINT16 Total_Good_WERU;                               // MP block critera
    UINT32 Replace_Table_Bit_Map;                         // set 1 to replace table.  bit#0: EC, bit#1: FD, bit#2: GD
    int    Max_Grown_Defect_Per_Plane;                    // if set 0, will ignore check
    int    Total_Grown_Defect;                            // if set 0, will ignore check
    int    CE_Count;
    BYTE   Flash_ID[FLASH_ID_LENGTH];
    char   Manual_Mark_Bad_Table_Full_Path_Name[MAX_PATH];
    int    Download_FW_Retry;
    int    Non_Preprogram_Safe_Erase_All_Retry;
    UINT32 Endurance;                                     // SSD life left info

    // using Is_Recv_Drv_Num_By_UI option instead
    /*
    bool   Enable_Named_Pipe;                             // for windows version. need server send new physical drive number when do reboot
    */

    char   Remote_IP[16];                                 // check KeyPro by remote drive mode
    char   Local_Path[16];                                // check KeyPro by local drive mode
    bool   Enable_Check;                                  // cancel check KeyPro. just temp function, because check KeyPro function should always enable !!
    bool   Is_Log_Event_Log;
    bool   Is_Recv_Drv_Num_By_UI;                         // get physical drive number from UI
    BYTE   Nand_Phy_Calibration;                          // bit#0 of 6th byte in the burner binary
                                                          // 0: nand flash run as toggle 2 and only set feature Vref (single end mode)
                                                          // 1: nand flash run as toggle 2 and set featrue Vref, DQS_Bar, RE (differential mode)
    BYTE   Bypass_Preprogram;                             // bit#1 of 6th byte in the burner binary
                                                          // 0: not bypss  1: bypass
    bool   Is_Read_Sorting_Table;
    char   User_FW_Revision[8 + 1];                       // fw revision length of identify device is 8 bytes ata string (pad the string with spece --> 20h)
    bool   Is_Too_Many_Defect_Error_Safe_Erase;
    int    Read_Log_Ext_Mode;
    BYTE   DA_Read;
    BYTE   ADATA_Scan_DF_Mode;                            // 0: normal scan defect  1: only scan original defect and sorting mark mad

} MP_INI_SETTING, *PMP_INI_SETTING;


//-------------------------------------------------------------------------------------------------

typedef struct _FLASH_ID {
	BYTE FlashID[FLASH_ID_LENGTH];
} FLASH_ID, *PFLASH_ID;

typedef struct _CE_ID_INFO {
	FLASH_ID CE[MAX_CE];
} CE_ID_INFO, *PCE_ID_INFO;

typedef struct _CH_ID_INFO {
	CE_ID_INFO CH[MAX_CH];
} CH_ID_INFO, *PCH_ID_INFO;

//-------------------------------------------------------------------------------------------------


#pragma pack()

//-------------------------------------------------------------------------------------------------
#endif