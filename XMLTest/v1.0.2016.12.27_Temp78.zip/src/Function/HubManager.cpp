// HubManager.cpp: implementation of the CHubManager class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "HubManager.h"
#include "usbinfo.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CHubManager::CHubManager()
{
	this->m_dwHubCount = SUPPORT_HUB_COUNT;
}

//---------------------------------------------------------------------------
CHubManager::~CHubManager()
{

}

//---------------------------------------------------------------------------
int CHubManager::Init()
{
	int ret;

    ret = this->ResetHubInfoTable();
    if(ret != 0) {
        return 1;
    }

    ret = this->BuildHubInfoTable();
    if(ret != 0) {
        return 2;
    }

    return 0;
}

//---------------------------------------------------------------------------
int CHubManager::ResetHubInfoTable()
{
    for(int i=0; i<SUPPORT_HUB_COUNT; i++) {
        ::memset(this->m_HubInfoTable[i].HubName, 0, sizeof(this->m_HubInfoTable[i].HubName));
        this->m_HubInfoTable[i].IsRootHub = FALSE;
        this->m_HubInfoTable[i].HubNumber = -1;
        this->m_HubInfoTable[i].PortCount = -1;
		this->m_HubInfoTable[i].IsExist   = FALSE;
    }
    for(int i=0; i<SUPPORT_HUB_COUNT; i++) {//Anjoy
        ::memset(this->m_CurrentHubInfoTable[i].HubName, 0, sizeof(this->m_CurrentHubInfoTable[i].HubName));
        this->m_CurrentHubInfoTable[i].IsRootHub = FALSE;
        this->m_CurrentHubInfoTable[i].HubNumber = -1;
        this->m_CurrentHubInfoTable[i].PortCount = -1;
		this->m_CurrentHubInfoTable[i].IsExist   = FALSE;
    }
    return 0;
}

//---------------------------------------------------------------------------
int CHubManager::BuildHubInfoTable()
{
    TCHAR  aszAllHubNames[SUPPORT_HUB_COUNT][256];
    DWORD  dwHubPortCount;
    int    ret;


    for(int i=0; i<SUPPORT_HUB_COUNT; i++) {
        ::memset(aszAllHubNames[i], 0, sizeof(aszAllHubNames[i]));
    }

    ret = HUB_GetHubNames(aszAllHubNames, &this->m_dwHubCount);
    if(ret != 0) {
		m_dwHubCount = 0;
        return 1;
    }
  
	// arvin 20160620
    this->FilterBusDriver(aszAllHubNames, this->m_dwHubCount);

	if(this->m_dwHubCount >= SUPPORT_HUB_COUNT) {
		return 2;
	}

	// build hub info table (all hubs info of PC)
    for(DWORD i=0; i<this->m_dwHubCount; i++) {
        ::_tcscpy(this->m_HubInfoTable[i].HubName, aszAllHubNames[i]);        
        this->m_HubInfoTable[i].IsRootHub = IsRootHub(this->m_HubInfoTable[i].HubName);
        this->m_HubInfoTable[i].HubNumber = i;
		this->m_HubInfoTable[i].IsExist   = TRUE;

        ret = HUB_GetHubPortCountByHubName(this->m_HubInfoTable[i].HubName, &dwHubPortCount);
        if(ret != 0) {
            return 3;
        }

        this->m_HubInfoTable[i].PortCount = dwHubPortCount;
    }

    return 0;
}

//---------------------------------------------------------------------------
BOOL CHubManager::IsRootHub(IN TCHAR *szHubName)
{
    if(::_tcsstr(szHubName, _T("root_hub"))) {
        return TRUE;
    }
    else {
        return FALSE;
    }
}

//---------------------------------------------------------------------------
BOOL CHubManager::IsExt4PortHub(IN TCHAR *szHubName)
{
	DWORD  dwHubPortCount;
	int    ret;

	
	if(::_tcslen(szHubName) <= 0) {
		return FALSE;
	}

	ret = HUB_GetHubPortCountByHubName(szHubName, &dwHubPortCount);
	if(ret != 0) {
		return FALSE;
	}

	if(::_tcsstr(szHubName, _T("root_hub")) || dwHubPortCount != 4) {
        return FALSE;
    }

	return TRUE;
}

//---------------------------------------------------------------------------
int CHubManager::IsExt7PortHub(IN TCHAR *szHubName)
{
	DWORD  dwHubPortCount;
	int    ret;


	if(::_tcslen(szHubName) <= 0) {
		return FALSE;
	}

	ret = HUB_GetHubPortCountByHubName(szHubName, &dwHubPortCount);
	if(ret != 0) {
		return FALSE;
	}

	if(::_tcsstr(szHubName, _T("root_hub")) || dwHubPortCount != 7) {
        return FALSE;
    }

	return TRUE;
}

//---------------------------------------------------------------------------
int CHubManager::GetHubInfoTable(OUT HUB_INFO_TABLE *HubInfoTable)
{
    for(int i=0; i<SUPPORT_HUB_COUNT; i++) {
        ::_tcscpy(HubInfoTable[i].HubName, this->m_HubInfoTable[i].HubName);
        HubInfoTable[i].IsRootHub = this->m_HubInfoTable[i].IsRootHub;
        HubInfoTable[i].HubNumber = this->m_HubInfoTable[i].HubNumber;
        HubInfoTable[i].PortCount = this->m_HubInfoTable[i].PortCount;
		HubInfoTable[i].IsExist   = this->m_HubInfoTable[i].IsExist;
    }

    return 0;
}
//---------------------------------------------------------------------------
int CHubManager::GetCurrentHubInfoTable(OUT HUB_INFO_TABLE *HubInfoTable)//Anjoy_1001_T1
{
    for(int i=0; i<SUPPORT_HUB_COUNT; i++) {
        ::_tcscpy(HubInfoTable[i].HubName, this->m_CurrentHubInfoTable[i].HubName);
        HubInfoTable[i].IsRootHub = this->m_CurrentHubInfoTable[i].IsRootHub;
        HubInfoTable[i].HubNumber = this->m_CurrentHubInfoTable[i].HubNumber;
        HubInfoTable[i].PortCount = this->m_CurrentHubInfoTable[i].PortCount;
		HubInfoTable[i].IsExist   = this->m_CurrentHubInfoTable[i].IsExist;
    }

    return 0;
}
//---------------------------------------------------------------------------
int CHubManager::GetExt4PortHubInfoTable(OUT HUB_INFO_TABLE *pExt4PortHubInfoTable, OUT DWORD *pdwHubCount)
{
	DWORD  dwCount;
	DWORD  dwIndex;


	dwCount = 0;
	dwIndex = 0;

	for(int i=0; i<SUPPORT_HUB_COUNT; i++) {

		// filter
		if((this->m_HubInfoTable[i].IsRootHub == TRUE) || (this->m_HubInfoTable[i].PortCount != 4)) {
			continue;
		}
		
		::_tcscpy(pExt4PortHubInfoTable[dwIndex].HubName, this->m_HubInfoTable[i].HubName);
        pExt4PortHubInfoTable[dwIndex].IsRootHub = this->m_HubInfoTable[i].IsRootHub;
        pExt4PortHubInfoTable[dwIndex].HubNumber = this->m_HubInfoTable[i].HubNumber;
        pExt4PortHubInfoTable[dwIndex].PortCount = this->m_HubInfoTable[i].PortCount;
		pExt4PortHubInfoTable[dwIndex].IsExist   = this->m_HubInfoTable[i].IsExist;

		dwCount++;
		dwIndex++;
	}

	*pdwHubCount = dwCount;

	return 0;
}

//---------------------------------------------------------------------------
int CHubManager::GetExt7PortHubInfoTable(OUT HUB_INFO_TABLE *pExt7PortHubInfoTable, OUT DWORD *pdwHubCount)
{
	DWORD  dwCount;
	DWORD  dwIndex;


	dwCount = 0;
	dwIndex = 0;

	for(int i=0; i<SUPPORT_HUB_COUNT; i++) {

		// filter
		if((this->m_HubInfoTable[i].IsRootHub == TRUE) || (this->m_HubInfoTable[i].PortCount != 7)) {
			continue;
		}
		
		::_tcscpy(pExt7PortHubInfoTable[dwIndex].HubName, this->m_HubInfoTable[i].HubName);
        pExt7PortHubInfoTable[dwIndex].IsRootHub = this->m_HubInfoTable[i].IsRootHub;
        pExt7PortHubInfoTable[dwIndex].HubNumber = this->m_HubInfoTable[i].HubNumber;
        pExt7PortHubInfoTable[dwIndex].PortCount = this->m_HubInfoTable[i].PortCount;
		pExt7PortHubInfoTable[dwIndex].IsExist   = this->m_HubInfoTable[i].IsExist;

		dwCount++;
		dwIndex++;
	}

	*pdwHubCount = dwCount;

	return 0;
}
//---------------------------------------------------------------------------
int CHubManager::GetAllHubCount()
{	
	return this->m_dwHubCount;
}

//---------------------------------------------------------------------------
int CHubManager::GetExt4PortHubCount()
{
	int nExt4PortHubCount;


	nExt4PortHubCount = 0;

	for(int i=0; i<SUPPORT_HUB_COUNT; i++) {
		if(this->m_HubInfoTable[i].IsRootHub == FALSE && this->m_HubInfoTable[i].PortCount == 4) {
			nExt4PortHubCount++;
		}
	}

	return nExt4PortHubCount;
}

//---------------------------------------------------------------------------
int CHubManager::GetExt7PortHubCount()
{
	int nExt7PortHubCount;


	nExt7PortHubCount = 0;

	for(int i=0; i<SUPPORT_HUB_COUNT; i++) {
		if(this->m_HubInfoTable[i].IsRootHub == FALSE && this->m_HubInfoTable[i].PortCount == 7) {
			nExt7PortHubCount++;
		}
	}

	return nExt7PortHubCount;
}

//---------------------------------------------------------------------------
int CHubManager::AddHubInfo(IN TCHAR *szHubName)
{
	DWORD  dwHubPortCount;
	BOOL   bIsRootHub;
	int    i;  // for loop index
	int    ret;


	// check is over max support hub count
	if((this->m_dwHubCount+1) > SUPPORT_HUB_COUNT) {
		return 1;
	}

	ret = HUB_GetHubPortCountByHubName(szHubName, &dwHubPortCount);
	if(ret != 0) {
		return 2;
	}

	bIsRootHub = this->IsRootHub(szHubName);

	if(bIsRootHub == FALSE) {
		if(dwHubPortCount == 4) {
			if((this->GetExt4PortHubCount() + 1) > SUPPORT_4PORT_HUB_COUNT) {
				return 3;
			}
		}
		else {
			if((this->GetExt7PortHubCount() + 1 ) > SUPPORT_7PORT_HUB_COUNT) {
				return 4;
			}
		}
	}
	
	// search empty space of hub info table to save
	for(i=0; i<SUPPORT_HUB_COUNT; i++) {
		if(this->m_HubInfoTable[i].IsExist == TRUE) {
			continue;
		}		

		::_tcscpy(this->m_HubInfoTable[i].HubName, szHubName);
		this->m_HubInfoTable[i].IsRootHub = IsRootHub(szHubName);
		this->m_HubInfoTable[i].HubNumber = i;
		this->m_HubInfoTable[i].IsExist   = TRUE;				
		this->m_HubInfoTable[i].PortCount = dwHubPortCount;

		this->m_dwHubCount++;
		break;
	}	

	return 0;
}

//---------------------------------------------------------------------------
int CHubManager::RemoveHubInfo(IN TCHAR *szHubName)
{
	this->m_dwHubCount--;

	// remove hub info from hub info table
	for(int i=0; i<SUPPORT_HUB_COUNT; i++) {

		if(::_tcsicmp(this->m_HubInfoTable[i].HubName, szHubName) == 0) {
			::memset(this->m_HubInfoTable[i].HubName, 0, sizeof(this->m_HubInfoTable[i].HubName));
			this->m_HubInfoTable[i].IsRootHub = FALSE;
			this->m_HubInfoTable[i].HubNumber = -1;
			this->m_HubInfoTable[i].PortCount = -1;
			this->m_HubInfoTable[i].IsExist   = FALSE;
		}

		if(::_tcsicmp(this->m_CurrentHubInfoTable[i].HubName, szHubName) == 0) {//Anjoy_1001_T1
			::memset(this->m_CurrentHubInfoTable[i].HubName, 0, sizeof(this->m_CurrentHubInfoTable[i].HubName));
			this->m_CurrentHubInfoTable[i].IsRootHub = FALSE;
			this->m_CurrentHubInfoTable[i].HubNumber = -1;
			this->m_CurrentHubInfoTable[i].PortCount = -1;
			this->m_CurrentHubInfoTable[i].IsExist   = FALSE;
		}

	}

	return 0;
}

//---------------------------------------------------------------------------
int CHubManager::GetHubIndex(IN TCHAR *pszHubName, OUT DWORD *pdwIndex)
{
	BOOL bIsFind;


	bIsFind = FALSE;
	for(int i=0; i<SUPPORT_HUB_COUNT; i++) {

		//if(::_tcscmp(this->m_HubInfoTable[i].HubName, pszHubName) == 0) {
		if(::_tcsicmp(this->m_HubInfoTable[i].HubName, pszHubName) == 0) {

			*pdwIndex = m_HubInfoTable[i].HubNumber;
			bIsFind = TRUE;
			break;			
		}
	}

	if(!bIsFind) {
		return 1;
	}

	return 0;
}

//---------------------------------------------------------------------------
// some of the notebook have simulated hub device built by bus drive
// the funciton filter out the hub name included bus_driver  
// arvin 20160620
void CHubManager::FilterBusDriver(TCHAR aszHubName[][256], DWORD &dwHubCount)
{
    int idx=0;
	DWORD dwFilterCount=0;
    TCHAR aszTempHubName[SUPPORT_HUB_COUNT][256] = { 0 };
   	  
    for(DWORD i=0; i<dwHubCount; i++) {
        if(::_tcsstr(aszHubName[i], _T("bus_driver")) != NULL) {
	       dwFilterCount++;
		   continue;
        }
		::_tcscpy(aszTempHubName[idx], aszHubName[i]);
		idx++;
	}
	dwHubCount-=dwFilterCount;
     	 
    for(DWORD i=0; i<dwHubCount; i++) {
		::_tcscpy(aszHubName[i], aszTempHubName[i]);
	}
    for(DWORD i=dwHubCount; i<SUPPORT_HUB_COUNT; i++) {
		::memset(aszHubName[i], 0, sizeof(aszHubName[i]));
    }
}
