// HubManager.h: interface for the CHubManager class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HUBMANAGER_H__2091B33E_5C77_4E0F_8451_2C17B39E1642__INCLUDED_)
#define AFX_HUBMANAGER_H__2091B33E_5C77_4E0F_8451_2C17B39E1642__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//===============================================================
//             User define for the flaw of compiler 
//===============================================================
#define for if(0); else for


const int SUPPORT_HUB_COUNT = 32;       // max support hub count
const int SUPPORT_4PORT_HUB_COUNT = 4;  // max support 4-port hub count
const int SUPPORT_7PORT_HUB_COUNT = 2;  // max support 7-port hub count
//const int SUPPORT_LUN_COUNT = 4;   // max support LUN count
//const int MAX_EXT_PORT_NUM  = 7;   // for HubInfoTable


#pragma pack(1)


typedef struct _HUB_INFO_TABLE {
    TCHAR  HubName[256];
    BOOL   IsRootHub;
    DWORD  HubNumber;  // number of index
    int    PortCount;  // the port count of a hub 
	BOOL   IsExist;    // convenient for some condition use
} HUB_INFO_TABLE, *PHUB_INFO_TABLE;

#pragma pack()

//---------------------------------------------------------------------------
class CHubManager  
{
public:
	void FilterBusDriver(TCHAR aszHubName[][256], DWORD &dwHubCount);
	CHubManager();
	virtual ~CHubManager();

	// init object
	int   Init();  // when create CHubManager object, we need to call Init() ourself first

	// query info
    int   GetHubInfoTable(OUT HUB_INFO_TABLE *HubInfoTable);
	int   GetExt4PortHubInfoTable(OUT HUB_INFO_TABLE *pExt4PortHubInfoTable, OUT DWORD *pdwHubCount);
	int   GetExt7PortHubInfoTable(OUT HUB_INFO_TABLE *pExt7PortHubInfoTable, OUT DWORD *pdwHubCount);
    int   GetAllHubCount();
	int   GetExt4PortHubCount();
	int   GetExt7PortHubCount();
    BOOL  IsRootHub(IN TCHAR *szHubName);
	BOOL  IsExt4PortHub(IN TCHAR *szHubName);
	BOOL  IsExt7PortHub(IN TCHAR *szHubName);
	int   GetHubIndex(IN TCHAR *pszHubName, OUT DWORD *pdwIndex);

	// maintain hub info table function
	int   AddHubInfo(IN TCHAR *szHubName);     // add hub info to hub info table
	int   RemoveHubInfo(IN TCHAR *szHubName);  // remove hub info from hub info table
	int   GetCurrentHubInfoTable(OUT HUB_INFO_TABLE *HubInfoTable);//Anjoy_1001_T1

	HUB_INFO_TABLE  m_CurrentHubInfoTable[SUPPORT_HUB_COUNT];  // current hub info table //Anjoy_1001_T1

private:
    HUB_INFO_TABLE  m_HubInfoTable[SUPPORT_HUB_COUNT];  // hub info table

    DWORD  m_dwHubCount;

	// for init use
    int    BuildHubInfoTable();  
    int    ResetHubInfoTable();

};

#endif // !defined(AFX_HUBMANAGER_H__2091B33E_5C77_4E0F_8451_2C17B39E1642__INCLUDED_)
