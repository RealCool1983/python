// LogManager.cpp: implementation of the CLogManager class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SSDMP.h"
#include "LogManager.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CLogManager::CLogManager()
{
    this->InitMember();
    ::InitializeCriticalSection(&this->m_CriticalSection);
}

//-------------------------------------------------------------------------------------------------
CLogManager::~CLogManager()
{
    ::DeleteCriticalSection(&this->m_CriticalSection);
}

//-------------------------------------------------------------------------------------------------
int CLogManager::Init(IN TCHAR *pLogFullPath, IN TCHAR *pOpenMode)
{
    int  Rslt;
    
    
    this->InitMember();
    
    TCHAR  Drive[_MAX_DRIVE]    = {0};
    TCHAR  Path[_MAX_PATH]      = {0};
    TCHAR  FileName[_MAX_FNAME] = {0};
    TCHAR  ExtName[8]           = {0};
    
    ::_tsplitpath(pLogFullPath, Drive, Path, FileName, ExtName);
        
	::_tcsncpy(this->m_LogFullPath, pLogFullPath, MAX_PATH);
    ::_tcsncpy(this->m_LogPath, Path, MAX_PATH);
    ::_stprintf(this->m_LogName, "%s%s", FileName, ExtName);
    ::_tcsncpy(this->m_OpenMode, pOpenMode, 8);
    
    Rslt = this->m_FileManager.BuildDirectory(this->m_LogPath);
    if (Rslt != 0) {
        return 1;
    }
    
    this->m_InitSucceed = true;
    
    return 0;
}

//-------------------------------------------------------------------------------------------------
void CLogManager::InitMember()
{
    ::memset(this->m_LogFullPath, 0, sizeof(this->m_LogFullPath));
    ::memset(this->m_LogPath, 0, sizeof(this->m_LogPath));
    ::memset(this->m_LogName, 0, sizeof(this->m_LogName));
    ::memset(this->m_OpenMode, 0, sizeof(this->m_OpenMode));
    this->m_InitSucceed = false;
    
    return;
}

//-------------------------------------------------------------------------------------------------
void CLogManager::DebugMsg(IN TCHAR *pFormat, ...)
{

#ifdef _DEBUG
	
	::EnterCriticalSection(&this->m_CriticalSection);		

    CString Msg;
    
    
	va_list	arg;
	va_start(arg, pFormat);
	Msg.FormatV(pFormat, arg);

	::OutputDebugString(Msg);

	::LeaveCriticalSection(&this->m_CriticalSection);

#endif

    return;
}

//-------------------------------------------------------------------------------------------------
void CLogManager::LogToFile(IN bool IsRecordTime, IN bool IsWithNewLine, IN TCHAR *pFormat, ...)
{
    ::EnterCriticalSection(&this->m_CriticalSection);
    
    FILE     *pFile;
    CTime    TimeInfo;
    CString  Msg;
    

    if (this->m_InitSucceed == false) {
        ::LeaveCriticalSection(&this->m_CriticalSection);
        return;
    }

    pFile = ::_tfopen(this->m_LogFullPath, this->m_OpenMode);
    if (pFile == NULL) {
        ::LeaveCriticalSection(&this->m_CriticalSection);
        return;
    }	
    

#if defined(_UNICODE) || defined(UNICODE)
    BYTE UnicodeHeader[2] = {0xff, 0xfe};  // Unicode header = 0xfeff
    ::fwrite(UnicodeHeader, 2, 1, pFile);
#endif
    
    // write the time out
    if (IsRecordTime == TRUE) {
        TimeInfo = CTime::GetCurrentTime();		
        Msg = TimeInfo.Format(_T("[%Y/%m/%d %H:%M:%S] "));
        ::_ftprintf(pFile, _T("%s"), Msg);
    }

    // format and write the data
    va_list	arg;
    va_start(arg, pFormat);
    Msg.FormatV(pFormat, arg);	
    
	if (IsWithNewLine == true) {
		::_ftprintf(pFile, _T("%s\n"), Msg);
	}
	else {
		::_ftprintf(pFile, _T("%s"), Msg);
	}

    // release resource
    ::fflush(pFile);
    ::fclose(pFile);
    

    ::LeaveCriticalSection(&this->m_CriticalSection);
	
    return;
}

//-------------------------------------------------------------------------------------------------
TCHAR *CLogManager::GetLogFullPath()
{
    return (this->m_InitSucceed == false) ? NULL : this->m_LogFullPath;
}

//-------------------------------------------------------------------------------------------------
TCHAR *CLogManager::GetLogPath()
{
    return (this->m_InitSucceed == false) ? NULL : this->m_LogPath;
}

//-------------------------------------------------------------------------------------------------
TCHAR *CLogManager::GetLogName()
{
    return (this->m_InitSucceed == false) ? NULL : this->m_LogName;
}

//-------------------------------------------------------------------------------------------------
bool CLogManager::IsInitSucceed()
{
    return (this->m_InitSucceed == false) ? NULL : this->m_InitSucceed;
}

//-------------------------------------------------------------------------------------------------









