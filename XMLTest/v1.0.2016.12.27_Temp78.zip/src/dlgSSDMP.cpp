// dlgSSDMP.cpp : implementation file
//

#include "stdafx.h"
#include "SSDMP.h"
#include "dlgSSDMP.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//-------------------------------------------------------------------------------------------------
// tab control page index
#define MP_TAB_PAGE           (0)
#define ENVIRONMENT_TAB_PAGE  (1)
#define FTB_TAB_PAGE          (2)
#define RDT_RSLT_PAGE         (3)

//-------------------------------------------------------------------------------------------------
BYTE g_KeyProDLL[] = {
#include ".\KeyProDLL\KeyProGen.HEX"
};

BYTE g_PublicKey[] = {
#include ".\KeyProDLL\MyKey1_Golden_public.HEX"
};

BYTE g_MP[] = {
#include ".\MP\3S_SSD_MP.HEX"
};


// global variable
bool              g_IsStartRun;
bool              g_IsKeyProDrvRemoved;
int               g_TaskCount;
int               g_KeyProCount;
int               g_NeedKeyCount;                // temp counter record need key pro count this run
CRITICAL_SECTION  g_csTaskCount;                 // for DetectTerminateThread to protect g_TaskCount
CRITICAL_SECTION  g_csNeedKeyCount;              // for DetectTerminateThread to protect g_TaskCount
HANDLE            g_hEvent[SUPPORT_PORT_COUNT];  // for wait remount device during task
CSNManager        g_SNManager;


// thread function
UINT   __stdcall  MPTask(IN LPVOID pParam);
int    __stdcall  PollingMPStatus(IN PORT_DATA *pPortData, IN PROCESS_INFORMATION *pProcessInfo, IN ANONYMOUS_PIPE_INFO *pPipeInfo);
int    __stdcall  RebootToFwModeToGetCapacity(IN PORT_DATA *pPortData);
HANDLE __stdcall  GetDriveHandle(IN int PhyDrvNum);
int    __stdcall  ReleaseTaskResource(IN PROCESS_INFORMATION *pi, ANONYMOUS_PIPE_INFO *pPipeInfo);
int    __stdcall  ParseString(IN char *pInputString, OUT char *pBuffer, IN int BufferSize);
void   __stdcall  DetectTerminateThread(IN PORT_DATA *pPortData);
void   __stdcall  GetKeyProStatus(IN bool IsReduceKey, OUT int *pStatus);
int    __stdcall  InitPortDataLogManager(IN PORT_DATA *pPortData);


//-------------------------------------------------------------------------------------------------
UINT __stdcall MPTask(IN LPVOID pParam)
{
    ANONYMOUS_PIPE_INFO  PipeInfo;  // pipe for child process stdin / stdout
    PORT_DATA  *pPortData;
    char       CommandLine[1024];
    int        Rslt;
	
    
    pPortData = (PORT_DATA*)pParam;
    

    ::ResetEvent(g_hEvent[pPortData->MapIndex]);
    
	//====================================================================
	//                     init log manager
	//====================================================================
    Rslt = InitPortDataLogManager(pPortData);
	if (Rslt != 0) {
		DetectTerminateThread(pPortData);
        return 1;
	}


	//====================================================================
	//                   check key pro count
	//====================================================================
    GetKeyProStatus(pPortData->IsReduceKey, &pPortData->KeyProStatus);
    
    if (pPortData->KeyProStatus == OUT_OF_KEY) {
        pPortData->ErrorCode = ERR_OUT_OF_KEY;
        DetectTerminateThread(pPortData);
        return 1;
    }
    
    
	//====================================================================
	//                   generate serial number
	//====================================================================
    pPortData->LogManager.DebugMsg("generate sn ...");
    pPortData->LogManager.LogToFile(true, true, "generate sn ...");
    
	::memset(pPortData->MPParam.SN, 0, sizeof(pPortData->MPParam.SN));
    
	Rslt = g_SNManager.GenerateSN(pPortData->MPParam.SN);
	if (Rslt != 0) {
        pPortData->LogManager.DebugMsg("generate sn fail");
        pPortData->LogManager.LogToFile(true, true, "generate sn fail");
        
        pPortData->ErrorCode = ERR_GENERATE_SN;
		DetectTerminateThread(pPortData);
		return 1;
	}
    pPortData->LogManager.DebugMsg("generate sn = %s", pPortData->MPParam.SN);
    pPortData->LogManager.LogToFile(true, true, "generate sn = %s", pPortData->MPParam.SN);
    

	//====================================================================
	//               prepare command line parameter
	//====================================================================
    CFileManager  FileManager;
    char          LogPath[MAX_PATH] = {0};
    
    
    Rslt = FileManager.GetCurrentExeFilePath(LogPath, sizeof(LogPath));
    if (Rslt != 0) {
        pPortData->ErrorCode = ERR_GET_PATH_FOR_COMMAND_LINE;
		DetectTerminateThread(pPortData);
		return 1;
    }
    
    ::memset(pPortData->MPParam.LogFullPath, 0, sizeof(pPortData->MPParam.LogFullPath));
    ::sprintf(pPortData->MPParam.LogFullPath, "%sLog\\%s.txt", LogPath, pPortData->MPParam.SN);
    
	::memset(CommandLine, 0, sizeof(CommandLine));
    ::sprintf(CommandLine, "%s -Function %s -DriveNumber %d -INI %s -WO %s -FW %s -SN %s -Log %s -WWN %s", pPortData->MPExeFullPath,
		                                                                                                   pPortData->MPParam.Task,
                                                                                                           pPortData->PhyDrvNum,
                                                                                                           pPortData->MPParam.ConfigFullPath,
                                                                                                           pPortData->MPParam.WO,
                                                                                                           pPortData->MPParam.FWFullPath,
                                                                                                           pPortData->MPParam.SN,
                                                                                                           pPortData->MPParam.LogFullPath,
                                                                                                           "");
    pPortData->LogManager.DebugMsg("task = %s", pPortData->MPParam.Task);
    pPortData->LogManager.LogToFile(true, true, "task = %s", pPortData->MPParam.Task);
    
    pPortData->LogManager.DebugMsg("phy drv number = %d", pPortData->PhyDrvNum);
    pPortData->LogManager.LogToFile(true, true, "phy drv number = %d", pPortData->PhyDrvNum);
    
    pPortData->LogManager.DebugMsg("mp ini full path = %s", pPortData->MPParam.ConfigFullPath);
    pPortData->LogManager.LogToFile(true, true, "mp ini full path = %s", pPortData->MPParam.ConfigFullPath);
    
    pPortData->LogManager.DebugMsg("firmware full path = %s", pPortData->MPParam.FWFullPath);
    pPortData->LogManager.LogToFile(true, true, "firmware full path = %s", pPortData->MPParam.FWFullPath);
    
    pPortData->LogManager.DebugMsg("log full path = %s", pPortData->MPParam.LogFullPath);
    pPortData->LogManager.LogToFile(true, true, "log full path = %s", pPortData->MPParam.LogFullPath);
    

    //====================================================================
	//      create anonymous pipe to communicate with child process
	//====================================================================
    SECURITY_ATTRIBUTES  sa;
    
    
    ZeroMemory(&sa, sizeof(sa));
    
    sa.nLength              = sizeof(sa);
	sa.lpSecurityDescriptor = NULL;
    sa.bInheritHandle       = true;
	
    // for child process stdout
    Rslt = ::CreatePipe(&PipeInfo.Stdout.hRead, &PipeInfo.Stdout.hWrite, &sa, 0);
	if (Rslt == 0) {
        pPortData->ErrorCode = ERR_CREATE_STDOUT_PIPE;
        DetectTerminateThread(pPortData);
		return 1;
	}

    // for child process stdin
    Rslt = ::CreatePipe(&PipeInfo.Stdin.hRead, &PipeInfo.Stdin.hWrite, &sa, 0);
	if (Rslt == 0) {
        pPortData->ErrorCode = ERR_CREATE_STDIN_PIPE;
		DetectTerminateThread(pPortData);
		return 1;
	}
	
	
    //====================================================================
	//                     create process
	//====================================================================
	PROCESS_INFORMATION pi;
	STARTUPINFO si;
    
    
    ZeroMemory(&pi, sizeof(pi));
	ZeroMemory(&si, sizeof(si));
	
	si.cb          = sizeof(STARTUPINFO);
	si.dwFlags     = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
	si.wShowWindow = SW_HIDE;
    si.hStdInput   = PipeInfo.Stdin.hRead;    // child process stdin
	si.hStdOutput  = PipeInfo.Stdout.hWrite;  // child process stdout
	si.hStdError   = PipeInfo.Stdout.hWrite;  // child process stderr
    
    Rslt = ::CreateProcess(NULL, CommandLine, NULL, NULL, true, 0, NULL, NULL, &si, &pi);
	if (Rslt == 0) {
        pPortData->ErrorCode = ERR_CREATE_PROCESS;
		DetectTerminateThread(pPortData);
		return 1;
	}
	
    
    //====================================================================
	//                      polling MP status
	//====================================================================
    Rslt = PollingMPStatus(pPortData, &pi, &PipeInfo);
    if (Rslt != 0) {
        ReleaseTaskResource(&pi, &PipeInfo);
        DetectTerminateThread(pPortData);
        return 1;
    }
    
	/*
	if (pPortData->ErrorCode == MP_NO_ERROR) {
		pPortData->NandInfoManager.Init(pPortData->PhyDrvNum, NULL);
	}
	*/
    

    //====================================================================
	//        reboot to fw mode to get identify device info
	//====================================================================
    // only for FTB flow with no error case
    if (::strcmp(pPortData->MPParam.Task, FTB_TASK) == 0) {
        Rslt = RebootToFwModeToGetCapacity(pPortData);
        if (Rslt != 0) {
            ReleaseTaskResource(&pi, &PipeInfo);
			DetectTerminateThread(pPortData);
			return 1;
        }
    }
    
    
    // release resource
	ReleaseTaskResource(&pi, &PipeInfo);
    
    DetectTerminateThread(pPortData);
    
    return 0;
}

//-------------------------------------------------------------------------------------------------
int __stdcall PollingMPStatus(IN PORT_DATA *pPortData, IN PROCESS_INFORMATION *pProcessInfo, IN ANONYMOUS_PIPE_INFO *pPipeInfo)
{
    char   ReadBuffer[256];
    char   Temp[256];
    DWORD  WaitRslt;
    DWORD  ReadBytes;
    DWORD  WrittenBytes;
    int    Progress;
    int    Rslt;
    
    
    pPortData->LogManager.DebugMsg("mp status");
    pPortData->LogManager.LogToFile(true, true, "mp status");
        
    while (1) {
		::memset(ReadBuffer, 0, sizeof(ReadBuffer));
		::ReadFile(pPipeInfo->Stdout.hRead, ReadBuffer, sizeof(ReadBuffer) - 1, &ReadBytes, NULL);
        
        pPortData->LogManager.DebugMsg("%s", ReadBuffer);
        pPortData->LogManager.LogToFile(false, false, "%s", ReadBuffer);
        
        if (g_IsKeyProDrvRemoved == true) {
            ::TerminateProcess(pProcessInfo->hProcess, 1);
            pPortData->ErrorCode = ERR_KEY_PRO_DRIVE_REMOVED;
			pPortData->LogManager.DebugMsg("key pro has been removed");
			pPortData->LogManager.LogToFile(true, true, "key pro has been removed");
            return 1;
        }
        
        if (::strstr(ReadBuffer, RECV_PROGRESS) != NULL) {  // MP is working
            ::memset(Temp, 0, sizeof(Temp));
            Rslt = ParseString(ReadBuffer, Temp, sizeof(Temp));
            if (Rslt != 0) {
                pPortData->ErrorCode = ERR_PARSE_RECV_STRING;
				pPortData->LogManager.DebugMsg("RECV_PROGRESS --> parse string fail");
			    pPortData->LogManager.LogToFile(true, true, "RECV_PROGRESS --> parse string fail");
                return 1;
            }
            
            Progress = ::atoi(Temp);
			::PostMessage(AfxGetMainWnd()->m_hWnd, WM_UPDATE_PROGRESS, pPortData->MapIndex, Progress);
		}
        else if (::strstr(ReadBuffer, RECV_REBOOT_TO_ROM)) {  // MP is ready to reboot to rom safe mode
            ::ResetEvent(g_hEvent[pPortData->MapIndex]);
            
            pPortData->LogManager.DebugMsg("recv reboot to rom msg", ReadBuffer);
            pPortData->LogManager.LogToFile(false, true, "recv reboot to rom msg", ReadBuffer);
        }
		else if (::strstr(ReadBuffer, RECV_WAIT_NEW_DRV_NUM) != NULL) {  // MP is waiting for new physical drive number

			pPortData->LogManager.DebugMsg("wait for device insert");
            pPortData->LogManager.LogToFile(true, true, "wait for device insert");

            WaitRslt = ::WaitForSingleObject(g_hEvent[pPortData->MapIndex], WAIT_REBOOT_TIME_OUT);
            if (WaitRslt != WAIT_OBJECT_0) {
                pPortData->ErrorCode = ERR_WAIT_DEV_REMOUNT_TIME_OUT;
				pPortData->LogManager.DebugMsg("wait for device insert time out");
				pPortData->LogManager.LogToFile(true, true, "wait for device insert time out");
                return 1;
            }
            
            // to avoid miss receive RECV_REBOOT_TO_ROM case
            ::ResetEvent(g_hEvent[pPortData->MapIndex]);
			
            
			::memset(Temp, 0, sizeof(Temp));
            ::sprintf(Temp, "%d\n", pPortData->PhyDrvNum);
            
            pPortData->LogManager.DebugMsg("send new phy drv num = %d", pPortData->PhyDrvNum);
            pPortData->LogManager.LogToFile(false, true, "send new phy drv num = %d", pPortData->PhyDrvNum);
            
			Rslt = ::WriteFile(pPipeInfo->Stdin.hWrite, Temp, strlen(Temp), &WrittenBytes, NULL);
            if (Rslt == 0) {
                pPortData->ErrorCode = ERR_WRITE_DATA_TO_PIPE;
				pPortData->LogManager.DebugMsg("write phy drv num to pipe fail. sys err = %d", ::GetLastError());
				pPortData->LogManager.LogToFile(true, true, "write phy drv num to pipe fail. sys err = %d", ::GetLastError());
                return 1;
            }
		}
        else if (::strstr(ReadBuffer, RECV_ERR_CODE)) {  // MP done (fail case)

			// avoid sometimes child process's print is without flush
			char *pStart = ::strstr(ReadBuffer, RECV_ERR_CODE);

            ::memset(Temp, 0, sizeof(Temp));
            Rslt = ParseString(pStart, Temp, sizeof(Temp));
            if (Rslt != 0) {
                pPortData->ErrorCode = ERR_PARSE_RECV_STRING;
				pPortData->LogManager.DebugMsg("RECV_ERR_CODE --> parse string fail");
			    pPortData->LogManager.LogToFile(true, true, "RECV_ERR_CODE --> parse string fail");
                return 1;
            }
            
            pPortData->ErrorCode = ::atoi(Temp);
            return 1;
        }
        else if (::strstr(ReadBuffer, RECV_TEST_RSLT)) {  // MP done (pass case)
            ::memset(Temp, 0, sizeof(Temp));
            Rslt = ParseString(ReadBuffer, Temp, sizeof(Temp));
            if (Rslt != 0) {
                pPortData->ErrorCode = ERR_PARSE_RECV_STRING;
				pPortData->LogManager.DebugMsg("RECV_TEST_RSLT --> parse string fail");
			    pPortData->LogManager.LogToFile(true, true, "RECV_TEST_RSLT --> parse string fail");
                return 1;
            }
            
            if (::stricmp(Temp, RECV_TEST_PASS) == 0) {
                pPortData->ErrorCode = MP_NO_ERROR;
				pPortData->LogManager.DebugMsg("mp pass");
				pPortData->LogManager.LogToFile(true, true, "mp pass");
                break;
            }
        }
	}
    
    return 0;
}

//-------------------------------------------------------------------------------------------------
int __stdcall RebootToFwModeToGetCapacity(IN PORT_DATA *pPortData)
{
	char    Temp[64];
    HANDLE  hDevice;
	/*
	DWORD   WaitRslt;
	*/
    int     Rslt;
    
    
    hDevice = GetDriveHandle(pPortData->PhyDrvNum);
    if (hDevice == INVALID_HANDLE_VALUE) {
        pPortData->LogManager.DebugMsg("reboot to fw. get device handle fail. phy drv num = %d", pPortData->PhyDrvNum);
        pPortData->LogManager.LogToFile(true, true, "reboot to fw. get device handle fail. phy drv num = %d", pPortData->PhyDrvNum);
        pPortData->ErrorCode = ERR_GET_DEV_HANLDE;
        return 1;
    }
	
    Rslt = SSD_CMD_Reboot_To_FW(-1, hDevice);
    if (Rslt != 0) {
        pPortData->LogManager.DebugMsg("reboot to fw command fail. sys err = %d", ::GetLastError());
        pPortData->LogManager.LogToFile(true, true, "reboot to fw command fail. sys err = %d", ::GetLastError());
        pPortData->ErrorCode = ERR_CMD_REBOOT_TO_FW;
        ::CloseHandle(hDevice);
        hDevice = INVALID_HANDLE_VALUE;
        return 1;
    }
    
    ::CloseHandle(hDevice);
    hDevice = INVALID_HANDLE_VALUE;
    
    //
    // use while loop re-open device and set time out method
    //
    

    //
    // send reboot to fw command. there are two situation (maybe caused by driver)
	// < situation 1 > some PC will not send device change message.
	// < situation 2 > some PC will send device change message.
    // so we try the common solution to solve them --> during task remove / insert drive do reset / set event
	//
    /*
	pPortData->LogManager.DebugMsg("reboot to fw. wait for device insert");
	pPortData->LogManager.LogToFile(false, true, "reboot to fw. wait for device insert");
	
	WaitRslt = ::WaitForSingleObject(g_hEvent[pPortData->MapIndex], WAIT_REBOOT_TIME_OUT);
	if (WaitRslt != WAIT_OBJECT_0) {
		pPortData->ErrorCode = ERR_WAIT_DEV_REMOUNT_TIME_OUT;
		return 1;
	}
	
	::memset(Temp, 0, sizeof(Temp));
	::sprintf(Temp, "%d\n", pPortData->PhyDrvNum);
	
	pPortData->LogManager.DebugMsg("send new phy drv num = %d", pPortData->PhyDrvNum);
	pPortData->LogManager.LogToFile(false, true, "send new phy drv num = %d", pPortData->PhyDrvNum);
    */
	
    // delay 2 second to re-open device
    bool  IsOpenSucceed = false;
    ::Sleep(2000);

    for (int i = 0; i < 30; i++) {
        hDevice = GetDriveHandle(pPortData->PhyDrvNum);
        if (hDevice == INVALID_HANDLE_VALUE) {
            pPortData->LogManager.DebugMsg("reboot to fw. re-get device handle fail. re-try = %d. phy drv num = %d", i, pPortData->PhyDrvNum);
            pPortData->LogManager.LogToFile(true, true, "reboot to fw. re-get device handle fail. re-try = %d. phy drv num = %d", i, pPortData->PhyDrvNum);
            ::Sleep(1000);
            continue;
        }
        IsOpenSucceed = true;
        break;
    }
    
    if (IsOpenSucceed == false) {
        pPortData->LogManager.DebugMsg("re-get device handle fail time out. phy drv num = %d", pPortData->PhyDrvNum);
        pPortData->LogManager.LogToFile(true, true, "re-get device handle fail time out. phy drv num = %d", pPortData->PhyDrvNum);
        pPortData->ErrorCode = ERR_GET_DEV_HANLDE;
        return 1;
    }

    // get capacity
    ::memset(&pPortData->IdentifyDevice, 0, sizeof(ATA_IDENTIFY_CONFIG_INFO));
    Rslt = SSD_Utility_Get_ATA_Identify(-1, hDevice, &pPortData->IdentifyDevice);
    if (Rslt != 0) {
        pPortData->LogManager.DebugMsg("get identify device fail. sys err = %d", ::GetLastError());
        pPortData->LogManager.LogToFile(true, true, "get identify device fail. sys err = %d", ::GetLastError());
        pPortData->ErrorCode = ERR_CMD_IDENTIFY_DEVICE;
        ::CloseHandle(hDevice);
        hDevice = INVALID_HANDLE_VALUE;
        return 1;
    }

	::memset(Temp, 0, sizeof(Temp));
	::strncpy(Temp, pPortData->IdentifyDevice.Serial_Number, SN_LEN);
    
    pPortData->LogManager.DebugMsg("read SN = %s", Temp);
	pPortData->LogManager.LogToFile(false, true, "read SN = %s", Temp);
    
	::CloseHandle(hDevice);
    hDevice = INVALID_HANDLE_VALUE;
    
    return 0;
}

//-------------------------------------------------------------------------------------------------
void __stdcall GetKeyProStatus(IN bool IsReduceKey, OUT int *pStatus)
{
    ::EnterCriticalSection(&g_csNeedKeyCount);
    
    if (IsReduceKey == true) {
        g_NeedKeyCount++;
        *pStatus = (g_NeedKeyCount > g_KeyProCount) ? OUT_OF_KEY : NEED_KEY;
    }
    else {
        *pStatus = NO_NEED_KEY;
    }
    
    ::LeaveCriticalSection(&g_csNeedKeyCount);
    
    return;
}

//-------------------------------------------------------------------------------------------------
int __stdcall InitPortDataLogManager(IN PORT_DATA *pPortData)
{
    CFileManager FileManager;
    char  ExePath[MAX_PATH];
	char  DateInfo[16];
	char  TimeInfo[16];
	int   Rslt;

	
	::memset(pPortData->UILogFullPath, 0, sizeof(pPortData->UILogFullPath));
	::memset(pPortData->UILogPath, 0, sizeof(pPortData->UILogPath));
	::memset(pPortData->UILogName, 0, sizeof(pPortData->UILogName));


    ::GetLocalTime(&pPortData->TimeInfo.StartTime);
    
	::memset(DateInfo, 0, sizeof(DateInfo));
	::sprintf(DateInfo, "%.4d%.2d%.2d%", pPortData->TimeInfo.StartTime.wYear, pPortData->TimeInfo.StartTime.wMonth, pPortData->TimeInfo.StartTime.wDay);

	::memset(TimeInfo, 0, sizeof(TimeInfo));
	::sprintf(TimeInfo, "%.2d%.2d%.2d", pPortData->TimeInfo.StartTime.wHour, pPortData->TimeInfo.StartTime.wMinute, pPortData->TimeInfo.StartTime.wSecond);
	
	::sprintf(pPortData->UILogName, "%s_%s_Port%.2d.txt", DateInfo, TimeInfo, pPortData->MapIndex);

    ::memset(ExePath, 0, sizeof(ExePath));
    Rslt = FileManager.GetCurrentExeFilePath(ExePath, sizeof(ExePath));
    if (Rslt != 0) {
        pPortData->ErrorCode = ERR_GET_PATH_TO_LOG;
        return 1;
    }

	// assign log path
	::sprintf(pPortData->UILogPath, "%sUI_Log\\%s\\", ExePath, DateInfo);
    
	// assign full log path
	::sprintf(pPortData->UILogFullPath, "%s%s", pPortData->UILogPath, pPortData->UILogName);
	
	Rslt = pPortData->LogManager.Init(pPortData->UILogFullPath, "a+");
	if (Rslt != 0) {
		pPortData->ErrorCode = ERR_INIT_PORT_LOG_MANAGER;
		return 1;
	}

	return 0;
}

//-------------------------------------------------------------------------------------------------
int __stdcall ReleaseTaskResource(IN PROCESS_INFORMATION *pi, ANONYMOUS_PIPE_INFO *pPipeInfo)
{
    DWORD  WaitRslt;
    
    
    // wait child process terminate
	WaitRslt = ::WaitForSingleObject(pi->hProcess, INFINITE);
    if (WaitRslt != WAIT_OBJECT_0) {
        return 1;
    }
    
    // release resource
    if (pi != NULL) {
        ::CloseHandle(pi->hProcess);
        ::CloseHandle(pi->hThread);
    }

    if (pPipeInfo != NULL) {
        ::CloseHandle(pPipeInfo->Stdin.hWrite);
        ::CloseHandle(pPipeInfo->Stdin.hRead);
        
        ::CloseHandle(pPipeInfo->Stdout.hWrite);
        ::CloseHandle(pPipeInfo->Stdout.hRead);
    }
    
    return 0;
}

//-------------------------------------------------------------------------------------------------
int __stdcall ParseString(IN char *pInputString, OUT char *pBuffer, IN int BufferSize)
{
    char  *pStart;
    char  *pEnd;
    int   CopyLength;
    
    
    pStart = strchr(pInputString, '\'');
    if (pStart == NULL) {
        return 1;
    }
    pStart++;
    
    pEnd = strchr(pStart, '\'');
    if (pEnd == NULL) {
        return 1;
    }
    
    CopyLength = ::strlen(pStart) - ::strlen(pEnd);
    if (BufferSize <= CopyLength) {
        return 1;
    }    
    
    ::strncpy(pBuffer, pStart, CopyLength);
            
    return 0;
}

//-------------------------------------------------------------------------------------------------
void __stdcall DetectTerminateThread(IN PORT_DATA *pPortData)
{
    ::EnterCriticalSection(&g_csTaskCount);
    
	g_TaskCount--;
    ::SendMessage(AfxGetMainWnd()->m_hWnd, WM_THREAD_TERMINATE, pPortData->MapIndex, 0);

    // all task thread terminate
	if (g_TaskCount == 0) {
		::SendMessage(AfxGetMainWnd()->m_hWnd, WM_ALL_THREAD_TERMINATE, 0, 0);
	}

	::LeaveCriticalSection(&g_csTaskCount);
    return;
}

//-------------------------------------------------------------------------------------------------
HANDLE __stdcall GetDriveHandle(IN int PhyDrvNum)
{
	HANDLE  hDrive;
	char    DriveRoot[32];
	

	if (PhyDrvNum == -1) {
		hDrive = INVALID_HANDLE_VALUE;
		return hDrive;
	}

	::memset(DriveRoot, 0, sizeof(DriveRoot));
    ::sprintf(DriveRoot, "\\\\.\\PHYSICALDRIVE%d", PhyDrvNum);
	
	hDrive = ::CreateFile(DriveRoot,
                          GENERIC_WRITE | GENERIC_READ,
                          FILE_SHARE_READ | FILE_SHARE_WRITE,
		                  NULL,
                          OPEN_EXISTING,
                          0,
                          NULL);
	
	return hDrive;
}

//-------------------------------------------------------------------------------------------------


///////////////////////////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//-------------------------------------------------------------------------------------------------
CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

//-------------------------------------------------------------------------------------------------
void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

//-------------------------------------------------------------------------------------------------
BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

///////////////////////////////////////////////////////////////////////////////////////////////////
// CdlgSSDMP dialog

CdlgSSDMP::CdlgSSDMP(CWnd* pParent /*=NULL*/)
	: CDialog(CdlgSSDMP::IDD, pParent)
{
	//{{AFX_DATA_INIT(CdlgSSDMP)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

//-------------------------------------------------------------------------------------------------
void CdlgSSDMP::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CdlgSSDMP)
	DDX_Control(pDX, IDC_TAB_MAIN_SHEET, m_TabMainSheet);
	//}}AFX_DATA_MAP
}

//-------------------------------------------------------------------------------------------------
BEGIN_MESSAGE_MAP(CdlgSSDMP, CDialog)
	//{{AFX_MSG_MAP(CdlgSSDMP)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_MESSAGE(WM_DEVICECHANGE, OnDeviceChange)
	ON_NOTIFY(TCN_SELCHANGE, IDC_TAB_MAIN_SHEET, OnSelChangeTabMainSheet)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

///////////////////////////////////////////////////////////////////////////////////////////////////
// CdlgSSDMP message handlers

BOOL CdlgSSDMP::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
    
	int Rslt;

    
	Rslt = this->RegDevNotification();
	if (Rslt != 0) {
        this->m_MPPage.EnableAllUI(false);
		MessageBox("RegDevNotification function fail", NULL, MB_OK | MB_ICONERROR);
		return TRUE;
	}

    
    //======================================================
    //           init member variable and UI
    //======================================================
	Rslt = this->Init();
    if (Rslt != 0) {
        this->m_MPPage.EnableAllUI(false);
		MessageBox("setting environment page fail", NULL, MB_OK | MB_ICONERROR);
		return TRUE;
    }
    
	this->InitUI();
	

	// only this tab page should be init in front of init port alignment
	Rslt = this->m_SettingPage1.Init(this->m_MPIniFullPath, this->m_SNIniFullPath);
	if (Rslt != 0) {
		this->m_MPPage.EnableAllUI(false);
		MessageBox("init setting environment page fail", NULL, MB_OK | MB_ICONERROR);
		return TRUE;
	}
    

    //======================================================
    //              init port alignment
    //======================================================
	switch (this->m_SettingPage1.m_PortAlignmentMode) {
	    case ALL_HUB_MODE:    Rslt = this->InitPortDataByAllHubMode();    break;
        case EXT_4PORT_MODE:  Rslt = this->InitPortDataByExt4PortMode();  break;
        case EXT_7PORT_MODE:  Rslt = this->InitPortDataByExt7PortMode();  break;
		default:
			this->m_MPPage.EnableAllUI(false);
			MessageBox("unknow hub alignment mode", NULL, MB_OK | MB_ICONERROR);
			return TRUE;
    }
	
	if (Rslt != 0) {
		this->m_MPPage.EnableAllUI(false);
		MessageBox("initial port alignment fail", NULL, MB_OK | MB_ICONERROR);
		return TRUE;
	}


	//======================================================
    //                 init tab page
    //======================================================
	Rslt = this->m_MPPage.Init(this->m_PortData, this->m_CommonBurnerFullPath);
	if (Rslt != 0) {
		this->m_MPPage.EnableAllUI(false);
		MessageBox("init MP page fail", NULL, MB_OK | MB_ICONERROR);
		return TRUE;
	}

	Rslt = this->m_SettingPage2.Init(this->m_PortData, this->m_MTableFullPath, this->m_CommonBurnerFullPath);
	if (Rslt != 0) {
		this->m_MPPage.EnableAllUI(false);
		MessageBox("init INI setting page fail", NULL, MB_OK | MB_ICONERROR);
		return TRUE;
	}

	Rslt = this->m_RDTPage.Init(this->m_PortData);
	if (Rslt != 0) {
		this->m_MPPage.EnableAllUI(false);
		MessageBox("init RDT Result page fail", NULL, MB_OK | MB_ICONERROR);
		return TRUE;
	}

    
    //======================================================
    //              init global variable
    //======================================================
    g_IsStartRun         = false;
	g_IsKeyProDrvRemoved = false;
    g_TaskCount         = 0;
    
    ::InitializeCriticalSection(&g_csTaskCount);
    ::InitializeCriticalSection(&g_csNeedKeyCount);
    
	for (int i = 0; i < SUPPORT_PORT_COUNT; i++) {
        g_hEvent[i] = ::CreateEvent(NULL, TRUE, FALSE, NULL);
        if (g_hEvent[i] == NULL) {
            this->m_MPPage.EnableAllUI(false);
			MessageBox("create event kernel object fail", NULL, MB_OK | MB_ICONERROR);
			return TRUE;
        }
    }
        
    Rslt = g_SNManager.Init(this->m_SettingPage1.m_StartSN, this->m_SettingPage1.m_EndSN, this->m_SettingPage1.m_Mask);
    if (Rslt != 0) {
        this->m_MPPage.EnableAllUI(false);
		MessageBox("init serial number fail", NULL, MB_OK | MB_ICONERROR);
        return 1;
    }


    //======================================================
    //           read back key pro count
    //======================================================
	// if function fail, still let user can use MP other function. (ex. modify ini ...)
	Rslt = this->GetKeyProDrive(&this->m_KeyProDrive, &g_KeyProCount);
	if (Rslt != 0) {
		MessageBox("check key function fail", NULL, MB_OK | MB_ICONERROR);
		g_KeyProCount = 0;
		this->m_MPPage.EnableAllUI(false);
	}
    this->m_MPPage.SetStatusBarKeyProCount(g_KeyProCount);
    
	return TRUE;  // return TRUE  unless you set the focus to a control
}

//-------------------------------------------------------------------------------------------------
void CdlgSSDMP::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

//-------------------------------------------------------------------------------------------------
// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CdlgSSDMP::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

//-------------------------------------------------------------------------------------------------
// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CdlgSSDMP::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

//-------------------------------------------------------------------------------------------------
BOOL CdlgSSDMP::OnDeviceChange(UINT nEventType, DWORD dwData)
{
    int  Rslt;

	if (nEventType == DBT_DEVICEARRIVAL) {
		PDEV_BROADCAST_HDR pHdr = (PDEV_BROADCAST_HDR)dwData;
		if (pHdr->dbch_devicetype != DBT_DEVTYP_DEVICEINTERFACE) {
			return TRUE;
		}
		
		PDEV_BROADCAST_DEVICEINTERFACE pdbch = (PDEV_BROADCAST_DEVICEINTERFACE)dwData;
        
        // get insert drive phsical drive number
		DWORD PhyDrvNum;
		Rslt = Vol_QueryPhysicalDriveNumberByVolumeName(pdbch->dbcc_name, &PhyDrvNum);
		if (Rslt != 0) {
			return TRUE;
		}
		
        Rslt = this->InsertDrive(PhyDrvNum);
        if (Rslt != 0) {
            return TRUE;
        }
    }
    else if ((nEventType == DBT_DEVICEREMOVECOMPLETE)) {

		PDEV_BROADCAST_VOLUME pDBV = (PDEV_BROADCAST_VOLUME)dwData;
		this->DetectKeyProDriveRemoved(pDBV);

        Rslt = this->RemoveDrive();
		if (Rslt != 0) {
			return TRUE;
		}
    }

    return TRUE;
}

//-------------------------------------------------------------------------------------------------
LRESULT CdlgSSDMP::WindowProc(UINT message, WPARAM wParam, LPARAM lParam) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	switch (message) {
	    case WM_START_RUN:             this->OnMsgStartRun();                      break;
        case WM_UPDATE_PROGRESS:       this->OnMsgUpdateProgress(wParam, lParam);  break;
        case WM_THREAD_TERMINATE:      this->OnMsgThreadTerminate(wParam);         break;
        case WM_ALL_THREAD_TERMINATE:  this->OnMsgAllThreadTerminate();            break;
        case WM_SCAN_DRIVE:            this->OnMsgScanDrive();                     break;
		case WM_CHANGE_SN:             this->OnMsgChangeSN();                      break;
        case WM_UPDATE_DESCRIPTION:    this->OnMsgUpdateDescription(wParam);       break;
	}

	return CDialog::WindowProc(message, wParam, lParam);
}

//-------------------------------------------------------------------------------------------------
int CdlgSSDMP::Init()
{
    int Rslt;
    

	this->m_KeyProDrive = NULL;
	this->m_hDevNotify = NULL;
    
	::memset(this->m_MPIniFullPath, 0, sizeof(this->m_MPIniFullPath));
	this->m_FileManager.GetCurrentExeFilePath(this->m_MPIniFullPath, sizeof(this->m_MPIniFullPath));
	::strcat(this->m_MPIniFullPath, "SSDMP.ini");

	::memset(this->m_IniFullPath, 0, sizeof(this->m_IniFullPath));

    ::memset(this->m_MTableFullPath, 0, sizeof(this->m_MTableFullPath));
	this->m_FileManager.GetCurrentExeFilePath(this->m_MTableFullPath, sizeof(this->m_MTableFullPath));
	::strcat(this->m_MTableFullPath, "Setting\\MTable.set");
    
    ::memset(this->m_CommonBurnerFullPath, 0, sizeof(this->m_CommonBurnerFullPath));
	this->m_FileManager.GetCurrentExeFilePath(this->m_CommonBurnerFullPath, sizeof(this->m_CommonBurnerFullPath));
	::strcat(this->m_CommonBurnerFullPath, "Setting\\CommonBurner.bin");

    ::memset(this->m_SNIniFullPath, 0, sizeof(this->m_SNIniFullPath));
    ::sprintf(this->m_SNIniFullPath, "%s", "C:\\SSD_SN.ini");
    
	this->m_OP = 0;
	
    
    //=============================================================
	//                  init port data
	//=============================================================
    for (int i = 0; i < SUPPORT_PORT_COUNT; i++) {
		this->m_PortData[i].hWorkThread = NULL;
		this->m_PortData[i].PassCount   = 0;  // this value will always keep
		this->m_PortData[i].FailCount   = 0;  // this value will always keep
		this->m_PortData[i].MapIndex    = i;  // this value will always keep

		this->RemovePortData(i);
	}
    
    
    //=============================================================
	//                init hub info table
	//=============================================================
	this->m_pExt4PortHubInfo = NULL;
	this->m_pExt7PortHubInfo = NULL;
    
    // malloc memory for 4-port mapping table
    this->m_pExt4PortHubInfo = (HUB_INFO_TABLE*)::malloc(EXT_4PORT_HUB_COUNT * sizeof(HUB_INFO_TABLE));
    if (this->m_pExt4PortHubInfo == NULL) {
        MessageBox("malloc memory for 4-port hub table fail", NULL, MB_OK | MB_ICONERROR); 
        return 1;
    }
    
    ::memset(this->m_pExt4PortHubInfo, 0, EXT_4PORT_HUB_COUNT * sizeof(HUB_INFO_TABLE));
    for (int i = 0; i < EXT_4PORT_HUB_COUNT; i++) {
        this->m_pExt4PortHubInfo[i].HubNumber = i + 1;  //arvin note. Initial hub nubmer here
    }

	// malloc memory for 7-port mapping table
    this->m_pExt7PortHubInfo = (HUB_INFO_TABLE*)::malloc(EXT_7PORT_HUB_COUNT * sizeof(HUB_INFO_TABLE));
    if (this->m_pExt7PortHubInfo == NULL) {
        MessageBox("malloc memory for 7-port hub table fail", NULL, MB_OK | MB_ICONERROR);
        return 1;
    }
    
    ::memset(this->m_pExt7PortHubInfo, 0, EXT_7PORT_HUB_COUNT * sizeof(HUB_INFO_TABLE));
    for (int i = 0; i < EXT_7PORT_HUB_COUNT; i++) {
        this->m_pExt7PortHubInfo[i].HubNumber = i + 1;  //arvin note. Initial hub nuber here 
    }
    
    
    // to do ...
    // if find user define hub, init m_UserDefineHubMapManager object
    
    Rslt = this->m_HubManager.Init();
	if (Rslt != 0) {
		MessageBox("hub manager init fail", NULL, MB_OK | MB_ICONERROR);
		return 1;
	}


	//=============================================================
	//                 dump key pro dll
	//=============================================================
	::memset(this->m_SpecialPath, 0, sizeof(this->m_SpecialPath));
    Rslt = ::SHGetSpecialFolderPath(NULL, this->m_SpecialPath, CSIDL_APPDATA, FALSE);
	if (Rslt != TRUE) {
		MessageBox("get special path fail", NULL, MB_OK | MB_ICONERROR);
		return 1;
	}

	::strcat(this->m_SpecialPath, "\\SSDMP");
    
	Rslt = this->m_FileManager.BuildDirectory(this->m_SpecialPath);
	if (Rslt != 0) {
		MessageBox("build MP folder fail", NULL, MB_OK | MB_ICONERROR);
		return 1;
	}

    ::memset(this->m_KeyProDllFullPath, 0, sizeof(this->m_KeyProDllFullPath));
	::strncpy(this->m_KeyProDllFullPath, this->m_SpecialPath, sizeof(this->m_KeyProDllFullPath));
	::strcat(this->m_KeyProDllFullPath, "\\KeyProGen.dll");

	Rslt = this->m_FileManager.DumpFile(this->m_KeyProDllFullPath, g_KeyProDLL, sizeof(g_KeyProDLL));
	if (Rslt != 0) {
		MessageBox("dump file fail", NULL, MB_OK | MB_ICONERROR);
		return 1;
	}

	this->m_hKeyProDLL = ::LoadLibrary(this->m_KeyProDllFullPath);
    if (this->m_hKeyProDLL == NULL) {
		MessageBox("load DLL fail", NULL, MB_OK | MB_ICONERROR);
        return 1;
    }

	// get export function
	this->fnReadCounterFromBadBlock = (FReadCounterFromBadBlock)::GetProcAddress(this->m_hKeyProDLL, "ReadCounterFromBadBlock");
	if (fnReadCounterFromBadBlock == NULL) {
		MessageBox("get read counter function pointer fail", NULL, MB_OK | MB_ICONERROR);
		return 1;
	}
	
	this->fnWriteCounterToBadBlock = (FWriteCounterToBadBlock)::GetProcAddress(this->m_hKeyProDLL, "WriteCounterToBadBlock");
	if (fnWriteCounterToBadBlock == NULL) {
		MessageBox("get write counter function pointer fail", NULL, MB_OK | MB_ICONERROR);
		return 1;
	}
    
    this->fnCheckCardIsValidEx = (FCheckCardIsValidEx)::GetProcAddress(this->m_hKeyProDLL, "CheckCardIsValidEx");
    if (fnWriteCounterToBadBlock == NULL) {
		MessageBox("get key function pointer fail", NULL, MB_OK | MB_ICONERROR);
		return 1;
	}


	//=============================================================
	//                 dump MP execute file
	//=============================================================
	::memset(this->m_MPFullPath, 0, sizeof(this->m_MPFullPath));
	::strncpy(this->m_MPFullPath, this->m_SpecialPath, sizeof(this->m_MPFullPath));
	::strcat(this->m_MPFullPath, "\\3S_SSD_MP.exe");

	Rslt = this->m_FileManager.DumpFile(this->m_MPFullPath, g_MP, sizeof(g_MP));
	if (Rslt != 0) {
		MessageBox("dump file fail", NULL, MB_OK | MB_ICONERROR);
		return 1;
	}

	return 0;
}

//-------------------------------------------------------------------------------------------------
void CdlgSSDMP::InitUI()
{
	this->ShowAppVer();


	//=============================================================
	//                 create tab page
	//=============================================================
	this->m_TabMainSheet.InsertItem(MP_TAB_PAGE, "MP");
    this->m_TabMainSheet.InsertItem(ENVIRONMENT_TAB_PAGE, "Environment");
	this->m_TabMainSheet.InsertItem(FTB_TAB_PAGE, "INI Setting");
	this->m_TabMainSheet.InsertItem(RDT_RSLT_PAGE, "RDT / Defect Info");
    
    this->m_MPPage.Create(IDD_MP_PAGE_DIALOG, &this->m_TabMainSheet);
    this->m_SettingPage1.Create(IDD_SETTING_PAGE1_DIALOG, &this->m_TabMainSheet);
	this->m_SettingPage2.Create(IDD_SETTING_PAGE2_DIALOG, &this->m_TabMainSheet);
	this->m_RDTPage.Create(IDD_RDT_RSLT_PAGE_DIALOG, &this->m_TabMainSheet);

	this->SwapTab();


	return;
}

//-------------------------------------------------------------------------------------------------
void CdlgSSDMP::SwapTab()
{
	CRect  RectClient;
    CRect  RectItem;
	int    CurrentIndex;


	this->m_TabMainSheet.GetItemRect(0, &RectItem);
	this->m_TabMainSheet.GetClientRect(&RectClient);

	int x  = RectItem.left;
	int y  = RectItem.bottom + 1;
    int cx = RectClient.right - x - 2;
	int cy = RectClient.bottom - y - 2;

	this->m_MPPage.SetWindowPos(NULL, x, y, cx, cy, SWP_HIDEWINDOW);
	this->m_SettingPage1.SetWindowPos(NULL, x, y, cx, cy, SWP_HIDEWINDOW);
	this->m_SettingPage2.SetWindowPos(NULL, x, y, cx, cy, SWP_HIDEWINDOW);
	this->m_RDTPage.SetWindowPos(NULL, x, y, cx, cy, SWP_HIDEWINDOW);

	CurrentIndex = this->m_TabMainSheet.GetCurSel();
	switch (CurrentIndex) {
        case MP_TAB_PAGE:           this->m_MPPage.SetWindowPos(NULL, x, y, cx, cy, SWP_SHOWWINDOW);        break;
        case ENVIRONMENT_TAB_PAGE:  this->m_SettingPage1.SetWindowPos(NULL, x, y, cx, cy, SWP_SHOWWINDOW);  break;	
		case FTB_TAB_PAGE:          this->m_SettingPage2.SetWindowPos(NULL, x, y, cx, cy, SWP_SHOWWINDOW);  break;
		case RDT_RSLT_PAGE: 
			this->m_RDTPage.SetWindowPos(NULL, x, y, cx, cy, SWP_SHOWWINDOW);       
			this->m_RDTPage.ShowProductionInfo();       
			
			break;
	}
    
    return;
}

//-------------------------------------------------------------------------------------------------
void CdlgSSDMP::ShowAppVer()
{
	DWORD   VerHandle;
    DWORD   VerSize;
    UINT    Size;
    LPBYTE  lpBuffer;
	LPTSTR  pVerData;
    int     major, minor, year, date;
    char    buf[256] = {0};
    char    AppName[512] = {0};


    ::GetWindowModuleFileName(this->m_hWnd, AppName, sizeof(AppName));
    VerSize = ::GetFileVersionInfoSize(AppName, &VerHandle);
    if (VerSize == 0) {
        return;
    }
    
    pVerData = new char[VerSize];
    if (pVerData == NULL) {
        return;
    }
    
    if (::GetFileVersionInfo(AppName, VerHandle, VerSize, pVerData)) {
        if (::VerQueryValue(pVerData, "\\", (VOID FAR* FAR*)&lpBuffer, &Size)) {
            if (Size) {
                VS_FIXEDFILEINFO *pVerInfo = (VS_FIXEDFILEINFO *)lpBuffer;
                if (pVerInfo->dwSignature == 0xfeef04bd) {
                    major = HIWORD(pVerInfo->dwFileVersionMS);
                    minor = LOWORD(pVerInfo->dwFileVersionMS);
                    year  = HIWORD(pVerInfo->dwFileVersionLS);
                    date  = LOWORD(pVerInfo->dwFileVersionLS);
                    ::_stprintf(buf, _T("SSD MP v%d.%d.%d.%d"), major, minor, year, date);
                    this->SetWindowText(buf);
                }
            }
        }
    }
    
    delete[] pVerData;
    pVerData = NULL;
    
    return;
}

//-------------------------------------------------------------------------------------------------
void CdlgSSDMP::OnSelChangeTabMainSheet(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	
	this->SwapTab();

	*pResult = 0;
}

//-------------------------------------------------------------------------------------------------
int CdlgSSDMP::RegDevNotification()
{
    DEV_BROADCAST_DEVICEINTERFACE dbch;


    ::memset(&dbch, 0, sizeof(dbch));

    dbch.dbcc_size = sizeof(dbch);
    dbch.dbcc_devicetype = DBT_DEVTYP_DEVICEINTERFACE;

	this->m_hDevNotify = ::RegisterDeviceNotification(this->m_hWnd, &dbch, DEVICE_NOTIFY_ALL_INTERFACE_CLASSES);
    if (this->m_hDevNotify == NULL) {
		return 1;
    }

	return 0;
}

//-------------------------------------------------------------------------------------------------
void CdlgSSDMP::OnDestroy() 
{
	CDialog::OnDestroy();
	
	// TODO: Add your message handler code here
    char  TempSN[SN_LEN + 1];
    int   Rslt;

    
    ::memset(TempSN, 0, sizeof(TempSN));
    Rslt = g_SNManager.GenerateSN(TempSN);
	if (Rslt == 0) {
        this->m_FileManager.WriteIniFile(this->m_SNIniFullPath, "Setting", "Start_SN", TempSN);
	}
    else {
        this->m_FileManager.WriteIniFile(this->m_SNIniFullPath, "Setting", "Start_SN", this->m_SettingPage1.m_EndSN);
    }
    this->m_FileManager.WriteIniFile(this->m_SNIniFullPath, "Setting", "End_SN", this->m_SettingPage1.m_EndSN);
    this->m_FileManager.WriteIniFile(this->m_SNIniFullPath, "Setting", "Mask_SN", this->m_SettingPage1.m_Mask);


	if (this->m_hDevNotify != NULL) {
		::UnregisterDeviceNotification(this->m_hDevNotify);
		this->m_hDevNotify = NULL;
	}

	if (this->m_hKeyProDLL) {
		::FreeLibrary(this->m_hKeyProDLL);
        this->m_hKeyProDLL = NULL;
	}
    
    if (this->m_pExt4PortHubInfo != NULL) {
		::free(this->m_pExt4PortHubInfo);
		this->m_pExt4PortHubInfo = NULL;
	}

	if (this->m_pExt7PortHubInfo != NULL) {
		::free(this->m_pExt7PortHubInfo);
		this->m_pExt7PortHubInfo = NULL;
	}
    
    for (int i = 0; i < SUPPORT_PORT_COUNT; i++) {
        if (g_hEvent[i] != NULL) {
            ::CloseHandle(g_hEvent[i]);
		    g_hEvent[i] = NULL;    
        }
	}	

    ::DeleteCriticalSection(&g_csTaskCount);
    ::DeleteCriticalSection(&g_csNeedKeyCount);

	::DeleteFile(this->m_KeyProDllFullPath);
	::DeleteFile(this->m_MPFullPath);
    
    return;
}

//-------------------------------------------------------------------------------------------------
int CdlgSSDMP::InitPortDataByAllHubMode()
{
	return 0;
}

//-------------------------------------------------------------------------------------------------
int CdlgSSDMP::InitPortDataByExt4PortMode()
{
    ATA_IDENTIFY_CONFIG_INFO  IdentifyDevice;
	TCHAR  HubName[256];  // temp for save each drive hub name
	DWORD  HubNumber;     // temp for save each drive hub index
	DWORD  PortNumber;    // temp for save each drive port number
	int    Offset;
    int    Mode;          // firmware mode
	int    Rslt;
    

	//used HunMap HubInfo to initial hub alignment (Ext-4port & Ext-7port)
	int nHubNumberTemp[4];
	int nOderTemp[4];//temp record the order of HubNumber 
	nOderTemp[0] = 0;
	nOderTemp[1] = 1;
	nOderTemp[2] = 2;
	nOderTemp[3] = 3;

	for (int k = 0; k < EXT_4PORT_HUB_COUNT; k++) {
        if ((this->m_UserDefineHubMapManager.m_HubMap[k].PortCount != 4) || (this->m_UserDefineHubMapManager.m_HubMap[k].HubNumber == 0)) {
            nHubNumberTemp[k] = 0xFF;                                            // not 4port hub or not on HubMap we get it an impossible value
        }
        else {
            nHubNumberTemp[k] = this->m_UserDefineHubMapManager.m_HubMap[k].HubNumber;
        }
	}
	
	//decide hub sequence    //arvin note. sorting hub number
	if (nHubNumberTemp[0] > nHubNumberTemp[1]) {
		nOderTemp[0]++; //1
		nOderTemp[1]--; //0
	}
	if (nHubNumberTemp[2] < nHubNumberTemp[1]) {
		nOderTemp[1]++; 
		nOderTemp[2]--;
	}
	if (nHubNumberTemp[2] < nHubNumberTemp[0]) {
		nOderTemp[0]++;
		nOderTemp[2]--;
	}
	if (nHubNumberTemp[3] < nHubNumberTemp[2]) {
		nOderTemp[2]++; 
		nOderTemp[3]--;	
	}
	if (nHubNumberTemp[3] < nHubNumberTemp[1]) {
		nOderTemp[1]++;
		nOderTemp[3]--;
	}
	if (nHubNumberTemp[3] < nHubNumberTemp[0]) {
		nOderTemp[0]++;
		nOderTemp[3]--;
	}		


	for (int aa = 0; aa < EXT_4PORT_HUB_COUNT; aa++){  //Anjoy_0205
		for (int bb = 0; bb < 4; bb++) {
			if (nOderTemp[bb] == aa) {
				if (nHubNumberTemp[bb] != 0xFF) {//4 port hub & on HubMap
					::strcpy(this->m_pExt4PortHubInfo[aa].HubName, this->m_UserDefineHubMapManager.m_HubMap[bb].HubName);
					break;
				}
			}
		}
	}
		
	for (DWORD i = 0; i < MAX_USB_DRIVE_COUNT; i++) {
        
		//==================================================
		//  query the hub info that current dirve connects
		//==================================================
        char Drive[32] = {0};
		::sprintf(Drive, "\\\\.\\PHYSICALDRIVE%d", i);
        
		HANDLE hDrive = ::CreateFile(Drive, GENERIC_WRITE | GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, 0, NULL);
		if (hDrive == INVALID_HANDLE_VALUE) {
			continue;
		}
        
		Rslt = SSD_Utility_Get_FW_Mode(-1, hDrive, 0, &Mode);
		if (Rslt != 0) {
            ::CloseHandle(hDrive);
            hDrive = INVALID_HANDLE_VALUE;
			continue;
		}
		
		if (Mode == UNKNOW_MODE) {
            ::CloseHandle(hDrive);
            hDrive = INVALID_HANDLE_VALUE;
			continue;
		}

        ::memset(HubName, 0, sizeof(HubName));
		Rslt = Vol_QueryPortNumberByDriveLetter(NULL, hDrive, HubName, &PortNumber);
		if(Rslt != 0) {
            ::CloseHandle(hDrive);
            hDrive = INVALID_HANDLE_VALUE;
			continue;
		}
        
        ::memset(&IdentifyDevice, 0, sizeof(ATA_IDENTIFY_CONFIG_INFO));
        Rslt = SSD_Utility_Get_ATA_Identify(-1, hDrive, &IdentifyDevice);
        if (Rslt != 0) {
            ::CloseHandle(hDrive);
            hDrive = INVALID_HANDLE_VALUE;
			continue;
        }
        
        ::CloseHandle(hDrive);
        hDrive = INVALID_HANDLE_VALUE;
            

		//==============================================================
		//            build ext 4 port hub info table
		//==============================================================

		// check is ext 4 port hub     //arvin note. if the drive is not plugged in external 4-port hub, ignore it.
		if (this->m_HubManager.IsExt4PortHub(HubName) != TRUE) {
			continue;  
		}
	
		// build ext 4 port hub info table
		BOOL bAddDrive = FALSE;
		for (int j = 0; j < EXT_4PORT_HUB_COUNT; j++) {
			if (::_tcscmp(this->m_pExt4PortHubInfo[j].HubName, HubName) == 0) {//check this HubName exist in Hubinfo or not  
				bAddDrive = TRUE;
				Offset = j * 4;
				HubNumber = this->m_pExt4PortHubInfo[j].HubNumber;    //arvin note. m_pExt4PortHubInfo[j].HubNumber is set in initial flow
				break;
			}
			else if (::_tcslen(this->m_pExt4PortHubInfo[j].HubName) == 0) {//check HubInfo Hubname is empty or not
				::_tcscpy(this->m_pExt4PortHubInfo[j].HubName, HubName);
				bAddDrive = TRUE;
				Offset = j * 4;
				HubNumber = this->m_pExt4PortHubInfo[j].HubNumber;
				break;	
			}
			else {//check this HubName is the same U2/U3 or new Hub
				//Analysis this Hubname
				TCHAR szHubNameTempSave[MAX_PATH];
				TCHAR szHubNameSearch[MAX_PATH];
				TCHAR szHubNameTemp[MAX_PATH];
				TCHAR *pHubNameTempStart;
				TCHAR *pHubNameTempEnd;
				
				//Find "pid" string
				::memset(szHubNameSearch, 0, sizeof(szHubNameSearch));
				::_tcscpy(szHubNameSearch, _T("pid"));
				pHubNameTempStart = ::_tcsstr(HubName, szHubNameSearch);
				if (pHubNameTempStart == NULL) {
					::memset(szHubNameSearch, 0, sizeof(szHubNameSearch));
					::_tcscpy(szHubNameSearch, _T("PID"));
					pHubNameTempStart = ::_tcsstr(HubName, szHubNameSearch);
					if (pHubNameTempStart == NULL) {
						continue;
					}
				}
				//copy PID to szHubNamePID
				TCHAR szHubNameTempPID[8];
				::memset(szHubNameTempPID, 0, sizeof(szHubNameTempPID));
				::memcpy(szHubNameTempPID, pHubNameTempStart, sizeof(szHubNameTempPID));

				//find #~~~#
				::memset(szHubNameSearch, 0, sizeof(szHubNameSearch));
				::_tcscpy(szHubNameSearch, _T("#"));
				pHubNameTempStart = ::_tcsstr(pHubNameTempStart, szHubNameSearch);
				if (pHubNameTempStart == NULL) {
					continue;
				}

				//cpy to szHubNameTemp
				pHubNameTempStart++;//ignaor #
				::memset(szHubNameTemp, 0 ,sizeof(szHubNameTemp));
				::memcpy(szHubNameTemp, pHubNameTempStart, sizeof(TCHAR) * MAX_PATH);

				//find next #
				::memset(szHubNameSearch, 0 ,sizeof(szHubNameSearch));
				::_tcscpy(szHubNameSearch, _T("#"));
				pHubNameTempEnd = ::_tcsstr(pHubNameTempStart,szHubNameSearch);
				if (pHubNameTempEnd == NULL) {
					continue;
				}
				pHubNameTempEnd --;//move to number before # 
				TCHAR ExHubPortNumber = *pHubNameTempEnd;
				pHubNameTempEnd --;//ignor external hub port number

				//copy to szHubNameTempSave
				::memset(szHubNameTempSave, 0, sizeof(szHubNameTempSave));
				for (int a = 0; pHubNameTempStart <= pHubNameTempEnd; a++) {
					szHubNameTempSave[a] = szHubNameTemp[a];
					pHubNameTempStart++;
				}
	
				//Analysis Ext-4port HunInfo Hubname
				TCHAR szExt4PortHubNameSearch[MAX_PATH];
				TCHAR szExt4PortHubNameTempSave[MAX_PATH];
				TCHAR szExt4PortHubNameTemp[MAX_PATH];
				TCHAR *pExt4PortHubNameTempStart;
				TCHAR *pExt4PortHubNameTempEnd;

				//Find "pid" string
				::memset(szExt4PortHubNameSearch, 0, sizeof(szExt4PortHubNameSearch));
				::_tcscpy(szExt4PortHubNameSearch, _T("pid"));
				pExt4PortHubNameTempStart = ::_tcsstr(this->m_pExt4PortHubInfo[j].HubName, szExt4PortHubNameSearch);
				if (pExt4PortHubNameTempStart == NULL) {
					::memset(szExt4PortHubNameSearch, 0, sizeof(szExt4PortHubNameSearch));
					::_tcscpy(szExt4PortHubNameSearch, _T("PID"));
					pExt4PortHubNameTempStart = ::_tcsstr(this->m_pExt4PortHubInfo[j].HubName,szExt4PortHubNameSearch);
					if (pExt4PortHubNameTempStart == NULL) {
						continue;
					}
				}
				//copy PID to szExt4PorHubNamePID
				TCHAR szExt4PortHubNameTempPID[8];
				::memset(szExt4PortHubNameTempPID, 0, sizeof(szExt4PortHubNameTempPID));
				::memcpy(szExt4PortHubNameTempPID, pExt4PortHubNameTempStart, sizeof(szExt4PortHubNameTempPID));

				//find #~~~#
				::memset(szExt4PortHubNameSearch, 0 ,sizeof(szExt4PortHubNameSearch));
				::_tcscpy(szExt4PortHubNameSearch, _T("#"));
				pExt4PortHubNameTempStart = ::_tcsstr(pExt4PortHubNameTempStart, szExt4PortHubNameSearch);
				if (pExt4PortHubNameTempStart == NULL) {
					continue;
				}

				//cpy to szHubNameTemp
				pExt4PortHubNameTempStart++;//ignaor #
				::memset(szExt4PortHubNameTemp, 0 ,sizeof(szExt4PortHubNameTemp));
				::memcpy(szExt4PortHubNameTemp, pExt4PortHubNameTempStart, sizeof(TCHAR) * MAX_PATH);

				//find next #
				pExt4PortHubNameTempEnd = ::_tcsstr(pExt4PortHubNameTempStart,szExt4PortHubNameSearch);
				if (pExt4PortHubNameTempEnd == NULL) {
					continue;
				}

				pExt4PortHubNameTempEnd--;
				TCHAR Ext4PortHubNumber = *pExt4PortHubNameTempEnd;
				pExt4PortHubNameTempEnd--;

				//copy to szExt4PortHubNameTempSave
				::memset(szExt4PortHubNameTempSave, 0 ,sizeof(szExt4PortHubNameTempSave));
				for (int b = 0; pExt4PortHubNameTempStart <= pExt4PortHubNameTempEnd; b++) {
					szExt4PortHubNameTempSave[b] =szExt4PortHubNameTemp[b];
					pExt4PortHubNameTempStart++;
				}

//Anjoy_0212 >>>
				//check the name #~~~~~# is the same or not                                 
				if (::_tcscmp(szExt4PortHubNameTempSave, szHubNameTempSave) != 0) {     //arvin note. make sure that the name between #~~~# is same
					continue;
				}

				//check is it under one U2 mode and one U3 mode 		               //arvin note. make sure the PID is different  		
				if (::memcmp(szExt4PortHubNameTempPID, szHubNameTempPID, sizeof(szExt4PortHubNameTempPID)) == 0) {
					continue;
				}
				Ext4PortHubNumber = (Ext4PortHubNumber % 2);                           //arvin note. make sure port nmber is matched rule of same hub 
				ExHubPortNumber = (ExHubPortNumber % 2);

				//NEC 3.0 Root Hub 1,2 => U3; 3,4 => U2 & 1/3 one ext-hub for U3/U2 , 2/4 one ext-hub for U3/U2
 				if (Ext4PortHubNumber == ExHubPortNumber) {
					bAddDrive = TRUE;
					Offset = j * 4;
					HubNumber = this->m_pExt4PortHubInfo[j].HubNumber;
					break;
				}
//Anjoy_0212 <<<
			}
		
		}

		if (bAddDrive != TRUE) {
			continue;
		}
		
		//==============================================================
		//                  assign drive info 
		//==============================================================
        int  MapIndex;

		// assign drive info to m_PortData
		MapIndex = Offset + (PortNumber - 1);
        this->m_PortData[MapIndex].Mode        = Mode;
		/*
		this->m_PortData[MapIndex].CardSize    = IdentifyDevice.Number_Of_User_Addressable_Logical_Sectors;
		*/
		this->m_PortData[MapIndex].IdentifyDevice = IdentifyDevice;
        this->m_PortData[MapIndex].IsReduceKey = (Mode == ROM_SAFE_MODE) ? true : false;
		this->AddPortData(i, MapIndex, HubName, PortNumber, HubNumber);
		this->m_MPPage.UpdatePortDataUI(&m_PortData[MapIndex]);
	}

    return 0;
}

//-------------------------------------------------------------------------------------------------
int CdlgSSDMP::InitPortDataByExt7PortMode()
{
	return 0;
}

//-------------------------------------------------------------------------------------------------
int CdlgSSDMP::GetMapPortIndex(IN char *HubName, IN int PortNumber, OUT int *pMapIndex)
{
	int Rslt;
    
    switch (this->m_SettingPage1.m_PortAlignmentMode) {
	    case ALL_HUB_MODE:    Rslt = GetMapPortIndexByAllHubMode(HubName, PortNumber, pMapIndex);    break;
	    case EXT_4PORT_MODE:  Rslt = GetMapPortIndexByExt4PortMode(HubName, PortNumber, pMapIndex);  break;
	    case EXT_7PORT_MODE:  Rslt = GetMapPortIndexByExt7PortMode(HubName, PortNumber, pMapIndex);  break;
        default:
		    return 1;
    }
	
    if (Rslt != 0) {
        return 1;
    }
	
    return 0;
}

//-------------------------------------------------------------------------------------------------
int CdlgSSDMP::GetMapPortIndexEx(IN char *pHubName, IN int PortNumber, OUT int *pMapIndex)
{
    for (int i = 0; i < SUPPORT_PORT_COUNT; i++) {
        if (::strcmp(pHubName, this->m_PortData[i].HubData.HubName) == 0 && (PortNumber == this->m_PortData[i].HubData.PortNumber)) {
            *pMapIndex = this->m_PortData[i].MapIndex;
			return 0;
        }
    }

	return 1;
}

//-------------------------------------------------------------------------------------------------
int CdlgSSDMP::GetMapPortIndexByAllHubMode(IN char *HubName, IN int PortNumber, OUT int *pMapIndex)
{
	// search match info for multi LUN case
    for (int i = 0; i< SUPPORT_PORT_COUNT; i++) {
        if ((::_stricmp(HubName, this->m_PortData[i].HubData.HubName) == 0) && (PortNumber == this->m_PortData[i].HubData.PortNumber)) {
			*pMapIndex = this->m_PortData[i].MapIndex;
			return 0;               
        }
    }

	// find the first map index of the empty space
    for (int i = 0; i < SUPPORT_PORT_COUNT; i++) {
        if (this->m_PortData[i].PhyDrvNum == -1) {
            *pMapIndex = i;
			return 0;
        }
    }

	return 1;
}

//-------------------------------------------------------------------------------------------------
int CdlgSSDMP::GetMapPortIndexByExt4PortMode(IN TCHAR *szHubName, IN int dwPortNumber, OUT int *pnMapIndex)
{
    int  nIndexOffset;
	

	if (!this->m_HubManager.IsExt4PortHub(szHubName)) {
		return 1;
	}
	
	// search match info for multi LUN case
    for (int i = 0; i < SUPPORT_PORT_COUNT; i++) {
        if ((::strcmp(szHubName, this->m_PortData[i].HubData.HubName) == 0) && (dwPortNumber == this->m_PortData[i].HubData.PortNumber)) {
			*pnMapIndex = this->m_PortData[i].MapIndex;
			return 0;
		}
    }
	
	// search in ext 4 port hub info talbe
    for (int i = 0; i < EXT_4PORT_HUB_COUNT; i++) {
        if (::strcmp(this->m_pExt4PortHubInfo[i].HubName, szHubName) == 0) {  //check this HubName exist in Hubinfo or not
				nIndexOffset = (this->m_pExt4PortHubInfo[i].HubNumber - 1) * 4;
				*pnMapIndex = nIndexOffset + (dwPortNumber - 1);
				return 0;
        }
		else if (::strlen(this->m_pExt4PortHubInfo[i].HubName) == 0) {  //check HubInfo Hubname is empty or not
			::strcpy(this->m_pExt4PortHubInfo[i].HubName, szHubName);
			nIndexOffset = (this->m_pExt4PortHubInfo[i].HubNumber - 1) * 4;
			*pnMapIndex = nIndexOffset + (dwPortNumber - 1);
			return 0;
        }
		else {  //check this HubName is the same U2/U3 or new Hub

			//Analysis this Hubname
			TCHAR szHubNameTempSave[MAX_PATH];
			TCHAR szHubNameSearch[MAX_PATH];
			TCHAR szHubNameTemp[MAX_PATH];
			TCHAR *pHubNameTempStart;
			TCHAR *pHubNameTempEnd;
			
			
			//Find "pid" string
			::memset(szHubNameSearch, 0 ,sizeof(szHubNameSearch));
			::_tcscpy(szHubNameSearch, _T("pid"));
			pHubNameTempStart = ::_tcsstr(szHubName,szHubNameSearch);
			if(pHubNameTempStart == NULL){
				::memset(szHubNameSearch, 0 ,sizeof(szHubNameSearch));
				::_tcscpy(szHubNameSearch, _T("PID"));
				pHubNameTempStart = ::_tcsstr(szHubName,szHubNameSearch);
				if(pHubNameTempStart == NULL){
					return 2;
				}
			}
			//copy PID to szHubNamePID
			TCHAR szHubNameTempPID[8];
			::memset(szHubNameTempPID, 0 ,sizeof(szHubNameTempPID));
			::memcpy(szHubNameTempPID, pHubNameTempStart, sizeof(szHubNameTempPID));

			//find #~~~#
			::memset(szHubNameSearch, 0 ,sizeof(szHubNameSearch));
			::_tcscpy(szHubNameSearch, _T("#"));
			pHubNameTempStart = ::_tcsstr(pHubNameTempStart,szHubNameSearch);
			if(pHubNameTempStart == NULL){
				return 3;
			}

			//cpy to szHubNameTemp
			pHubNameTempStart++;//ignaor #
			::memset(szHubNameTemp, 0 ,sizeof(szHubNameTemp));
			::memcpy(szHubNameTemp, pHubNameTempStart, sizeof(TCHAR) * MAX_PATH);

			//find next #
			::memset(szHubNameSearch, 0 ,sizeof(szHubNameSearch));
			::_tcscpy(szHubNameSearch, _T("#"));
			pHubNameTempEnd = ::_tcsstr(pHubNameTempStart,szHubNameSearch);
			if(pHubNameTempEnd == NULL){
				return 4;
			}
			pHubNameTempEnd --;//move to number before # 
			TCHAR ExHubPortNumber = *pHubNameTempEnd;
			pHubNameTempEnd --;//ignor external hub port number

			//copy to szHubNameTempSave
			::memset(szHubNameTempSave, 0 ,sizeof(szHubNameTempSave));
			for(int a = 0;  pHubNameTempStart <= pHubNameTempEnd ; a++){
				szHubNameTempSave[a] =szHubNameTemp[a];
				pHubNameTempStart++;
			}

			//Analysis Ext-4port HunInfo Hubname
			TCHAR szExt4PortHubNameSearch[MAX_PATH];
			TCHAR szExt4PortHubNameTempSave[MAX_PATH];
			TCHAR szExt4PortHubNameTemp[MAX_PATH];
			TCHAR *pExt4PortHubNameTempStart;
			TCHAR *pExt4PortHubNameTempEnd;

			//Find "pid" string
			::memset(szExt4PortHubNameSearch, 0 ,sizeof(szExt4PortHubNameSearch));
			::_tcscpy(szExt4PortHubNameSearch, _T("pid"));
			pExt4PortHubNameTempStart = ::_tcsstr(this->m_pExt4PortHubInfo[i].HubName,szExt4PortHubNameSearch);
			if(pExt4PortHubNameTempStart == NULL){
				::memset(szExt4PortHubNameSearch, 0 ,sizeof(szExt4PortHubNameSearch));
				::_tcscpy(szExt4PortHubNameSearch, _T("PID"));
				pExt4PortHubNameTempStart = ::_tcsstr(this->m_pExt4PortHubInfo[i].HubName,szExt4PortHubNameSearch);
				if(pExt4PortHubNameTempStart == NULL){
					return 12;
				}
			}
			//copy PID to szExt4PorHubNamePID
			TCHAR szExt4PortHubNameTempPID[8];
			::memset(szExt4PortHubNameTempPID, 0 ,sizeof(szExt4PortHubNameTempPID));
			::memcpy(szExt4PortHubNameTempPID, pExt4PortHubNameTempStart, sizeof(szExt4PortHubNameTempPID));

			//find #~~~#
			::memset(szExt4PortHubNameSearch, 0 ,sizeof(szExt4PortHubNameSearch));
			::_tcscpy(szExt4PortHubNameSearch, _T("#"));
			pExt4PortHubNameTempStart = ::_tcsstr(pExt4PortHubNameTempStart,szExt4PortHubNameSearch);
			if(pExt4PortHubNameTempStart == NULL){
				return 13;
			}

			//cpy to szHubNameTemp
			pExt4PortHubNameTempStart++;//ignaor #
			::memset(szExt4PortHubNameTemp, 0 ,sizeof(szExt4PortHubNameTemp));
			::memcpy(szExt4PortHubNameTemp, pExt4PortHubNameTempStart, sizeof(TCHAR) * MAX_PATH);

			//find next #
			pExt4PortHubNameTempEnd = ::_tcsstr(pExt4PortHubNameTempStart,szExt4PortHubNameSearch);
			if(pExt4PortHubNameTempEnd == NULL){
				return 14;
			}

			pExt4PortHubNameTempEnd--;
			TCHAR Ext4PortHubNumber = *pExt4PortHubNameTempEnd;
			pExt4PortHubNameTempEnd--;

			//copy to szHubNameTempSave
			::memset(szExt4PortHubNameTempSave, 0 ,sizeof(szExt4PortHubNameTempSave));
			for(int b = 0;  pExt4PortHubNameTempStart <= pExt4PortHubNameTempEnd ; b++){
				szExt4PortHubNameTempSave[b] =szExt4PortHubNameTemp[b];
				pExt4PortHubNameTempStart++;
			}
//Anjoy_0212 >>>
			//check the name #~~~~~# is the same or not 
			if(::strcmp(szExt4PortHubNameTempSave, szHubNameTempSave) != 0) {//check is the same hub
				continue;
			}

			//check is it under one U2 mode and one U3 mode
			if(::memcmp(szExt4PortHubNameTempPID, szHubNameTempPID, sizeof(szExt4PortHubNameTempPID)) == 0){
				continue;
			}
			Ext4PortHubNumber = (Ext4PortHubNumber % 2);
			ExHubPortNumber = (ExHubPortNumber % 2);

			//NEC 3.0 Root Hub 1,2 => U3; 3,4 => U2 , & 1/3 one ext-hub for U3/U2; 2/4 one ext-hub for U3/U2
			if(Ext4PortHubNumber == ExHubPortNumber){
				nIndexOffset = (this->m_pExt4PortHubInfo[i].HubNumber - 1) * 4;
				*pnMapIndex = nIndexOffset + (dwPortNumber - 1);
				return 0;
			}
//Anjoy_0212 <<<
			//else, it's a new hub name
		}
    }

    return 2;
}

//-------------------------------------------------------------------------------------------------
int CdlgSSDMP::GetMapPortIndexByExt7PortMode(IN TCHAR *szHubName, IN int dwPortNumber, OUT int  *pnMapIndex)
{
	return 0;
}

//-------------------------------------------------------------------------------------------------
void CdlgSSDMP::AddPortData(IN int PhyDrvNum, IN int MapIndex, IN char *pHubName, IN int PortNumber, IN int HubNumber)
{    
	this->m_PortData[MapIndex].PhyDrvNum = PhyDrvNum;
    
    // hub info
    ::strcpy(this->m_PortData[MapIndex].HubData.HubName, pHubName);
    this->m_PortData[MapIndex].HubData.PortNumber = PortNumber;
    this->m_PortData[MapIndex].HubData.HubNumber  = HubNumber;
    this->m_PortData[MapIndex].HubData.IsRootHub  = this->m_HubManager.IsRootHub(pHubName);
    
    return;
}

//-------------------------------------------------------------------------------------------------
void CdlgSSDMP::RemovePortData(IN int MapIndex)
{
    this->m_PortData[MapIndex].PhyDrvNum = -1;	

	// during task only reset above data
    
	if (g_IsStartRun == true) {
        /*
		this->m_PortData[MapIndex].PortDataLog.LogToFile(LOGLEVEL_USER, _T("[Task remove] handle[0] = %p"), this->m_PortData[MapIndex].hDrive[0]);
        */
		return;
	}
    
    if (this->m_PortData[MapIndex].hWorkThread != NULL) {
        ::CloseHandle(this->m_PortData[MapIndex].hWorkThread);
        this->m_PortData[MapIndex].hWorkThread = NULL;
    }
	
	this->m_PortData[MapIndex].ErrorCode    = 0;
	this->m_PortData[MapIndex].Mode         = UNKNOW_MODE;
	/*
	this->m_PortData[MapIndex].CardSize     = 0;
	*/
	::memset(&this->m_PortData[MapIndex].IdentifyDevice, 0, sizeof(ATA_IDENTIFY_CONFIG_INFO));
    this->m_PortData[MapIndex].IsReduceKey  = false;
    this->m_PortData[MapIndex].KeyProStatus = NO_NEED_KEY;
    
	::memset(&this->m_PortData[MapIndex].HubData, 0, sizeof(HUB_DATA));
    ::memset(&this->m_PortData[MapIndex].MPParam, 0, sizeof(CMD_LINE_MP_PARAM));
    
    ::memset(this->m_PortData[MapIndex].MPExeFullPath, 0, sizeof(this->m_PortData[MapIndex].MPExeFullPath));
    ::memset(&this->m_PortData[MapIndex].MPParam, 0, sizeof(CMD_LINE_MP_PARAM));
    
    return;
}

//-------------------------------------------------------------------------------------------------
int CdlgSSDMP::InsertDrive(IN int PhyDrvNum)
{
	ATA_IDENTIFY_CONFIG_INFO  IdentifyDevice;
    HANDLE  hDrive;
    int     MapIndex;
	char    HubName[256];
	DWORD   PortNumber;
	DWORD   HubNumber;
    int     Rslt;
	
	
    hDrive = GetDriveHandle(PhyDrvNum);
    if (hDrive == INVALID_HANDLE_VALUE) {
        return 1;
    }
	
    ::memset(HubName, 0, sizeof(HubName));
	Rslt = Vol_QueryPortNumberByDriveLetter(NULL, hDrive, HubName, &PortNumber);
	if (Rslt != 0) {
        ::CloseHandle(hDrive);
        hDrive = INVALID_HANDLE_VALUE;
		return 1;
	}
	
    
	if (g_IsStartRun == false) {  // normal insert
		
		// get map port index
		Rslt = this->GetMapPortIndex(HubName, PortNumber, &MapIndex);
		if (Rslt != 0) {
            ::CloseHandle(hDrive);
            hDrive = INVALID_HANDLE_VALUE;
			return 1;
		}
		
		// get hub number
		Rslt = this->m_HubManager.GetHubIndex(HubName, &HubNumber);
		if (Rslt != 0) {
            ::CloseHandle(hDrive);
            hDrive = INVALID_HANDLE_VALUE;
			return 1;
		}
		
		// get firmware mode
        int Mode;
		Rslt = SSD_Utility_Get_FW_Mode(-1, hDrive, 0, &Mode);
        if (Rslt != 0) {
            ::CloseHandle(hDrive);
            hDrive = INVALID_HANDLE_VALUE;
            return 1;
        }
        
        if (Mode == UNKNOW_MODE) {
            ::CloseHandle(hDrive);
            hDrive = INVALID_HANDLE_VALUE;
            return 1;
        }

		// get identify device
		::memset(&IdentifyDevice, 0, sizeof(ATA_IDENTIFY_CONFIG_INFO));
        Rslt = SSD_Utility_Get_ATA_Identify(-1, hDrive, &IdentifyDevice);
		if (Rslt != 0) {
			hDrive = INVALID_HANDLE_VALUE;
            return 1;
		}


		this->m_PortData[MapIndex].Mode        = Mode;
		/*
		this->m_PortData[MapIndex].CardSize    = IdentifyDevice.Number_Of_User_Addressable_Logical_Sectors;
		*/
		this->m_PortData[MapIndex].IdentifyDevice = IdentifyDevice;
		this->m_PortData[MapIndex].IsReduceKey = (Mode == ROM_SAFE_MODE) ? true : false;
		this->AddPortData(PhyDrvNum, MapIndex, HubName, PortNumber, HubNumber);

		// update device info for other page
		this->m_MPPage.UpdatePortDataUI(&this->m_PortData[MapIndex]);
	}
	else {  // during task insert drive
		Rslt = this->GetMapPortIndexEx(HubName, PortNumber, &MapIndex);  // use original method to get map index first
		if (Rslt != 0) {
            ::CloseHandle(hDrive);
            hDrive = INVALID_HANDLE_VALUE;
            return 1;
		}
		
        this->m_PortData[MapIndex].LogManager.LogToFile(false, true, "drive insert. phy drv num = %d. map index = %d", PhyDrvNum, MapIndex);
        
		this->m_PortData[MapIndex].PhyDrvNum = PhyDrvNum;
        ::SetEvent(g_hEvent[MapIndex]);
        
        // show new physical drive number to UI
        this->m_MPPage.UpdatePhyDrvNum(MapIndex, PhyDrvNum);
	}

	// update device info for other page
	this->m_RDTPage.Init(this->m_PortData);

	
    ::CloseHandle(hDrive);
    hDrive = INVALID_HANDLE_VALUE;
    
	return 0;
}

//-------------------------------------------------------------------------------------------------
int CdlgSSDMP::RemoveDrive()
{
    int  PhyDrvNum;  // removed physical drive number
	int  MapIndex;   // removed map index
	int  Rslt;


	Rslt = this->GetRemovedPhyDrvNum(&PhyDrvNum);
	if (Rslt != 0) {
		return 1;
	}

	Rslt = this->GetRemoveMapPortIndex(PhyDrvNum, &MapIndex);
	if (Rslt != 0) {
		return 2;
	}
	
	this->RemovePortData(MapIndex);
    
	// update device info for other page
    (g_IsStartRun == true) ? this->m_MPPage.UpdatePhyDrvNum(MapIndex, -1) : this->m_MPPage.ClearPort(MapIndex);
	this->m_RDTPage.Init(this->m_PortData);
    
	return 0;
}

//---------------------------------------------------------------------------
int CdlgSSDMP::GetRemoveMapPortIndex(IN int PhyDrvNum, OUT int *pMapIndex)
{
	for (int i = 0; i < SUPPORT_PORT_COUNT; i++) {
		if (this->m_PortData[i].PhyDrvNum == PhyDrvNum) {
			*pMapIndex = this->m_PortData[i].MapIndex;
			return 0;
		}
	}

	return 1;
}

//-------------------------------------------------------------------------------------------------
int CdlgSSDMP::GetRemovedPhyDrvNum(OUT int *pPhyDrvNum)
{
	HANDLE  hDrive;

	
	// by getting each port physical drive number handle to judge this drive is removed
	for (int i = 0; i < SUPPORT_PORT_COUNT; i++) {
	    if (this->m_PortData[i].PhyDrvNum == -1) {
            continue;
        }
        
        hDrive = GetDriveHandle(this->m_PortData[i].PhyDrvNum);
        if (hDrive == INVALID_HANDLE_VALUE) {
            *pPhyDrvNum = this->m_PortData[i].PhyDrvNum;
            return 0;
        }		

        // when re-get handle and then close one of them, another handle
        // will still work successfully.
        ::CloseHandle(hDrive);
        hDrive = INVALID_HANDLE_VALUE;
	}

	return 1;
}

//-------------------------------------------------------------------------------------------------
int CdlgSSDMP::OnMsgStartRun()
{
    CMD_LINE_MP_PARAM  Param;
    CString  StrMsg;
	UINT     ThreadID;
    int      Rslt;
        	
 
    ::memset(&Param, 0, sizeof(CMD_LINE_MP_PARAM));
    this->GetCMDLineParam(&Param);
    
	Rslt = this->CheckCMDLineParam(&Param);
	if (Rslt != 0) {
		return 1;
	}

	// get over-provisioning by reading combo fw
	if (::strcmp(Param.Task, FTB_TASK) == 0) {
		Rslt = this->GetOPByComboFW(Param.FWFullPath, &this->m_OP);
		if (Rslt != 0) {
			MessageBox("parse combo firmware to get op info fail", NULL, MB_OK | MB_ICONERROR);
			return 1;
		}
	}

    
    //==================================================================
    //                  prepare working thread
    //==================================================================    
    g_TaskCount    = 0;
    g_NeedKeyCount = 0;
    
    for (int i = 0; i < SUPPORT_PORT_COUNT; i++) {
        
        // reset port data info
        this->m_PortData[i].ErrorCode    = MP_NO_ERROR;
        this->m_PortData[i].KeyProStatus = NO_NEED_KEY;
        ::memset(&this->m_PortData[i].IdentifyDevice, 0, sizeof(ATA_IDENTIFY_CONFIG_INFO));
        
        // check device is exist
        if ((this->m_PortData[i].PhyDrvNum == -1) || (this->m_MPPage.IsItemChecked(i) == FALSE)) {
            continue;
        }

		// create working thread
        this->m_PortData[i].hWorkThread = (HANDLE)::_beginthreadex(NULL, 0, MPTask, &this->m_PortData[i], CREATE_SUSPENDED, &ThreadID);
        if (this->m_PortData[i].hWorkThread == NULL) {
            this->CloseHandleAllWorkingThread();
            MessageBox("create working thread fail", NULL, MB_OK | MB_ICONERROR);
            return 1;
        }
        
        // calculate total working thread
		g_TaskCount++;
        
        // assing to command line parameter
        ::memcpy(&this->m_PortData[i].MPParam, &Param, sizeof(CMD_LINE_MP_PARAM));
        ::strncpy(this->m_PortData[i].MPExeFullPath, this->m_MPFullPath, MAX_PATH);
    }
    
	if (g_TaskCount == 0) {
        return 0;
    }
    
    
    //==================================================================
    //                   get key count
    //==================================================================
    Rslt = (*this->fnReadCounterFromBadBlock)(this->m_KeyProDrive, &g_KeyProCount);
    if (Rslt != 0) {
        g_KeyProCount = 0;
    }
    this->m_MPPage.SetStatusBarKeyProCount(g_KeyProCount);
    
    
    //==================================================================
    //                  start working thread
    //==================================================================
    g_IsStartRun = true;
    this->m_MPPage.EnableAllUI(false);
	this->m_MPPage.EnableRunTimer(true);
	this->m_TabMainSheet.EnableWindow(false);
    	
	
    for (int i = 0; i < SUPPORT_PORT_COUNT; i++) {

		// clear MP page UI
		this->m_MPPage.UpdateCapacity(i, "");

		// resume working thread
        if (this->m_PortData[i].hWorkThread == NULL) {
            continue;
        }
        
        ::ResumeThread(this->m_PortData[i].hWorkThread);
        this->m_MPPage.UpdateStatus(i, DRIVE_BUSY, COLOR_BLUE);
    }

    return 0;
}

//-------------------------------------------------------------------------------------------------
int CdlgSSDMP::GetPassFailCout(OUT int *pPass, OUT int *Fail)
{
	*pPass = 0;
	*Fail  = 0;

	for (int i = 0; i < SUPPORT_PORT_COUNT; i++) {
		*pPass += this->m_PortData[i].PassCount;
		*Fail += this->m_PortData[i].FailCount;
	}

	return 0;
}

//-------------------------------------------------------------------------------------------------
void CdlgSSDMP::CloseHandleAllWorkingThread()
{
    for (int i = 0; i < SUPPORT_PORT_COUNT; i++) {
        if (this->m_PortData[i].hWorkThread == NULL) {
            continue;
        }
        
        ::CloseHandle(this->m_PortData[i].hWorkThread);
        this->m_PortData[i].hWorkThread = NULL;
    }
    
    return;
}

//-------------------------------------------------------------------------------------------------
void CdlgSSDMP::OnMsgUpdateProgress(IN int MapIndex, IN int Progress)
{
    this->m_MPPage.UpdateProgress(MapIndex, Progress);
    return;
}

//-------------------------------------------------------------------------------------------------
void CdlgSSDMP::OnMsgThreadTerminate(IN int MapIndex)
{
	char  Buffer[16];


    this->m_MPPage.ShowErrorCode(MapIndex, this->m_PortData[MapIndex].ErrorCode);

	// show capacity only when FTB flow pass
	/*
    cfg_tbl_nand_info_t *pInfo;
	UINT32  MB;         // device total size.  unit: MB
    UINT64  Sector;     // device total size that reported by size table
    UINT32  BlockSize;  // unit: MB
    int     Rslt;
    
	if ((::strcmp(this->m_PortData[MapIndex].MPParam.Task, FTB_TASK) == 0) && (this->m_PortData[MapIndex].ErrorCode == MP_NO_ERROR) && (this->m_PortData[MapIndex].NandInfoManager.IsInitSucceed())) {
		pInfo = this->m_PortData[MapIndex].NandInfoManager.GetNandInfo();
		
		BlockSize = (pInfo->nr_pages_per_block * (pInfo->page_data_sz / 1024)) / 1024;  // unit: MB
		MB        = (pInfo->nr_werus * pInfo->width * BlockSize);  // total size. unit: MB
		
        Rslt = this->QuerySizeTable(this->m_OP, MB, &Sector);
        if (Rslt != 0) {
			this->m_MPPage.UpdateCapacity(MapIndex, "not define");
		}
		else {
			double GB = CdlgMPPage::UINT64ToDouble(Sector) / 2 / 1024 / 1024;
			::memset(Buffer, 0, sizeof(Buffer));
			::sprintf(Buffer, "%.2f GB", GB);

            this->m_MPPage.UpdateCapacity(MapIndex, Buffer);
        }
	}
	else {
		this->m_MPPage.UpdateCapacity(MapIndex, "16 MB");
	}
	*/
	if ((::strcmp(this->m_PortData[MapIndex].MPParam.Task, FTA_TASK) == 0) && (this->m_PortData[MapIndex].ErrorCode == MP_NO_ERROR)) {
		this->m_MPPage.UpdateCapacity(MapIndex, "16 MB");
	}
	else if ((::strcmp(this->m_PortData[MapIndex].MPParam.Task, FTB_TASK) == 0) && (this->m_PortData[MapIndex].ErrorCode == MP_NO_ERROR)) {
		UINT64 CardSize = this->m_PortData[MapIndex].IdentifyDevice.Number_Of_User_Addressable_Logical_Sectors;
		double GB = CdlgMPPage::UINT64ToDouble(CardSize) / 2 / 1024 / 1024;

		::memset(Buffer, 0, sizeof(Buffer));
		::sprintf(Buffer, "%.2f GB", GB);
		
		this->m_MPPage.UpdateCapacity(MapIndex, Buffer);
	}
	else {
		this->m_MPPage.UpdateCapacity(MapIndex, "");
	}
    

    // calculate pass / fail count
    if (this->m_PortData[MapIndex].ErrorCode == MP_NO_ERROR) {
        this->m_PortData[MapIndex].PassCount++;
    }
    else {
        this->m_PortData[MapIndex].FailCount++;
    }
    

    // judge is need to reduce key next time
    if ((this->m_PortData[MapIndex].Mode == ROM_SAFE_MODE) && (this->m_PortData[MapIndex].ErrorCode == MP_NO_ERROR)) {
        this->m_PortData[MapIndex].IsReduceKey = false;
    }
    

    // release resource working thread handle
    if (this->m_PortData[MapIndex].hWorkThread != NULL) {
        ::CloseHandle(this->m_PortData[MapIndex].hWorkThread);
        this->m_PortData[MapIndex].hWorkThread = NULL;
    }
    

	// re-name UI log name
    this->m_PortData[MapIndex].LogManager.LogToFile(true, true, "error code = %d", this->m_PortData[MapIndex].ErrorCode);
	this->RenamePortDataLog(MapIndex);


    return;
}

//-------------------------------------------------------------------------------------------------
void CdlgSSDMP::OnMsgAllThreadTerminate()
{
	int  PassCout;
	int  FailCount;
	int  TotalCount;
	int  ReduceKey;
	int  Rslt;


    g_IsStartRun = false;


    // update count info
	this->GetPassFailCout(&PassCout, &FailCount);
	TotalCount = PassCout + FailCount;

	this->m_MPPage.SetStatusBarPassCount(PassCout);
	this->m_MPPage.SetStatusBarFailCount(FailCount);
	this->m_MPPage.SetStatusBarTotalCount(TotalCount);
	

    // enable UI
    (g_IsKeyProDrvRemoved == true) ? this->m_MPPage.EnableAllUI(false) : this->m_MPPage.EnableAllUI(true);
    this->m_TabMainSheet.EnableWindow(true);
    

    // reduce key count of key pro drive
    ReduceKey = 0;

    for (int i = 0; i < SUPPORT_PORT_COUNT; i++) {
        if ((this->m_PortData[i].KeyProStatus == NEED_KEY) && (this->m_PortData[i].ErrorCode == MP_NO_ERROR)) {
            ReduceKey++;
        }
    }

	if (ReduceKey > 0) {
		g_KeyProCount = (g_KeyProCount > ReduceKey) ? (g_KeyProCount - ReduceKey) : 0;

		Rslt = (*this->fnWriteCounterToBadBlock)(this->m_KeyProDrive, g_KeyProCount);
		if (Rslt != 0) {
			g_KeyProCount = 0;
            this->m_MPPage.SetStatusBarKeyProCount(g_KeyProCount);
			MessageBox("update key fail", NULL, MB_OK | MB_ICONERROR);
			return;
		}

		this->m_MPPage.SetStatusBarKeyProCount(g_KeyProCount);
	}

	this->m_MPPage.EnableRunTimer(false);


    return;
}

//-------------------------------------------------------------------------------------------------
int CdlgSSDMP::OnMsgScanDrive()
{
    //
    // maybe need to do ...
    //
    
    return 0;
}

//-------------------------------------------------------------------------------------------------
void CdlgSSDMP::OnMsgChangeSN()
{
	// change g_SNManager serial number format
    int  Rslt;

    Rslt = g_SNManager.Init(this->m_SettingPage1.m_StartSN, this->m_SettingPage1.m_EndSN, this->m_SettingPage1.m_Mask);
    if (Rslt != 0) {
        this->m_MPPage.EnableAllUI(false);
        MessageBox("re-init serial number fail", NULL, MB_OK | MB_ICONERROR);
        return;
    }

	return;
}

//-------------------------------------------------------------------------------------------------
void CdlgSSDMP::OnMsgUpdateDescription(IN int IniMode)
{
    CString  Str;
    char     Buffer[MAX_PATH];
    int      Rslt;


    ::memset(Buffer, 0, sizeof(Buffer));
    
    Rslt = this->m_SettingPage2.GetDescription(Buffer, MAX_PATH);
    if (Rslt != 0) {
        return;
    }
    
    this->m_MPPage.ShowDescription(Buffer);

    return;
}

//-------------------------------------------------------------------------------------------------
int CdlgSSDMP::GetKeyProDrive(OUT char *pDrive, OUT int *pKeyCount)
{
	DWORD    DriveMask;  // drive bit mask
	char     Drive;
	char     DriveRoot[4];
	UINT     DriveType;
	KeyInfo  Info;
    int      Rslt;


    DriveMask = ::GetLogicalDrives();
    if (DriveMask == 0) {
        return 1;
    }
    
	::memset(DriveRoot, 0, sizeof(DriveRoot));
    ::strcpy(DriveRoot, "A:\\");

    // Form 'C' drive to 'Z'
    for (int i = 2; i < 26; i++) {
        if ((DriveMask & (1 << i)) == 0) {
            continue;
        }

		Drive = 'A' + i;
        DriveRoot[0] = Drive;

        DriveType = ::GetDriveType(DriveRoot);
        if (DriveType != DRIVE_REMOVABLE) {
            continue;
        }
        
		::memset(&Info, 0, sizeof(KeyInfo));
		Info.Drive = Drive;
		::memcpy(Info.PublicKeyBuffer, g_PublicKey, sizeof(Info.PublicKeyBuffer));
		Info.PublicKeySize = sizeof(g_PublicKey);
		
		Rslt = (*this->fnCheckCardIsValidEx)(&Info);
		if ((Rslt != 0) || (Info.Result != 1)) {
			continue;
		}
		
		Rslt = (*this->fnReadCounterFromBadBlock)(Info.Drive, pKeyCount);
		if (Rslt != 0) {
			continue;
		}
 
        *pDrive = DriveRoot[0];

		return 0;
    }

    return 1;
}

//-------------------------------------------------------------------------------------------------
int CdlgSSDMP::DetectKeyProDriveRemoved(IN DEV_BROADCAST_VOLUME *pDBV)
{
	char Drive;


	for (int i = 0; i < 32; i++) {
		if (!(pDBV->dbcv_unitmask & (1L << i))) {
			continue;
		}
		
		Drive = 'A' + i;

		if (this->m_KeyProDrive != Drive) {
			continue;
		}
        
        //
        // for HUATOOP's strange issue:
        // When SSD device reboot, will cause key pro drive disconnect
        // so we try to get key pro drive handle to be sure it's removed.
        // 
        char  DriveRoot[32] = {0};
        ::sprintf(DriveRoot, "\\\\.\\%c:", Drive);
        HANDLE hDrive = ::CreateFile(DriveRoot, GENERIC_WRITE | GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL,OPEN_EXISTING, 0, NULL);
        if (hDrive != INVALID_HANDLE_VALUE) {
            ::CloseHandle(hDrive);
            hDrive = INVALID_HANDLE_VALUE;
            continue;
        }

		this->m_KeyProDrive = NULL;
		g_KeyProCount = 0;
		this->m_MPPage.SetStatusBarKeyProCount(g_KeyProCount);
		
		if (g_IsStartRun == true) {
	        // kill child process
			g_IsKeyProDrvRemoved = true;
		}
		else {
	        MessageBox("key pro drive has been removed", NULL, MB_OK | MB_ICONERROR);
			this->m_MPPage.EnableAllUI(false);
		}

		return 0;
	}

	return 1;
}

//-------------------------------------------------------------------------------------------------
int CdlgSSDMP::GetCMDLineParam(OUT CMD_LINE_MP_PARAM *pParam)
{
    char  LogFullPath[MAX_PATH];
    int   Task;
    
    
    ::memset(pParam, 0, sizeof(CMD_LINE_MP_PARAM));
    
    this->m_SettingPage2.GetTask(&Task);
    switch (Task) {
        case FTA_FLOW:  ::strcpy(pParam->Task, FTA_TASK);    break;
        case FTB_FLOW:  ::strcpy(pParam->Task, FTB_TASK);    break;
        default:  ::strcpy(pParam->Task, "UNKNOW_TASK");  break;
    }
    
    this->m_SettingPage2.GetIniFullPath(pParam->ConfigFullPath, MAX_PATH);
    this->m_SettingPage2.GetFwFullPath(pParam->FWFullPath, MAX_PATH);
    
    ::memset(LogFullPath, 0, sizeof(LogFullPath));
    this->m_FileManager.GetCurrentExeFilePath(LogFullPath, sizeof(LogFullPath));
    ::strcat(LogFullPath, "Log\\SSS_Test.txt");
    ::strncpy(pParam->LogFullPath, LogFullPath, sizeof(pParam->LogFullPath));
    
    ::strcpy(pParam->WO, "");
    ::strcpy(pParam->SN, "1234567890ABCDEF");

    return 0;
}

//-------------------------------------------------------------------------------------------------
int CdlgSSDMP::CheckCMDLineParam(IN CMD_LINE_MP_PARAM *pParam)
{
	CString  StrMsg;
	BOOL     IsFileExist;


	if ((::strcmp(pParam->Task, FTA_TASK) != 0) && (::strcmp(pParam->Task, FTB_TASK) != 0)) {
		StrMsg.Format("unknow task");
		MessageBox(StrMsg, NULL, MB_OK | MB_ICONERROR);
		return 1;
	}

	IsFileExist = this->m_FileManager.IsFileExist(pParam->ConfigFullPath);
	if (IsFileExist == FALSE) {
		StrMsg.Format("ini doesn't exist. file = %s", pParam->ConfigFullPath);
		MessageBox(StrMsg, NULL, MB_OK | MB_ICONERROR);
		return 1;
	}

	IsFileExist = this->m_FileManager.IsFileExist(pParam->FWFullPath);
	if (IsFileExist == FALSE) {
		StrMsg.Format("fw doesn't exist. file = %s", pParam->FWFullPath);
		MessageBox(StrMsg, NULL, MB_OK | MB_ICONERROR);
		return 1;
	}

	return 0;
}

//-------------------------------------------------------------------------------------------------
int CdlgSSDMP::GetOPByComboFW(IN char *pFullPath, OUT int *pOP)
{
	FILE     *pFile;
    __int64  FileSize;
    UINT32   ReadSize;
    BYTE     *pBuffer;
    int      Rslt;


    //===================================================================
    //                        read file
    //===================================================================
    Rslt = this->m_FileManager.GetFileSize(pFullPath, &FileSize);
    if (Rslt != 0) {
        return 1;
    }

    pFile = ::fopen(pFullPath, "rb");
    if (pFile == NULL) {
        return 1;
    }
    
    pBuffer = (BYTE*)::malloc((UINT32)FileSize * sizeof(BYTE));
    if (pBuffer == NULL) {
        ::fclose(pFile);
        pFile = NULL;
        return 1;
    }
    
    ::memset(pBuffer, 0, (UINT32)FileSize * sizeof(BYTE));
    ReadSize = ::fread(pBuffer, sizeof(BYTE), (UINT32)FileSize, pFile);
    if (ReadSize != FileSize) {
        ::fclose(pFile);
        pFile = NULL;
        ::free(pBuffer);
        pBuffer = NULL;
        return 1;
    }
    
    
    //===================================================================
    //                      decrypt by AES
    //===================================================================
    int  HeaderSize;
    int  DownloadSize;
    AES  aes(g_AES_KEY);
    
    aes.InvCipher(pBuffer, (int)FileSize);
    CIPHER_HEADER *pHeader = (CIPHER_HEADER*)pBuffer;

    if (::memcmp(pHeader->Signature, CIPHER_SIGNATURE, ::strlen(CIPHER_SIGNATURE)) == 0) {  // has been decrypted
        HeaderSize   = sizeof(CIPHER_HEADER);
        DownloadSize = pHeader->Size;
    }
    else {  // didn't be decrypted
        ::rewind(pFile);
        
        ::memset(pBuffer, 0, (UINT32)FileSize);
        ReadSize = ::fread(pBuffer, sizeof(BYTE), (UINT32)FileSize, pFile);
        if (ReadSize != FileSize) {
            ::fclose(pFile);
            pFile = NULL;
            ::free(pBuffer);
            pBuffer = NULL;
            return 1;
        }
        HeaderSize = 0;
        DownloadSize = (UINT32)FileSize;
    }

	// release resource
    ::fclose(pFile);
    pFile = NULL;
	

	//===================================================================
    //                      find MISC_HDR
    //===================================================================
	int  Offset = 32;              // unit: byte
	bool IsFindSignature = false;  // "MISC_HDR" signature
	char Signature[] = "MISC_HDR";

	BYTE *pTemp;
	for (int i = 0; i < 20; i++) {
		if (::memcmp((pBuffer + HeaderSize + (i * Offset)), Signature, ::strlen(Signature)) != 0) {
			continue;
		}
		IsFindSignature = true;
		pTemp = pBuffer + HeaderSize + (i * Offset);
		break;
	}

	if (IsFindSignature == false) {
		return 1;
	}

	UINT32 CFGImageAddr = ((UINT32)pTemp[27] << 24)  | ((UINT32)pTemp[26] << 16) | ((UINT32)pTemp[25] << 8) | pTemp[24];
    *pOP = pBuffer[HeaderSize + CFGImageAddr + 0x870 + 0x23];

	return 0;
}

//-------------------------------------------------------------------------------------------------
int CdlgSSDMP::QuerySizeTable(IN int OP, IN UINT32 MB, OUT UINT64 *pSector)
{
	//
	// according to the real card size to build below table
	// unit: sector count         128GB      256GB
	//
    UINT64  OP7_Sector_Table[] = {234441648, 468862128};
    UINT64  OP0_Sector_Table[] = {250069680, 500118192};
    UINT64  *pTable;
 
	
	// align 32GB
	MB = MB - (MB % (32 * 1024));
    
    pTable = (OP == 0) ? OP0_Sector_Table : OP7_Sector_Table;

    if (MB < (128 * 1024)) {
        return 1;
    }
    else if (MB < (256 * 1024)) {
        *pSector = pTable[0];  // 128 GB
    }
    else if (MB < (512 * 1024)) {
        *pSector = pTable[1];  // 256 GB
    }
    else {
        return 1;
    }
    
    return 0;
}

//-------------------------------------------------------------------------------------------------
void CdlgSSDMP::RenamePortDataLog(IN int MapIndex)
{
	char  NewUILogFullPath[MAX_PATH];
	char  Temp[16];


	if (::strlen(this->m_PortData[MapIndex].UILogFullPath) == 0) {
		return;
	}

	::memset(Temp, 0, sizeof(Temp));
	(this->m_PortData[MapIndex].ErrorCode == MP_NO_ERROR) ? ::strcpy(Temp, "Pass_") : ::strcpy(Temp, "Fail_");
	
	::memset(NewUILogFullPath, 0, sizeof(NewUILogFullPath));
	::sprintf(NewUILogFullPath, "%s%s%s", this->m_PortData[MapIndex].UILogPath, Temp, this->m_PortData[MapIndex].UILogName);

	this->m_FileManager.RenameFileName(this->m_PortData[MapIndex].UILogFullPath, NewUILogFullPath);

	return;
}

//-------------------------------------------------------------------------------------------------

