// DefectManager.h: interface for the CDefectManager class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DEFECTMANAGER_H__02F09968_857B_4801_899A_1FFA708171B7__INCLUDED_)
#define AFX_DEFECTMANAGER_H__02F09968_857B_4801_899A_1FFA708171B7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//-------------------------------------------------------------------------------------------------
#include <vector>

#include "SSD_Command.h"
#include "SSD_Utility.h"

//-------------------------------------------------------------------------------------------------
class CDefectManager  
{
public:
	CDefectManager();
	virtual ~CDefectManager();

public:
	int  Init(IN int PhyDrvNum, IN HANDLE hDevice, IN ENUM_READ_LOG_EXT_MODE Mode);
    
    // interface
    DEFECT_INFO  *GetFD();
    DEFECT_INFO  *GetGD();
    DEFECT_INFO  *GetAllDefect();
    bool         IsInitSucceed();

private:
	bool m_InitSucceed;
    
    DEFECT_INFO  m_FD;  // factory defect
    DEFECT_INFO  m_GD;  // grown defect
    DEFECT_INFO  m_AllDefect;  // factory defect + grown defect
    
    void  InitMember();
    void  FilterToGetGD(IN DEFECT_INFO *pFD, IN OUT DEFECT_INFO *pGD);
};

//-------------------------------------------------------------------------------------------------

#endif // !defined(AFX_DEFECTMANAGER_H__02F09968_857B_4801_899A_1FFA708171B7__INCLUDED_)
