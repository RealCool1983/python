// MTableManager.h: interface for the CMTableManager class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MTABLEMANAGER_H__F19DDD04_9959_409B_A8FC_81AA63E66F81__INCLUDED_)
#define AFX_MTABLEMANAGER_H__F19DDD04_9959_409B_A8FC_81AA63E66F81__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


//-------------------------------------------------------------------------------------------------
#pragma warning(disable : 4018)         // for do not show warning C4786
#include <vector>


#include "MPDefine.h"
#include "FileManager.h"


//-------------------------------------------------------------------------------------------------
enum ENUM_TASK {UNKNOW_TASK, FTA_FLOW, FTB_FLOW, QC_FLOW};

#define ITEM_COUNT              (1000)   // unit: SETTING_ITEM object
#define COMMENT_LEN             (128)    // unit: char


#define SECTION_HEADER_TOSHIBA  "Toshiba"
#define SECTION_HEADER_HYNIX    "Hynix"
#define SECTION_HEADER_INTEL    "Intel"
#define SECTION_HEADER_MICRON   "Micron"
#define SECTION_HEADER_SAMSUNG  "Samsung"
#define SECTION_HEADER_SANDISK  "Sandisk"


#pragma pack(1)

typedef struct _SETTING_ITEM
{
	int   Task;
	char  IniFullPath[MAX_PATH];
	char  FwFullPath[MAX_PATH];
	char  Comment[COMMENT_LEN];
} SETTING_ITEM, *PSETTING_ITEM;

#pragma pack()

//-------------------------------------------------------------------------------------------------
class CMTableManager  
{
public:
	CMTableManager();
	virtual ~CMTableManager();

	// need init first
	int  Init(IN BYTE *pFlashID, IN char *pMTableFullPath);

	// interface
	int  GetItem(OUT SETTING_ITEM *pItem, IN int Index);
	int  GetItemCount();


private:
	CFileManager               m_FileManager;
	std::vector<SETTING_ITEM>  m_Item;
	BYTE                       m_FlashID[FLASH_ID_LENGTH];
	char                       m_MTableFullPath[MAX_PATH];

	int  ParseMTable(IN BYTE *pFlashID, IN char *pMTableFullPath);
	int  GetTask(IN char *pKeyWord);

};

//-------------------------------------------------------------------------------------------------

#endif // !defined(AFX_MTABLEMANAGER_H__F19DDD04_9959_409B_A8FC_81AA63E66F81__INCLUDED_)
